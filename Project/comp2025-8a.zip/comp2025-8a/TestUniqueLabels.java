import pt.up.fe.comp2025.backend.JasminUtils;
import org.specs.comp.ollir.type.BuiltinType;
import org.specs.comp.ollir.type.BuiltinKind;
import org.specs.comp.ollir.OperationType;

public class TestUniqueLabels {
    public static void main(String[] args) {
        JasminUtils utils = new JasminUtils(null);
        BuiltinType intType = new BuiltinType(BuiltinKind.INT32);
        
        // Generate multiple LTH operations to test unique labels
        System.out.println("First LTH operation:");
        System.out.println(utils.getBinaryOpInstruction(OperationType.LTH, intType));
        System.out.println("\nSecond LTH operation:");
        System.out.println(utils.getBinaryOpInstruction(OperationType.LTH, intType));
        System.out.println("\nThird LTH operation:");
        System.out.println(utils.getBinaryOpInstruction(OperationType.LTH, intType));
    }
}
