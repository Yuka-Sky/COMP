/**
 * Copyright 2022 SPeCS.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License. under the License.
 */

package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;

import java.util.Arrays;
import java.util.List;

/**
 * Conditional branch that has a {@link SingleOpInstruction} as condition.
 *
 * @author Joao Bispo
 *
 */
public class SingleOpCondInstruction extends CondBranchInstruction {

    private final SingleOpInstruction inst;

    public SingleOpCondInstruction(SingleOpInstruction inst) {
        this.inst = inst;
    }

    @Override
    public List<Element> getOperands() {
        //if (inst.getSingleOperand().getType().getTypeOfElement() == ElementType.BOOLEAN) {
        //
        //}
        return Arrays.asList(inst.getSingleOperand());
    }

    /*
    @Override
    protected String getCondType() {
        return "SingleOpCond";
    }
*/

    @Override
    public SingleOpInstruction getCondition() {
        return inst;
    }
}
