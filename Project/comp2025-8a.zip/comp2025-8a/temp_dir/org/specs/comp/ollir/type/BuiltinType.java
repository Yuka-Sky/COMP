package org.specs.comp.ollir.type;

public class BuiltinType extends Type {

    private final BuiltinKind builtinKind;

    public BuiltinType(BuiltinKind typeOfElement) {
        this.builtinKind = typeOfElement;
    }

    /**
     * Tests if the given type is a BuiltinType of the given kind.
     * @param type
     * @param builtinKind
     * @return
     */
    public static boolean is(Type type, BuiltinKind builtinKind) {
        if(type instanceof BuiltinType builtinType) {
            return builtinType.getKind() == builtinKind;
        }

        return false;
    }


    @Override
    public void show() {
        System.out.println("Type: " + this);
    }

    @Override
    public String toString() {

        return builtinKind.toString();
    }

    public BuiltinKind getKind() {
        return builtinKind;
    }

}
