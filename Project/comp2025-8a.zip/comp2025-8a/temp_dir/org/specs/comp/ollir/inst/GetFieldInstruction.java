/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operand;
import org.specs.comp.ollir.type.Type;

/**
 * Class representing the field instructions: getfield, getstatic.
 */
public class GetFieldInstruction extends FieldInstruction {

    public GetFieldInstruction(Operand object, Operand field, Type fieldType) {
        super(InstructionType.GETFIELD, fieldType, object, field);
    }

    @Override
    public String toString() {
        return super.toString() + " object " + getObject() + ", field " + getField();
    }
}
