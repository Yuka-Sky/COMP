package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

import java.util.List;

public final class InvokeVirtualInstruction extends CallInstruction {

    public InvokeVirtualInstruction(Element caller, Element methodName, List<Element> arguments,  Type returnType, boolean isIsolated) {
        super(caller, methodName, arguments, returnType, isIsolated);
    }

}
