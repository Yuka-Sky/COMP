/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operand;
import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.Type;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Class representing the field instructions: getfield, getstatic, putfield, putstatic.
 */
public abstract class FieldInstruction extends Instruction {

    private List<Element> operands;

    private Type fieldType;

    public FieldInstruction(InstructionType instType, Type fieldType, Operand object, Operand field, Collection<Element> extraOperands) {
        super(instType);

        this.operands = new ArrayList<>();
        this.operands.add(object);
        this.operands.add(field);
        this.operands.addAll(extraOperands);

        this.fieldType = fieldType;
    }

    public FieldInstruction(InstructionType instType, Type fieldType,  Operand object, Operand field, Element... extraOperands) {
        this(instType, fieldType, object, field, Arrays.asList(extraOperands));
    }

    public List<Element> getOperands() {
        return operands;
    }

    public void setOperands(List<Element> operands) {
        // Verify if has at least two elements, and that are of type Operand
        if(operands.size() < 2) {
            throw new RuntimeException("At least two operands are required (object and field), got " + operands.size());
        }

        if(!(operands.get(0) instanceof Operand) ||  !(operands.get(1) instanceof Operand)) {
            throw new RuntimeException("The first two operands must be of type Operand: " + operands);
        }

        this.operands = new ArrayList<>(operands);
    }

    public void setOperands(Element... operands) {
        setOperands(Arrays.asList(operands));
    }

    public Type getFieldType() {
        return fieldType;
    }



    public FieldInstruction(InstructionType tp) {
        super(tp);
    }

    public Operand getObject() {
        return (Operand) getOperands().get(0);
    }

    public Operand getField() {
        return (Operand) getOperands().get(1);
    }

    @Override
    public List<TreeNode> getChildren() {
        return new ArrayList<>(getOperands());
    }
}
