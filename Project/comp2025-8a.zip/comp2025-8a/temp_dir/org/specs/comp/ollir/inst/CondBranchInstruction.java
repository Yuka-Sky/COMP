/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.tree.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing the OLLIR conditional instructions. They have a comparison and a label to which the flow must jump
 * if the comparison is evaluated as true.
 */
public abstract class CondBranchInstruction extends Instruction {

    String label;

    public String getLabel() {
        return this.label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    //protected abstract String getCondType();

    @Override
    public String toString() {
        var string = new StringBuilder();

        string.append(super.toString() + " (CondBranch) ");

        var operands = getOperands();
        if (operands.size() < 1 || operands.size() > 2) {
            throw new RuntimeException("Expected condition to have between one and two operands, has " + operands.size());
        }

        string.append(getCondition());
        string.append(", Label: " + this.label);

        return string.toString();
    }

    public CondBranchInstruction() {
        super(InstructionType.BRANCH);
    }

    public abstract List<Element> getOperands();

    public abstract Instruction getCondition();

    @Override
    public List<TreeNode> getChildren() {
        return new ArrayList<>(getOperands());
    }
}
