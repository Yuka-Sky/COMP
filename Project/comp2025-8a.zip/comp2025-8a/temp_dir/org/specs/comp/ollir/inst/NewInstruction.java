package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

import java.util.List;

public final class NewInstruction extends CallInstruction {

    public NewInstruction(Element classNameOrArray, List<Element> arguments, Type returnType, boolean isIsolated) {
        super(classNameOrArray, null, arguments, returnType, isIsolated);
    }

}
