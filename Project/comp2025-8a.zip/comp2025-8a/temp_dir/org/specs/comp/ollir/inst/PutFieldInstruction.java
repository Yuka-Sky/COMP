/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operand;
import org.specs.comp.ollir.type.Type;

/**
 * Class representing the field instructions: putfield, putstatic.
 */
public class PutFieldInstruction extends FieldInstruction {


    public Element getValue() {
        return getOperands().get(2);
    }

    public PutFieldInstruction(Operand object, Operand field, Element value, Type fieldType) {
        super(InstructionType.PUTFIELD, fieldType, object, field, value);
    }

    @Override
    public String toString() {
        return super.toString() + " object " + getObject() + ", field " + getField() + ", value " + getValue();
    }



}
