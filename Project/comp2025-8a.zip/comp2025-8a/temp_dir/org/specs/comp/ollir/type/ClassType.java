/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

/**
 * The Type is a Class.
 */
public class ClassType extends Type {

    private final String name;
    private final ClassKind kind;

    public ClassType(ClassKind kind, String name) {
        this.name = name;
        this.kind = kind;
    }


    /**
     * Tests if given type is a ClassType of the given kind.
     * @param type
     * @param kind
     */
    public static boolean is(Type type, ClassKind kind) {
        if(type instanceof ClassType classType) {
            return classType.getKind() == kind;
        }

        return false;
    }


    public ClassKind getKind() {
        return kind;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public void show() {
        System.out.println("Type: " + getKind() + " Name: " + this.name);
    }

    @Override
    public String toString() {
        return kind.toString() + "(" + name + ")";
    }



}
