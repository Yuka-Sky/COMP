/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

import org.specs.comp.ollir.tree.TreeNode;

import java.util.List;

/**
 *
 */
public class ArrayType extends Type {

    // number of dimensions of the array
    int numDimensions;
    private Type elementType = null;

    public ArrayType() {

    }

    public ArrayType(int dims) {
        this.numDimensions = dims;
    }

    public void setElementType(Type elementType) {
        this.elementType = elementType;
    }

    @Override
    public List<TreeNode> getChildren() {
        if(elementType == null) {
            throw new RuntimeException("Element type of the array not set");
        }

        return List.of(elementType);
    }

    /**
     * @return the type of the elements of the array, as a Type
     */
    public Type getElementType() {
        return (Type) getChildren().get(0);
    }

    public int getNumDimensions() {
        return this.numDimensions;
    }

    @Override
    public void show() {
        System.out.println("Type: ARRAYREF " + this);
    }

    @Override
    public String toString() {

        // translate array dimensions to "[..."
        StringBuilder array = new StringBuilder();

        array.append(getElementType());
        for (int i = 0; i < numDimensions; i++) {
            array.append("[]");
        }


        return array.toString();
    }


}
