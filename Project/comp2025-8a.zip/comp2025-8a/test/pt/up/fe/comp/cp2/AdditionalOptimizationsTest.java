package pt.up.fe.comp.cp2;

import org.junit.Test;
import pt.up.fe.comp.CpUtils;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.comp2025.ConfigOptions;
import pt.up.fe.specs.util.SpecsIo;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Additional tests for optimization passes.
 * Tests constant propagation, constant folding, and register allocation with more complex cases.
 */
public class AdditionalOptimizationsTest {

    private static final String BASE_PATH = "pt/up/fe/comp/cp2/optimizations/";

    static OllirResult getOllirResult(String filename) {
        return CpUtils.getOllirResult(SpecsIo.getResource(BASE_PATH + filename), Collections.emptyMap(), false);
    }

    static OllirResult getOllirResultOpt(String filename) {
        Map<String, String> config = new HashMap<>();
        config.put(ConfigOptions.getOptimize(), "true");

        return CpUtils.getOllirResult(SpecsIo.getResource(BASE_PATH + filename), config, true);
    }

    static OllirResult getOllirResultRegalloc(String filename, int maxRegs) {
        Map<String, String> config = new HashMap<>();
        config.put(ConfigOptions.getRegister(), Integer.toString(maxRegs));

        return CpUtils.getOllirResult(SpecsIo.getResource(BASE_PATH + filename), config, true);
    }

    static OllirResult getOllirResultBothOpt(String filename, int maxRegs) {
        Map<String, String> config = new HashMap<>();
        config.put(ConfigOptions.getOptimize(), "true");
        config.put(ConfigOptions.getRegister(), Integer.toString(maxRegs));

        return CpUtils.getOllirResult(SpecsIo.getResource(BASE_PATH + filename), config, true);
    }

    /**
     * Tests constant propagation with branching logic (if/else).
     * Verifies that constants are properly propagated in different branches.
     */
    @Test
    public void constPropWithBranching() {
        String filename = "const_prop_fold/PropWithBranching.jmm";

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultOpt(filename);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "conditional");
        CpUtils.assertLiteralCount("10", method, optimized, 2);
    }

    /**
     * Tests constant propagation with nested loops.
     * Verifies that constants are correctly identified and propagated.
     */
    @Test
    public void constPropWithNestedLoops() {
        String filename = "const_prop_fold/PropWithNestedLoops.jmm";

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultOpt(filename);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "nestedLoops");
        CpUtils.assertLiteralCount("5", method, optimized, 3);
    }

    /**
     * Tests constant folding with more complex expressions.
     * Verifies that expressions like (2*3)+(4*5) are evaluated to 26.
     */
    @Test
    public void complexConstantFolding() {
        String filename = "const_prop_fold/ComplexFolding.jmm";

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultOpt(filename);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "complexExpression");
        CpUtils.assertFindLiteral("26", method, optimized);
    }

    /**
     * Tests constant propagation with method parameters.
     * Constants assigned to parameters should be propagated correctly.
     */
    @Test
    public void constPropWithParameters() {
        String filename = "const_prop_fold/PropWithParameters.jmm";

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultOpt(filename);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "withParams");
        CpUtils.assertFindLiteral("7", method, optimized);
    }

    /**
     * Tests constant propagation and folding when variable values are reassigned.
     * Only the last assigned value should propagate after the assignment.
     */
    @Test
    public void constPropWithReassignment() {
        String filename = "const_prop_fold/PropWithReassignment.jmm";

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultOpt(filename);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "reassignVars");
        CpUtils.assertFindLiteral("30", method, optimized);
    }

    /**
     * Tests register allocation with variables that have overlapping lifetimes.
     * Ensures that variables with overlapping lifetimes get different registers.
     */
    @Test
    public void regAllocOverlapping() {
        String filename = "reg_alloc/regalloc_overlapping.jmm";
        int configMaxRegs = 2;

        OllirResult optimized = getOllirResultRegalloc(filename, configMaxRegs);

        var method = CpUtils.getMethod(optimized, "overlappingVars");
        var varTable = method.getVarTable();

        var aReg = varTable.get("a").getVirtualReg();
        var bReg = varTable.get("b").getVirtualReg();

        CpUtils.assertNotEquals("Variables with overlapping lifetimes should have different registers",
                aReg, bReg, optimized);
    }

    /**
     * Tests register allocation with a method containing a large number of variables.
     * Verifies that the algorithm correctly reuses registers when possible.
     */
    @Test
    public void regAllocManyVariables() {
        String filename = "reg_alloc/regalloc_many_vars.jmm";
        int configMaxRegs = 3;

        OllirResult optimized = getOllirResultRegalloc(filename, configMaxRegs);

        var method = CpUtils.getMethod(optimized, "manyLocalVars");
        int actualNumReg = CpUtils.countRegisters(method);

        CpUtils.assertTrue("Expected no more than " + configMaxRegs + " registers to be used, found " + actualNumReg,
                actualNumReg <= configMaxRegs, optimized);
    }

    /**
     * Tests combining both optimizations (constant propagation and register allocation).
     * Verifies that both optimizations work well together.
     */
    @Test
    public void combinedOptimizations() {
        String filename = "const_prop_fold/PropAndFoldingSimple.jmm";
        int configMaxRegs = 2;

        OllirResult original = getOllirResult(filename);
        OllirResult optimized = getOllirResultBothOpt(filename, configMaxRegs);

        CpUtils.assertNotEquals("Expected code to change after optimization",
                original.getOllirCode(), optimized.getOllirCode(),
                optimized);

        var method = CpUtils.getMethod(optimized, "main");
        CpUtils.assertFindLiteral("15", method, optimized);

        int actualNumReg = CpUtils.countRegisters(method);
        CpUtils.assertTrue("Expected no more than " + configMaxRegs + " registers to be used, found " + actualNumReg,
                actualNumReg <= configMaxRegs, optimized);
    }
}