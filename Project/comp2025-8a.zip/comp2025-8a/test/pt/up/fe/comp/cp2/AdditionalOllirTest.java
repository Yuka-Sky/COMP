package pt.up.fe.comp.cp2;

import org.junit.Test;
import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.*;
import pt.up.fe.comp.CpUtils;
import pt.up.fe.comp.TestUtils;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.specs.util.SpecsIo;
import org.specs.comp.ollir.ClassUnit;
import org.specs.comp.ollir.Method;
import org.specs.comp.ollir.OperationType;
import java.util.stream.Collectors;
import pt.up.fe.comp.jmm.analysis.table.Type;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;

public class AdditionalOllirTest {

    static OllirResult getOllirResult(String filename) {
        return TestUtils.optimize(SpecsIo.getResource("pt/up/fe/comp/cp2/ollir/" + filename));
    }

    @Test
    public void Arithmetic_Subtraction() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_sub.jmm");

        var method = CpUtils.getMethod(ollirResult, "foo");

        CpUtils.assertHasOperation(OperationType.SUB, method, ollirResult);
    }

    @Test
    public void Arithmetic_Multiplication() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_mul.jmm");

        var method = CpUtils.getMethod(ollirResult, "foo");

        CpUtils.assertHasOperation(OperationType.MUL, method, ollirResult);
    }

    @Test
    public void Arithmetic_SimpleOr() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_or.jmm");
        var method = CpUtils.getMethod(ollirResult, "main");
        var numBranches = CpUtils.getInstructions(CondBranchInstruction.class, method).size();

        CpUtils.assertTrue("Expected at least 2 branches, found " + numBranches, numBranches >= 2, ollirResult);
    }

    @Test
    public void Arithmetic_Division() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_div.jmm");

        var method = CpUtils.getMethod(ollirResult, "foo");

        CpUtils.assertHasOperation(OperationType.DIV, method, ollirResult);
    }

    @Test
    public void Arithmetic_GreaterThan() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_greater.jmm");

        var method = CpUtils.getMethod(ollirResult, "main");

        CpUtils.assertHasOperation(OperationType.GTH, method, ollirResult);
    }

    @Test
    public void Arithmetic_Equals() {
        var ollirResult = getOllirResult("arithmetic/Arithmetic_equals.jmm");

        var method = CpUtils.getMethod(ollirResult, "main");

        CpUtils.assertHasOperation(OperationType.EQ, method, ollirResult);
    }

    @Test
    public void ControlFlow_NestedIf() {
        var result = getOllirResult("control_flow/NestedIfStat.jmm");

        var method = CpUtils.getMethod(result, "func");

        var branches = CpUtils.assertInstExists(CondBranchInstruction.class, method, result);
        CpUtils.assertTrue("Number of branches at least 2", branches.size() >= 2, result);

        var gotos = CpUtils.assertInstExists(GotoInstruction.class, method, result);
        CpUtils.assertTrue("Has at least 2 gotos", gotos.size() >= 2, result);
    }

    @Test
    public void ControlFlow_IfInWhile() {
        var result = getOllirResult("control_flow/IfInWhileStat.jmm");

        var method = CpUtils.getMethod(result, "func");

        var branches = CpUtils.assertInstExists(CondBranchInstruction.class, method, result);
        CpUtils.assertTrue("Number of branches at least 2", branches.size() >= 2, result);

        var gotos = CpUtils.assertInstExists(GotoInstruction.class, method, result);
        CpUtils.assertTrue("Has at least 1 goto", gotos.size() >= 1, result);
    }

    @Test
    public void ObjectCreation() {
        var result = getOllirResult("objects/ObjectCreation.jmm");

        var method = CpUtils.getMethod(result, "func");

        var news = CpUtils.assertInstExists(NewInstruction.class, method, result);
        CpUtils.assertTrue("Has at least one new object instruction", news.size() >= 1, result);
    }

    @Test
    public void FieldAccess() {
        var result = getOllirResult("objects/FieldAccess.jmm");
        var method = CpUtils.getMethod(result, "func");

        var getFieldInstructions = CpUtils.getInstructions(GetFieldInstruction.class, method);
        boolean hasFieldAccess = !getFieldInstructions.isEmpty();

        if (!hasFieldAccess) {
            List<Instruction> instructions = method.getInstructions();
            for (Instruction inst : instructions) {
                if (inst instanceof AssignInstruction) {
                    AssignInstruction assign = (AssignInstruction) inst;
                    String rhsString = assign.getRhs().toString().toLowerCase();
                    if (rhsString.contains("getfield")) {
                        hasFieldAccess = true;
                        break;
                    }
                }

                String instString = inst.toString().toLowerCase();
                if (instString.contains("getfield")) {
                    hasFieldAccess = true;
                    break;
                }
            }
        }

        CpUtils.assertTrue("Has at least one field access (getfield operation)", hasFieldAccess, result);
    }

    private List<Element> getAllElements(Instruction inst) {
        List<Element> elements = new ArrayList<>();

        if (inst instanceof AssignInstruction) {
            AssignInstruction assign = (AssignInstruction) inst;
            elements.add(assign.getDest());
            elements.addAll(getAllElements(assign.getRhs()));
        } else if (inst instanceof BinaryOpInstruction) {
            BinaryOpInstruction binOp = (BinaryOpInstruction) inst;
            elements.addAll(binOp.getOperands());
        } else if (inst instanceof UnaryOpInstruction) {
            UnaryOpInstruction unaryOp = (UnaryOpInstruction) inst;
            elements.add(unaryOp.getOperand());
        } else if (inst instanceof CallInstruction) {
            CallInstruction call = (CallInstruction) inst;
            elements.addAll(call.getOperands());
        }

        return elements;
    }

    private boolean isFieldAccess(Element element) {
        // Check if this element represents a field access based on its structure
        // This is a simplified check - in a real implementation, we would look for patterns
        // that indicate field access like object.field
        return element.toString().contains("OBJECTFIELD") ||
                element.toString().contains("field access") ||
                element.toString().contains("putfield") ||
                element.toString().contains("getfield");
    }

    @Test
    public void FieldAssignment() {
        var result = getOllirResult("objects/FieldAssignment.jmm");
        var method = CpUtils.getMethod(result, "func");

        var putFieldInstructions = CpUtils.getInstructions(PutFieldInstruction.class, method);
        boolean hasFieldAssignment = !putFieldInstructions.isEmpty();

        if (!hasFieldAssignment) {
            List<Instruction> instructions = method.getInstructions();
            for (Instruction inst : instructions) {
                String instString = inst.toString().toLowerCase();
                if (instString.contains("putfield")) {
                    hasFieldAssignment = true;
                    break;
                }
            }
        }

        CpUtils.assertTrue("Has at least one field assignment (putfield operation)", hasFieldAssignment, result);
    }

    // Helper method to determine if an Element is a field access
    private boolean isFieldAccess2(Element elem) {
        if (elem instanceof Operand) {
            Operand operand = (Operand) elem;
            String name = operand.getName();

            if (!name.startsWith("$") && !name.contains("tmp") && !name.equals("this")) {
                return true;
            }
        }

        return false;
    }

    @Test
    public void ThisExpression() {
        var result = getOllirResult("objects/ThisExpression.jmm");

        var method = CpUtils.getMethod(result, "func");

        var calls = CpUtils.assertInstExists(CallInstruction.class, method, result);

        boolean hasThisCall = false;
        for (CallInstruction call : calls) {
            Element caller = call.getCaller();
            if (caller instanceof LiteralElement) {
                LiteralElement literalCaller = (LiteralElement) caller;
                if (literalCaller.getLiteral().equals("this")) {
                    hasThisCall = true;
                    break;
                }
            } else if (caller instanceof Operand) {
                Operand operandCaller = (Operand) caller;
                if (operandCaller.getName().equals("this")) {
                    hasThisCall = true;
                    break;
                }
            }
        }

        CpUtils.assertTrue("Has at least one method call on 'this'", hasThisCall, result);
    }

    @Test
    public void MethodOverloading() {
        var result = getOllirResult("methods/MethodOverloading.jmm");

        ClassUnit classUnit = result.getOllirClass();
        var methodName = "foo";
        var methods = classUnit.getMethods().stream()
                .filter(method -> method.getMethodName().equals(methodName))
                .collect(Collectors.toList());

        CpUtils.assertTrue("Has at least two methods with the same name", methods.size() >= 2, result);

        boolean hasDifferentParams = false;
        for (int i = 0; i < methods.size(); i++) {
            for (int j = i + 1; j < methods.size(); j++) {
                if (methods.get(i).getParams().size() != methods.get(j).getParams().size()) {
                    hasDifferentParams = true;
                    break;
                }

                for (int p = 0; p < methods.get(i).getParams().size(); p++) {
                    if (!methods.get(i).getParams().get(p).getType().toString()
                            .equals(methods.get(j).getParams().get(p).getType().toString())) {
                        hasDifferentParams = true;
                        break;
                    }
                }
            }
        }

        CpUtils.assertTrue("Methods with the same name have different parameters", hasDifferentParams, result);
    }

    @Test
    public void MethodCallChaining() {
        var result = getOllirResult("methods/MethodCallChaining.jmm");

        var method = CpUtils.getMethod(result, "func");

        var calls = CpUtils.assertInstExists(CallInstruction.class, method, result);
        CpUtils.assertTrue("Has at least two method calls", calls.size() >= 2, result);

        boolean hasMultipleCalls = calls.size() >= 2;

        CpUtils.assertTrue("Has multiple method calls", hasMultipleCalls, result);
    }

    @Test
    public void NestedExpressions() {
        var result = getOllirResult("expressions/NestedExpressions.jmm");

        var method = CpUtils.getMethod(result, "func");

        int binOpCount = countBinaryOpsInMethod(method);

        CpUtils.assertTrue("Has at least two binary operations", binOpCount >= 2, result);
    }

    // Helper method to count binary operations in a method
    private int countBinaryOpsInMethod(Method method) {
        int count = 0;
        for (Instruction inst : method.getInstructions()) {
            if (inst instanceof AssignInstruction) {
                String instString = inst.toString();

                count += countOccurrences(instString, OperationType.ADD.toString());
                count += countOccurrences(instString, OperationType.SUB.toString());
                count += countOccurrences(instString, OperationType.MUL.toString());
                count += countOccurrences(instString, OperationType.DIV.toString());
                count += countOccurrences(instString, OperationType.ANDB.toString());
                count += countOccurrences(instString, OperationType.ORB.toString());
                count += countOccurrences(instString, OperationType.LTH.toString());
                count += countOccurrences(instString, OperationType.GTH.toString());
                count += countOccurrences(instString, OperationType.EQ.toString());
            }
        }
        return count;
    }

    // Helper method to count occurrences of a substring in a string
    private int countOccurrences(String str, String subStr) {
        int count = 0;
        int lastIndex = 0;

        while (lastIndex != -1) {
            lastIndex = str.indexOf(subStr, lastIndex);
            if (lastIndex != -1) {
                count++;
                lastIndex += subStr.length();
            }
        }

        return count;
    }

    @Test
    public void varArgsTest() {
        var result = getOllirResult("varargs/VarArgsTest.jmm");
        System.out.println("---------------------- OLLIR ----------------------");
        System.out.println(result.getOllirCode());
        System.out.println("---------------------- OLLIR ----------------------");

        var method = CpUtils.getMethod(result, "processNumbers");

        CpUtils.assertTrue("Method should have parameters", method.getParams().size() > 0, result);

        var lastParam = method.getParams().get(method.getParams().size() - 1);
        var lastParamType = lastParam.getType();

        boolean isArray = CpUtils.toString(lastParamType).contains("[]");
        CpUtils.assertTrue("Last parameter should be an array type", isArray, result);

        var mainMethod = CpUtils.getMethod(result, "main");
        assertNotNull("Could not find main method", mainMethod);

        var calls = CpUtils.getInstructions(CallInstruction.class, mainMethod);

        var processNumbersCalls = calls.stream()
                .filter(call -> {
                    if (call instanceof CallInstruction) {
                        return "processNumbers".equals(((CallInstruction) call).getMethodName());
                    }
                    return false;
                })
                .collect(Collectors.toList());

        CpUtils.assertEquals("Should have 3 calls to processNumbers", 3, processNumbersCalls.size(), result);

        boolean hasArrayCreations = result.getOllirCode().contains("new(int).array");
        CpUtils.assertTrue("Should have array creation for varargs", hasArrayCreations, result);
    }

    @Test
    public void comprehensiveVarArgsTest() {
        var result = getOllirResult("varargs/VarArgsTest.jmm");
        System.out.println(result.getOllirCode());

        var mainMethod = CpUtils.getMethod(result, "main");
        assertNotNull("Could not find main method", mainMethod);        // Instead of trying to use getMethodName() which may fail with NoSuchElementException,
        // we'll directly check the OLLIR code for the expected invokevirtual calls
        String ollirCodeStr = result.getOllirCode();
        int processNumbersCallCount = 0;
        
        // Count all occurrences of processNumbers method calls
        int index = ollirCodeStr.indexOf("invokevirtual(test.VarArgsTest, \"processNumbers\"");
        while (index != -1) {
            processNumbersCallCount++;
            index = ollirCodeStr.indexOf("invokevirtual(test.VarArgsTest, \"processNumbers\"", index + 1);
        }
        
        CpUtils.assertEquals("Should have 3 calls to processNumbers", 3, processNumbersCallCount, result);

        String ollirCode = result.getOllirCode();

        CpUtils.assertTrue("Should create empty array for no-args call",
                ollirCode.contains("new(int).array.0"), result);

        CpUtils.assertTrue("Should create appropriate sized array for multiple args",
                ollirCode.contains("new(int).array.5"), result);

        boolean hasArrayAssignments = ollirCode.matches(".*\\[.*\\]\\.i32\\s*:=\\.i32.*");
        CpUtils.assertTrue("Should have array element assignments for varargs array",
                hasArrayAssignments, result);

        CpUtils.assertTrue("Should use existing array in third method call",
                ollirCode.contains("myArray"), result);
    }
}