package pt.up.fe.comp2025.analysis.passes;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.analysis.AnalysisVisitor;

import java.util.List;

public class VarargsPositionCheck extends AnalysisVisitor {

    @Override
    protected void buildVisitor() {
        addVisit("MethodDecl", this::visitMethodDecl);
    }

    private Void visitMethodDecl(JmmNode methodDecl, SymbolTable table) {
        String methodName = methodDecl.get("name");

        JmmNode paramsNode = null;
        for (JmmNode child : methodDecl.getChildren()) {
            if (child.getKind().equals("MethodParams")) {
                paramsNode = child;
                break;
            }
        }

        if (paramsNode == null) return null; // No parameters

        List<JmmNode> params = paramsNode.getChildren();
        boolean foundVarargs = false;

        for (int i = 0; i < params.size(); i++) {
            JmmNode param = params.get(i);
            JmmNode typeNode = null;

            // Find the type node
            for (JmmNode child : param.getChildren()) {
                if (child.getKind().equals("Type")) {
                    typeNode = child;
                    break;
                }
            }

            if (typeNode != null && typeNode.hasAttribute("isVarArgs") &&
                    typeNode.getBoolean("isVarArgs", false)) {

                foundVarargs = true;

                // Check if this is the last parameter
                if (i != params.size() - 1) {
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            param.getLine(),
                            param.getColumn(),
                            "Varargs parameter must be the last parameter in method '" + methodName + "'",
                            null
                    ));
                }
            } else if (foundVarargs) {
                // Found a regular parameter after varargs -> error
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        param.getLine(),
                        param.getColumn(),
                        "Regular parameter cannot appear after varargs parameter in method '" + methodName + "'",
                        null
                ));
            }
        }

        return null;
    }
}