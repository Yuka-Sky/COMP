package pt.up.fe.comp2025.symboltable;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.ast.Kind;
import pt.up.fe.comp2025.ast.TypeUtils;
import pt.up.fe.specs.util.SpecsCheck;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static pt.up.fe.comp2025.ast.Kind.*;

public class JmmSymbolTableBuilder {

    private List<Report> reports;

    public List<Report> getReports() {
        return reports;
    }

    private static Report newError(JmmNode node, String message) {
        return Report.newError(
                Stage.SEMANTIC,
                node.getLine(),
                node.getColumn(),
                message,
                null);
    }

    public JmmSymbolTable build(JmmNode root) {

        reports = new ArrayList<>();

        var classDecls = root.getChildren(Kind.CLASS_DECL); // Retrieve class declarations
        if (classDecls.isEmpty()) {
            throw new RuntimeException("No class declaration found in the root node.");
        }
        var classDecl = classDecls.get(0); // Assuming single-class support for now instead of var classDecl = root.getChild(0);

        SpecsCheck.checkArgument(Kind.CLASS_DECL.check(classDecl), () -> "Expected a class declaration: " + classDecl);

        String className = classDecl.get("name");
        var fields = buildFields(classDecl);
        var methods = buildMethods(classDecl);
        var returnTypes = buildReturnTypes(classDecl);
        var params = buildParams(classDecl);
        var locals = buildLocals(classDecl);
        var imports = buildImports(root);
        String superClass = classDecl.hasAttribute("extendedClass") ? classDecl.get("extendedClass") : null;

        JmmSymbolTable symbolTable = new JmmSymbolTable(className, superClass, imports, methods, returnTypes, params, locals, fields);

        // After the table has been built, we check varargs
        for (var method : classDecl.getChildren(METHOD_DECL)) {
            var methodName = method.get("name");
            for (var param : method.getChildren(PARAM)) {
                JmmNode typeNode = param.getChild(0);
                if (typeNode.hasAttribute("isVarArgs") && typeNode.getBoolean("isVarArgs", false)) {
                    symbolTable.addVarargsMethod(methodName);
                    break; // Only need to find one varargs parameter per method
                }
            }
        }

        return symbolTable;
    }

    private List<String> buildImports(JmmNode root) {
        List<String> imports = new ArrayList<>();
        for (var importNode : root.getChildren(IMPORT_DECL)) {
            // Get the base name (without brackets)
            String baseName = importNode.get("name").replaceAll("[\\[\\]]", "").trim();
            if (importNode.hasAttribute("nameImport") &&
                    !importNode.get("nameImport").equals("[]")) {
                // Create a full path with nameImport parts
                String nameImports = importNode.get("nameImport").replaceAll("[\\[\\]]", "").trim();
                imports.add(baseName + "." + nameImports);
            } else {
                imports.add(baseName);
            }
        }
        return imports;
    }

    private List<Symbol> buildFields(JmmNode classDecl) {
        List<Symbol> fields = new ArrayList<>();
        for (var fieldNode : classDecl.getChildren(VAR_DECL)) {
            JmmNode typeNode = fieldNode.getChild(0);
            Type fieldType = TypeUtils.convertType(typeNode);
            String fieldName = fieldNode.get("name");
            fields.add(new Symbol(fieldType, fieldName));
        }
        System.out.println("Extracted fields: " + fields);
        return fields;
    }

    private Map<String, Type> buildReturnTypes(JmmNode classDecl) {
        Map<String, Type> map = new HashMap<>();

        for (var method : classDecl.getChildren(METHOD_DECL)) {
            var name = method.get("name");
            var returnTypeNode = method.getChild(0);

            Type returnType;
            if (returnTypeNode.getNumChildren() > 0) {
                // Has a child: regular type
                returnType = TypeUtils.convertType(returnTypeNode.getChild(0));
            } else {
                // No children: must be void
                returnType = new Type("void", false);
            }

            map.put(name, returnType);
        }

        return map;
    }

    private Map<String, List<Symbol>> buildParams(JmmNode classDecl) {
        Map<String, List<Symbol>> map = new HashMap<>();

        for (var method : classDecl.getChildren(METHOD_DECL)) {
            var name = method.get("name");
            List<Symbol> params = new ArrayList<>();

            for (var param : method.getChildren(PARAM)) {
                JmmNode typeNode = param.getChild(0);

                Type paramType;

                // Check if this is a varargs parameter (isVarArgs attribute would be set by the parser)
                if (typeNode.hasAttribute("isVarArgs") && typeNode.getBoolean("isVarArgs", false)) {
                    // For varargs, ensure it's marked as an array type
                    paramType = new Type(typeNode.get("name"), true); // Force array type for varargs
                    System.out.println("Found varargs parameter: " + param.get("name") + " of type " + paramType.getName() + "[]");
                } else {
                    // Regular parameter
                    paramType = TypeUtils.convertType(typeNode);
                }

                String paramName = param.get("name");
                params.add(new Symbol(paramType, paramName));
            }

            map.put(name, params);
        }

        return map;
    }

    private Map<String, List<Symbol>> buildLocals(JmmNode classDecl) {

        var map = new HashMap<String, List<Symbol>>();

        for (var method : classDecl.getChildren(METHOD_DECL)) {
            var name = method.get("name");
            var locals = method.getChildren(VAR_DECL).stream()
                    .map(varDecl -> {
                        JmmNode typeNode = varDecl.getChild(0);
                        Type varDeclType = TypeUtils.convertType(typeNode);
                        String varDeclName = varDecl.get("name");
                        System.out.println("LOCAL: " + varDeclName + " : " + varDeclType.getName() + "[]? " + varDeclType.isArray());
                        return new Symbol(varDeclType, varDeclName);
                    })
                    .toList();
            map.put(name, locals);
        }
        return map;
    }

    private List<String> buildMethods(JmmNode classDecl) {
        List<String> methods = new ArrayList<>();

        for (var method : classDecl.getChildren(METHOD_DECL)) {
            var name = method.get("name");
            methods.add(name);
        }
        return methods;
    }
}
