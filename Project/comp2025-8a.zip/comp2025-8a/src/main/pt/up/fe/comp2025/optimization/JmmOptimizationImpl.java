package pt.up.fe.comp2025.optimization;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import pt.up.fe.comp.jmm.analysis.JmmSemanticsResult;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.ollir.JmmOptimization;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.ReportType;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.ConfigOptions;
import pt.up.fe.comp2025.ast.TypeUtils;
import pt.up.fe.specs.util.SpecsCollections;

public class JmmOptimizationImpl implements JmmOptimization {

    @Override
    public OllirResult toOllir(JmmSemanticsResult semanticsResult) {
        var visitor = new OllirGeneratorVisitor(semanticsResult.getSymbolTable());

        // Visit the AST and obtain OLLIR code
        var ollirCode = visitor.visit(semanticsResult.getRootNode(), null);

        // Returns the OLLIR result with the generated code
        // and reports list is empty since we assume successful generation
        return new OllirResult(semanticsResult, ollirCode, Collections.emptyList());
    }

    @Override
    public JmmSemanticsResult optimize(JmmSemanticsResult semanticsResult) {
        // Check if optimization is enabled
        boolean optimizationEnabled = isOptimizationEnabled(semanticsResult.getConfig());
        if (!optimizationEnabled) {
            // If not, return as unchanged
            return semanticsResult;
        }

        // Store reports related to the optimization process
        List<Report> reports = new ArrayList<>();
        JmmNode rootNode = semanticsResult.getRootNode();

        try {
            // Create TypeUtils for const prop
            TypeUtils typeUtils = new TypeUtils(semanticsResult.getSymbolTable());

            // Track total optimizations of each type
            int totalFoldings = 0;
            int totalPropagations = 0;

            // Continue optimizing until no more changes are made (fixed point)
            boolean changesApplied;
            int iterations = 0;
            final int MAX_ITERATIONS = 100; // Safety limit to prevent infinite loops

            do {
                iterations++;
                changesApplied = false;

                // Step 1: Apply constant folding
                ConstantFolding constFold = new ConstantFolding(typeUtils);
                constFold.visit(rootNode, Collections.emptyMap());
                int foldingCount = constFold.getFoldingCount();
                totalFoldings += foldingCount;

                // Track if changes were made
                changesApplied = changesApplied || (foldingCount > 0);

                // Step 2: Apply constant propagation
                ConstantPropagation constProp = new ConstantPropagation(typeUtils);
                constProp.visit(rootNode, Collections.emptyMap());
                int propagationCount = constProp.getReplacementCount();
                totalPropagations += propagationCount;

                // Track if changes were made
                changesApplied = changesApplied || (propagationCount > 0);

                // Add iteration report if changes were made
                if (changesApplied) {
                    Report iterReport = new Report(ReportType.LOG, Stage.OPTIMIZATION, -1,
                            "Optimization iteration " + iterations + ": " +
                                    foldingCount + " foldings, " + propagationCount + " propagations");
                    reports.add(iterReport);
                }

                // Exit if we've reached our safety limit
                if (iterations >= MAX_ITERATIONS) {
                    Report limitReport = new Report(ReportType.WARNING, Stage.OPTIMIZATION, -1,
                            "Reached maximum iterations (" + MAX_ITERATIONS + "); optimization may not be complete");
                    reports.add(limitReport);
                    break;
                }

            } while (changesApplied); // Continue until no changes are made

            // Summary reports
            if (totalFoldings > 0) {
                Report foldingReport = new Report(ReportType.LOG, Stage.OPTIMIZATION, -1,
                        "Total Constant Folding optimizations: " + totalFoldings + " expressions folded");
                reports.add(foldingReport);
            }

            if (totalPropagations > 0) {
                Report propReport = new Report(ReportType.LOG, Stage.OPTIMIZATION, -1,
                        "Total Constant Propagation optimizations: " + totalPropagations + " replacements made");
                reports.add(propReport);
            }

            Report iterationsReport = new Report(ReportType.LOG, Stage.OPTIMIZATION, -1,
                    "Optimization completed in " + iterations + " iterations, reaching fixed point");
            reports.add(iterationsReport);

            // If no optimizations were applied at all, add an informative report
            if (totalFoldings == 0 && totalPropagations == 0) {
                Report noOptReport = new Report(ReportType.LOG, Stage.OPTIMIZATION, -1,
                        "No optimizations were applied (no optimization opportunities found)");
                reports.add(noOptReport);
            }

        } catch (Exception e) {
            // Report any errors during optimization
            Report report = new Report(ReportType.ERROR, Stage.OPTIMIZATION, -1,
                    "Error during optimization: " + e.getMessage());
            reports.add(report);
            e.printStackTrace();
        }

        List<Report> allReports = SpecsCollections.concat(semanticsResult.getReports(), reports);

        // New JmmSemanticsResult with the updated AST
        return new JmmSemanticsResult(rootNode, semanticsResult.getSymbolTable(),
                allReports, semanticsResult.getConfig());
    }

    /**
     * Checks if optimization is enabled in the compiler configuration.
     * Looks for the "-o" flag in the configuration.
     */
    private boolean isOptimizationEnabled(Map<String, String> config) {
        if (config == null) {
            return false;
        }

        // Check for optimization flag
        return config.containsKey("-o") ||
                "true".equalsIgnoreCase(config.getOrDefault("optimize", "false")) ||
                "true".equalsIgnoreCase(config.getOrDefault("-o", "false"));
    }



    @Override
    public OllirResult optimize(OllirResult ollirResult) {
        RegisterAllocator registerAllocator = new RegisterAllocator();
        List<Report> reportList = new ArrayList<>(ollirResult.getReports());
        int regAllocOption = ConfigOptions.getRegisterAllocation(ollirResult.getConfig());

        if (regAllocOption != -1) {
            System.out.println("Starting register allocation with " +
                    (regAllocOption == 0 ? "minimal" : regAllocOption) + " registers...");

            List<Report> allocationReports = registerAllocator.allocateRegisters(ollirResult, regAllocOption);
            reportList.addAll(allocationReports);

            if (allocationReports.isEmpty()) {
                System.out.println("Register allocation completed without errors!");
            } else {
                System.out.println("Issues detected during register allocation. Check reports for more details.");
            }
        }

        return ollirResult;
    }

}
