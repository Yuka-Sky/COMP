package pt.up.fe.comp2025.analysis.passes;

import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.analysis.AnalysisVisitor;
import pt.up.fe.comp2025.ast.Kind;
import pt.up.fe.comp2025.ast.TypeUtils;

/**
 * Checks if conditions in if/while statements are boolean.
 */
public class ConditionTypeCheck extends TypeCheckVisitor {

    @Override
    public void buildVisitor() {
        addVisit(Kind.METHOD_DECL, this::visitMethodDecl);
        addVisit("IfElseStmt", this::visitIfStmt);
        addVisit("WhileStmt", this::visitWhileStmt);
    }

    private Void visitMethodDecl(JmmNode method, SymbolTable table) {
        currentMethod = method.get("name");
        return null;
    }

    private Void visitIfStmt(JmmNode ifStmt, SymbolTable table) {
        return checkCondition(ifStmt.getChild(0), table, "if statement");
    }

    private Void visitWhileStmt(JmmNode whileStmt, SymbolTable table) {
        return checkCondition(whileStmt.getChild(0), table, "while statement");
    }

    private Void checkCondition(JmmNode conditionExpr, SymbolTable table, String statementType) {
        Type conditionType = typeUtils.getExprType(conditionExpr);

        if (!conditionType.getName().equals("boolean")) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    conditionExpr.getLine(),
                    conditionExpr.getColumn(),
                    "Condition in " + statementType + " must be boolean, found " + conditionType.print(),
                    null
            ));
        }
        return null;
    }
}