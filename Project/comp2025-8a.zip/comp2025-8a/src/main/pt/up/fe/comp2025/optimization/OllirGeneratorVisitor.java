package pt.up.fe.comp2025.optimization;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.AJmmVisitor;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp2025.ast.TypeUtils;

import java.util.List;
import java.util.stream.Collectors;

import static pt.up.fe.comp2025.ast.Kind.*;

/**
 * Generates OLLIR code from JmmNodes that are not expressions.
 */
public class OllirGeneratorVisitor extends AJmmVisitor<Void, String> {

    private static final String SPACE = " ";
    private static final String ASSIGN = ":=";
    private final String END_STMT = ";\n";
    private final String NL = "\n";
    private final String L_BRACKET = " {\n";
    private final String R_BRACKET = "}\n";


    private final SymbolTable table;

    private final TypeUtils types;
    private final OptUtils ollirTypes;


    private final OllirExprGeneratorVisitor exprVisitor;

    public OllirGeneratorVisitor(SymbolTable table) {
        this.table = table;
        this.types = new TypeUtils(table);
        this.ollirTypes = new OptUtils(types);
        exprVisitor = new OllirExprGeneratorVisitor(table);
    }


    @Override
    protected void buildVisitor() {

        addVisit(PROGRAM, this::visitProgram);
        addVisit(VAR_DECL, this::visitVarDecl);
        addVisit(CLASS_DECL, this::visitClass);
        addVisit(METHOD_DECL, this::visitMethodDecl);
        addVisit(PARAM, this::visitParam);
        addVisit("ReturnStmt", this::visitReturn);
        addVisit(ASSIGN_STMT, this::visitAssignStmt);
        addVisit(NESTED_STMT, this::visitNestedStmt);
        addVisit(ASSERT_STMT, this::visitAssertStmt);
        addVisit(IF_ELSE_STMT, this::visitIfElseStmt);
        addVisit(WHILE_STMT, this::visitWhileStmt);
        addVisit(SINGLE_STMT, this::visitSingleStmt);
        addVisit(IMPORT_DECL, this::visitImportDecl);
        setDefaultVisit(this::defaultVisit);
    }

    private boolean isClassField(String varName, String methodName) {
        // If we're in a method context, check parameters and local variables first
        if (methodName != null && !methodName.isEmpty()) {
            // Check parameters
            List<Symbol> parameters = table.getParameters(methodName);
            if (parameters != null) {
                for (Symbol param : parameters) {
                    if (param.getName().equals(varName)) {
                        System.out.println("Variable " + varName + " is a parameter in " + methodName);
                        return false; // It's a parameter
                    }
                }
            }

            // Check local variables
            List<Symbol> localVars = table.getLocalVariables(methodName);
            if (localVars != null) {
                for (Symbol localVar : localVars) {
                    if (localVar.getName().equals(varName)) {
                        System.out.println("Variable " + varName + " is a local variable in " + methodName);
                        return false; // It's a local variable
                    }
                }
            }
        }

        // Check if it's a field
        List<Symbol> fields = table.getFields();
        if (fields != null) {
            for (Symbol field : fields) {
                if (field.getName().equals(varName)) {
                    System.out.println("Variable " + varName + " is a class field");
                    return true; // It's a field
                }
            }
        }

        // Default behavior - if we can't determine, assume it's not a field
        System.out.println("Variable " + varName + " not identified, assuming local");
        return false;
    }


    // Helper method to get the current method name from a node
    private String getCurrentMethodName(JmmNode node) {
        // Traverse up until we find a MethodDecl node
        JmmNode current = node;
        while (current != null && !current.getKind().equals("MethodDecl")) {
            current = current.getParent();
        }

        if (current != null && current.getKind().equals("MethodDecl")) {
            return current.get("name");
        }

        return null; // Not in a method context
    }

    private String visitImportDecl(JmmNode node, Void unused) {
        // Import declarations are represented in OLLIR but kept in the symbol table
        // (they don't generate code in the method body)
        return "";
    }


    private String visitVarDecl(JmmNode node, Void unused) {
        // Variable declarations in OLLIR don't generate code at the method level,
        // (they're just used during assignments and other operations)
        return "";
    }


    private String visitNestedStmt(JmmNode node, Void unused) {
        // Visit all the statements inside the nested statement block
        StringBuilder code = new StringBuilder();

        for (JmmNode child : node.getChildren()) {
            code.append(visit(child));
        }

        return code.toString();
    }


    private String visitAssertStmt(JmmNode node, Void unused) {

        // array variable (child 0)
        var arrayExpr = exprVisitor.visit(node.getChild(0));

        // index expression (child 1)
        var indexExpr = exprVisitor.visit(node.getChild(1));

        //  value expression (child 2)
        var valueExpr = exprVisitor.visit(node.getChild(2));

        StringBuilder code = new StringBuilder();

        // Appending computations in order
        code.append(arrayExpr.getComputation());
        code.append(indexExpr.getComputation());
        code.append(valueExpr.getComputation());

        // Getting the type of the array elements
        Type arrayType = types.getExprType(node.getChild(0));
        Type elementType = new Type(arrayType.getName(), false); // array dimension is removed
        String elementOllirType = ollirTypes.toOllirType(elementType);

        code.append(arrayExpr.getCode())
                .append("[")
                .append(indexExpr.getCode())
                .append("]")
                .append(elementOllirType)
                .append(SPACE)
                .append(ASSIGN)
                .append(elementOllirType)
                .append(SPACE)
                .append(valueExpr.getCode())
                .append(END_STMT);

        return code.toString();
    }


    private String visitIfElseStmt(JmmNode node, Void unused) {
        var condResult = exprVisitor.visit(node.getChild(0));

        StringBuilder code = new StringBuilder();
        code.append(condResult.getComputation());

        // Get labels for then, else, and end
        String thenLabel = "if_then_" + ollirTypes.nextTemp("lbl");
        String elseLabel = "if_else_" + ollirTypes.nextTemp("lbl");
        String endLabel = "if_end_" + ollirTypes.nextTemp("lbl");

        // If condition is true, jump to then label, otherwise fall through to else
        code.append("if (").append(condResult.getCode()).append(") goto ").append(thenLabel).append(END_STMT);
        code.append("goto ").append(elseLabel).append(END_STMT);

        // Then block
        code.append(thenLabel).append(":").append(NL);
        code.append(visit(node.getChild(1)));
        code.append("goto ").append(endLabel).append(END_STMT);

        // Else block
        code.append(elseLabel).append(":").append(NL);
        code.append(visit(node.getChild(2)));

        // End label
        code.append(endLabel).append(":").append(NL);

        return code.toString();
    }


    private String visitWhileStmt(JmmNode node, Void unused) {
        // Get labels for condition, body, and end
        String condLabel = "while_cond_" + ollirTypes.nextTemp("lbl");
        String bodyLabel = "while_body_" + ollirTypes.nextTemp("lbl");
        String endLabel = "while_end_" + ollirTypes.nextTemp("lbl");

        StringBuilder code = new StringBuilder();

        // Start with condition check
        code.append(condLabel).append(":").append(NL);

        // Process the condition expression
        var condResult = exprVisitor.visit(node.getChild(0));
        code.append(condResult.getComputation());

        // If condition is true, jump to body, otherwise end
        code.append("if (").append(condResult.getCode()).append(") goto ").append(bodyLabel).append(END_STMT);
        code.append("goto ").append(endLabel).append(END_STMT);

        // Body
        code.append(bodyLabel).append(":").append(NL);
        code.append(visit(node.getChild(1)));
        code.append("goto ").append(condLabel).append(END_STMT);

        // End label
        code.append(endLabel).append(":").append(NL);

        return code.toString();
    }


    private String visitSingleStmt(JmmNode node, Void unused) {
        var exprResult = exprVisitor.visit(node.getChild(0));

        StringBuilder code = new StringBuilder();
        code.append(exprResult.getComputation());

        // For method calls that return void, we might need to add the statement
        // to call the method rather than just computing the result
        JmmNode expr = node.getChild(0);
        if (expr.getKind().equals("MethodCall") || expr.getKind().equals("StaticMethodCall")) {
            // Already handled in the computation
        } else {
            if (!exprResult.getComputation().contains(exprResult.getCode())) {
                code.append(exprResult.getCode()).append(END_STMT);
            }
        }

        return code.toString();
    }


    private String visitAssignStmt(JmmNode node, Void unused) {
        // Get the right-hand side result
        var rhs = exprVisitor.visit(node.getChild(1));

        StringBuilder code = new StringBuilder();

        // Append the computation for the right-hand side
        code.append(rhs.getComputation());

        // Get the left-hand side node
        var left = node.getChild(0);

        // Handle different types of left-hand expressions
        if (left.getKind().equals("ArrayAccess")) {
            // Array assignment handling
            var arrayVar = exprVisitor.visit(left.getChild(0));
            var indexExpr = exprVisitor.visit(left.getChild(1));

            code.append(arrayVar.getComputation());
            code.append(indexExpr.getComputation());

            Type arrayType = types.getExprType(left.getChild(0));
            Type elementType = new Type(arrayType.getName(), false);
            String elementOllirType = ollirTypes.toOllirType(elementType);

            code.append(arrayVar.getCode())
                    .append("[")
                    .append(indexExpr.getCode())
                    .append("]")
                    .append(elementOllirType)
                    .append(SPACE)
                    .append(ASSIGN)
                    .append(elementOllirType)
                    .append(SPACE)
                    .append(rhs.getCode())
                    .append(END_STMT);
        } else if (left.getKind().equals("VarRefExpr")) {
            // Regular variable assignment
            String varName = left.get("name");
            String currentMethod = getCurrentMethodName(node);

            System.out.println("Assignment to: " + varName + " in method: " + currentMethod);

            boolean isField = isClassField(varName, currentMethod);

            // Get variable type
            Type varType = types.getExprType(left);
            String typeString = ollirTypes.toOllirType(varType);

            if (isField) {
                // Assignment to class field using putfield
                code.append("putfield")
                        .append("(")
                        .append("this")
                        .append(", ")
                        .append(varName).append(typeString)
                        .append(", ")
                        .append(rhs.getCode())
                        .append(")").append(".V")
                        .append(END_STMT);
            } else {
                // Assignment to local variable
                String varCode = varName + typeString;
                code.append(varCode)
                        .append(SPACE)
                        .append(ASSIGN)
                        .append(typeString)
                        .append(SPACE)
                        .append(rhs.getCode())
                        .append(END_STMT);
            }
        }

        return code.toString();
    }


    private String visitReturn(JmmNode node, Void unused) {
        StringBuilder code = new StringBuilder();

        if (node.getNumChildren() > 0) {
            // Getting the expression result
            var expr = exprVisitor.visit(node.getChild(0));
            code.append(expr.getComputation());

            String methodName = getMethodNameFromParent(node);

            // Getting return type
            Type retType = table.getReturnType(methodName);
            if (retType == null) {
                // If return type is not found, default to int
                retType = TypeUtils.newIntType();
            }
            String retOllirType = ollirTypes.toOllirType(retType);

            code.append("ret").append(retOllirType).append(" ")
                    .append(expr.getCode()).append(END_STMT);
        } else {
            // Void return
            code.append("ret.V").append(END_STMT);
        }

        return code.toString();
    }


    private String getMethodNameFromParent(JmmNode node) {
        JmmNode current = node;
        while (current != null && !current.getKind().equals("MethodDecl")) {
            current = current.getParent();
        }

        if (current != null && current.getKind().equals("MethodDecl")) {
            return current.get("name");
        }

        return null; // Not in a method context
    }


    private String visitParam(JmmNode node, Void unused) {
        System.out.println("DEBUG: Param node: " + node);
        System.out.println("DEBUG: Param attributes: " + node.getAttributes());

        if (node.getChildren().isEmpty()) {
            System.err.println("ERROR: Param node has no type child");
            return "error.V";
        }

        JmmNode typeNode = node.getChild(0);
        String paramName = node.get("name");

        boolean isVarArgs = false;

        if (node.hasAttribute("isVarArgs") && node.getBoolean("isVarArgs", false)) {
            isVarArgs = true;
            System.out.println("VarArgs flag found on param node: " + paramName);
        } else if (typeNode.hasAttribute("isVarArgs") && typeNode.getBoolean("isVarArgs", false)) {
            isVarArgs = true;
            // Transfer the flag up to the param node for later use
            node.put("isVarArgs", "true");
            System.out.println("VarArgs flag found on type node and transferred to param: " + paramName);
        }

        // Make sure the param type is properly marked as an array for varargs
        Type paramType = types.convertType(typeNode);

        if (isVarArgs && !paramType.isArray()) {
            paramType = new Type(paramType.getName(), true);
            System.out.println("Converted varargs param to array type: " + paramName);
        }

        return paramName + ollirTypes.toOllirType(paramType);
    }


    private String visitMethodDecl(JmmNode node, Void unused) {
        System.out.println("DEBUG: Method node: " + node);
        System.out.println("DEBUG: Method children: " + node.getChildren().size());
        System.out.println("DEBUG: Method children kinds: " + node.getChildren().stream()
                .map(child -> child.getKind() + (child.hasAttribute("isVarArgs") ? " (isVarArgs)" : ""))
                .collect(Collectors.joining(", ")));

        StringBuilder code = new StringBuilder(".method ");

        boolean isPublic = node.getBoolean("isPublic", false);
        boolean isStatic = node.getBoolean("isStatic", false);

        if (isPublic) {
            code.append("public ");
        }

        if (isStatic) {
            code.append("static ");
        }

        var name = node.get("name");
        code.append(name);

        System.out.println("Processing method: " + name);

        var paramsNode = node.getChildren().stream()
                .filter(child -> child.getKind().equals("MethodParams"))
                .findFirst()
                .orElse(null);

        StringBuilder paramsCode = new StringBuilder();
        if (paramsNode != null) {
            boolean first = true;
            for (var paramNode : paramsNode.getChildren()) {
                if (!first) {
                    paramsCode.append(", ");
                }

                // Check if this parameter is a varargs parameter
                boolean isVarArgs = paramNode.hasAttribute("isVarArgs") &&
                        paramNode.getBoolean("isVarArgs", false);

                String paramStr = visit(paramNode);

                if (isVarArgs) {
                    paramStr = paramStr + ".varargs";
                    System.out.println("Found varargs parameter: " + paramStr);
                }

                paramsCode.append(paramStr);
                first = false;
            }
        } else {
            // If there's no dedicated MethodParams node, look for individual Param nodes
            boolean first = true;
            for (var paramNode : node.getChildren().stream()
                    .filter(child -> child.getKind().equals("Param"))
                    .toList()) {
                if (!first) {
                    paramsCode.append(", ");
                }

                // Same varargs check as above
                boolean isVarArgs = paramNode.hasAttribute("isVarArgs") &&
                        paramNode.getBoolean("isVarArgs", false);

                String paramStr = visit(paramNode);

                if (isVarArgs) {
                    paramStr = paramStr + ".varargs";
                    System.out.println("Found varargs parameter: " + paramStr);
                }

                paramsCode.append(paramStr);
                first = false;
            }
        }

        code.append("(").append(paramsCode).append(")");

        // return type
        Type methodType = table.getReturnType(name);
        if (methodType != null) {
            code.append(ollirTypes.toOllirType(methodType));
        } else {
            // Default to void if not found
            code.append(".V");
        }

        code.append(L_BRACKET);

        // Process local variable declarations
        // Note: Variable declarations in OLLIR should not generate initialization code
        // Variables are only declared in the local variable table, not initialized
        var varDecls = node.getChildren().stream()
                .filter(child -> child.getKind().equals("VarDecl"))
                .toList();

        // Local variables are handled by the OLLIR framework through the variable table
        // No explicit initialization code should be generated for declarations like "int a;"

        // Process all other statement children, including return statements
        var statementNodes = node.getChildren().stream()
                .filter(child -> !child.getKind().equals("VarDecl") &&
                        !child.getKind().equals("Param") &&
                        !child.getKind().equals("ReturnType") &&
                        !child.getKind().equals("MethodParams"))
                .toList();

        for (var stmtNode : statementNodes) {
            String stmtCode = visit(stmtNode);
            if (!stmtCode.isEmpty()) {
                code.append("    ").append(stmtCode);
            }
        }

        // Check if method has an explicit return statement
        boolean hasReturnStmt = node.getChildren().stream()
                .anyMatch(child -> child.getKind().equals("ReturnStmt"));

        // Only add void return for main method if it doesn't have explicit return
        if (!hasReturnStmt && name.equals("main") && 
            (methodType == null || methodType.getName().equals("void"))) {
            code.append("    ret.V").append(END_STMT);
        }

        code.append(R_BRACKET);
        code.append(NL);

        return code.toString();
    }


    private String visitClass(JmmNode node, Void unused) {
        StringBuilder code = new StringBuilder();

        // Start with imports
        for (String importStr : table.getImports()) {
            code.append("import ").append(importStr).append(";").append(NL);
        }

        code.append(NL);
        code.append(table.getClassName());

        // Add extends clause if there's a superclass
        if (table.getSuper() != null && !table.getSuper().isEmpty()) {
            code.append(" extends ").append(table.getSuper());
        }

        code.append(L_BRACKET);
        code.append(NL);
        code.append(NL);

        // Add field declarations
        for (var field : table.getFields()) {
            code.append(".field public ").append(field.getName())
                    .append(ollirTypes.toOllirType(field.getType()))
                    .append(";").append(NL);
        }

        if (!table.getFields().isEmpty()) {
            code.append(NL);
        }

        code.append(buildConstructor());
        code.append(NL);

        // Add methods
        for (var child : node.getChildren(METHOD_DECL)) {
            var result = visit(child);
            code.append(result);
        }

        code.append(R_BRACKET);

        return code.toString();
    }

    private String buildConstructor() {

        return """
                .construct %s().V {
                    invokespecial(this, "<init>").V;
                }
                """.formatted(table.getClassName());
    }


    private String visitProgram(JmmNode node, Void unused) {

        StringBuilder code = new StringBuilder();

        node.getChildren().stream()
                .map(this::visit)
                .forEach(code::append);

        return code.toString();
    }

    /**
     * Default visitor. Visits every child node and return an empty string.
     *
     * @param node
     * @param unused
     * @return
     */
    private String defaultVisit(JmmNode node, Void unused) {

        for (var child : node.getChildren()) {
            visit(child);
        }

        return "";
    }
}
