package pt.up.fe.comp2025.backend;

import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.AssignInstruction;
import org.specs.comp.ollir.inst.BinaryOpInstruction;
import org.specs.comp.ollir.inst.ReturnInstruction;
import org.specs.comp.ollir.inst.SingleOpInstruction;
import org.specs.comp.ollir.inst.NewInstruction;
import org.specs.comp.ollir.inst.InvokeVirtualInstruction;
import org.specs.comp.ollir.inst.InvokeSpecialInstruction;
import org.specs.comp.ollir.inst.InvokeStaticInstruction;
import org.specs.comp.ollir.inst.GetFieldInstruction;
import org.specs.comp.ollir.inst.PutFieldInstruction;
import org.specs.comp.ollir.inst.GotoInstruction;
import org.specs.comp.ollir.inst.SingleOpCondInstruction;
import org.specs.comp.ollir.inst.OpCondInstruction;
import org.specs.comp.ollir.inst.ArrayLengthInstruction;
import org.specs.comp.ollir.inst.UnaryOpInstruction;
import org.specs.comp.ollir.inst.Instruction;
import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.Type;
import org.specs.comp.ollir.type.ArrayType;
import org.specs.comp.ollir.type.ClassType;
import org.specs.comp.ollir.type.BuiltinType;
import org.specs.comp.ollir.type.BuiltinKind;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.specs.util.classmap.FunctionClassMap;
import pt.up.fe.specs.util.exceptions.NotImplementedException;
import pt.up.fe.specs.util.utilities.StringLines;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class JasminGenerator {

    private static final String NL = "\n";
    private static final String TAB = "   ";

    private final OllirResult ollirResult;

    List<Report> reports;

    String code;

    Method currentMethod;

    private final JasminUtils types;

    private final FunctionClassMap<TreeNode, String> generators;

    public JasminGenerator(OllirResult ollirResult) {
        this.ollirResult = ollirResult;

        reports = new ArrayList<>();
        code = null;
        currentMethod = null;

        types = new JasminUtils(ollirResult);

        this.generators = new FunctionClassMap<>();
        generators.put(ClassUnit.class, this::generateClassUnit);
        generators.put(Method.class, this::generateMethod);
        generators.put(AssignInstruction.class, this::generateAssign);
        generators.put(SingleOpInstruction.class, this::generateSingleOp);
        generators.put(LiteralElement.class, this::generateLiteral);
        generators.put(Operand.class, this::generateOperand);
        generators.put(BinaryOpInstruction.class, this::generateBinaryOp);
        generators.put(ReturnInstruction.class, this::generateReturn);
        generators.put(NewInstruction.class, this::generateNew);
        generators.put(InvokeVirtualInstruction.class, this::generateInvokeVirtual);
        generators.put(InvokeSpecialInstruction.class, this::generateInvokeSpecial);
        generators.put(InvokeStaticInstruction.class, this::generateInvokeStatic);
        generators.put(GetFieldInstruction.class, this::generateGetField);
        generators.put(PutFieldInstruction.class, this::generatePutField);
        generators.put(GotoInstruction.class, this::generateGoto);
        generators.put(OpCondInstruction.class, this::generateOpCond);
        generators.put(SingleOpCondInstruction.class, this::generateSingleOpCond);
        generators.put(ArrayLengthInstruction.class, this::generateArrayLength);
        generators.put(ArrayOperand.class, this::generateArrayLoad);
        generators.put(UnaryOpInstruction.class, this::generateUnaryOp);
    }

    private String apply(TreeNode node) {
        var code = new StringBuilder();

        // Print the corresponding OLLIR code as a comment
        //code.append("; ").append(node).append(NL);

        code.append(generators.apply(node));

        return code.toString();
    }


    public List<Report> getReports() {
        return reports;
    }

    public String build() {

        if (code == null) {
            code = apply(ollirResult.getOllirClass());
        }

        return code;
    }


    private String generateClassUnit(ClassUnit classUnit) {

        var code = new StringBuilder();

        var className = ollirResult.getOllirClass().getClassName();
        code.append(".class ").append(className).append(NL).append(NL);

        var fullSuperClass = "java/lang/Object";

        code.append(".super ").append(fullSuperClass).append(NL);

        var defaultConstructor = """
                ;default constructor
                .method public <init>()V
                    aload_0
                    invokespecial %s/<init>()V
                    return
                .end method
                """.formatted(fullSuperClass);
        code.append(defaultConstructor);

        for (var method : ollirResult.getOllirClass().getMethods()) {

            if (method.isConstructMethod()) {
                continue;
            }

            code.append(apply(method));
        }

        return code.toString();
    }    private String generateMethod(Method method) {
        // Set method
        currentMethod = method;

        var code = new StringBuilder();

        // Calculate modifier
        var modifier = types.getModifier(method.getMethodAccessModifier());
        if (method.isStaticMethod()) {
            modifier += "static ";
        }

        var methodName = method.getMethodName();
        
        // Generate method descriptor using our utility
        String methodDescriptor = types.getMethodDescriptor(method);

        code.append("\n.method ").append(modifier)
                .append(methodName)
                .append(methodDescriptor).append(NL);

        // Calculate stack and locals limits
        Map<String, Integer> limits = types.calculateLimits(method);
        int stackLimit = limits.get("stack");
        int localsLimit = limits.get("locals");
        
        code.append(TAB).append(".limit stack ").append(stackLimit).append(NL);
        code.append(TAB).append(".limit locals ").append(localsLimit).append(NL);

        Set<String> labelsNeeded = new HashSet<>();
        
        // First collect labels from control flow instructions
        for (org.specs.comp.ollir.inst.Instruction inst : method.getInstructions()) {
            if (inst instanceof GotoInstruction gotoInst) {
                labelsNeeded.add(gotoInst.getLabel());
            } 
            else if (inst instanceof OpCondInstruction condBranch) {
                labelsNeeded.add(condBranch.getLabel());
            }
            else if (inst instanceof SingleOpCondInstruction condBranch) {
                labelsNeeded.add(condBranch.getLabel());
            }
        }
          // Generate code for each instruction with iinc optimization
        List<org.specs.comp.ollir.inst.Instruction> instructions = method.getInstructions();
        for (int i = 0; i < instructions.size(); i++) {
            org.specs.comp.ollir.inst.Instruction inst = instructions.get(i);
            
            // Emitting necessary labels for this instruction
            HashMap<String, Instruction> labelMap = method.getLabels();
            if (labelMap != null) {
                for (Map.Entry<String, Instruction> entry : labelMap.entrySet()) {
                    if (entry.getValue() == inst && labelsNeeded.contains(entry.getKey())) {
                        code.append(TAB).append(entry.getKey()).append(":").append(NL);
                    }
                }
            }
            
            // Check for iinc optimization pattern: temp = var + const; var = temp
            if (inst instanceof AssignInstruction && i + 1 < instructions.size()) {
                AssignInstruction firstAssign = (AssignInstruction) inst;
                org.specs.comp.ollir.inst.Instruction nextInst = instructions.get(i + 1);
                
                if (nextInst instanceof AssignInstruction) {
                    AssignInstruction secondAssign = (AssignInstruction) nextInst;
                    
                    if (JasminIncrementOptimizer.canApplyIincOptimizationPair(firstAssign, secondAssign)) {
                        // Apply iinc optimization - generate iinc instruction and skip both assignments
                        String iincCode = JasminIncrementOptimizer.generateIincInstructionFromPair(firstAssign, currentMethod.getVarTable());
                        code.append(TAB).append(iincCode);
                        
                        // Handle labels for the second instruction as well
                        if (labelMap != null) {
                            for (Map.Entry<String, Instruction> entry : labelMap.entrySet()) {
                                if (entry.getValue() == nextInst && labelsNeeded.contains(entry.getKey())) {
                                    code.append(TAB).append(entry.getKey()).append(":").append(NL);
                                }
                            }
                        }
                        
                        // Skip the next instruction since we've optimized both
                        i++;
                        continue;
                    }
                }
            }
            
            // Generate code for the instruction normally
            String instCode = apply(inst);
            if (!instCode.isEmpty()) {
                String formattedInstCode = StringLines.getLines(instCode).stream()
                        .collect(Collectors.joining(NL + TAB, TAB, NL));
                
                code.append(formattedInstCode);
            }
        }

        code.append(".end method\n");

        // unset method
        currentMethod = null;
        return code.toString();
    }    private String generateAssign(AssignInstruction assign) {
        var code = new StringBuilder();

        // Get the left-hand side (destination)
        var lhs = assign.getDest();
        
        // First, check if we can apply the iinc optimization
        if (JasminIncrementOptimizer.canApplyIincOptimization(assign)) {
            code.append(JasminIncrementOptimizer.generateIincInstruction(assign, currentMethod.getVarTable()));
            return code.toString();
        }
          
        // Check if we're assigning to an array element
        if (lhs instanceof ArrayOperand) {
            ArrayOperand arrayOp = (ArrayOperand) lhs;
            

            String arrayName = arrayOp.getName();
            var reg = currentMethod.getVarTable().get(arrayName);
            Type arrayType = reg.getVarType(); // Get the actual array type from the variable table
            code.append(types.generateLoadInstruction(arrayType, reg.getVirtualReg())).append(NL);

            code.append(apply(arrayOp.getIndexOperands().get(0)));

            code.append(apply(assign.getRhs()));

            if (!(arrayType instanceof ArrayType)) {
                throw new NotImplementedException("Expected array type, got: " + arrayType);
            }
            
            Type elementType = ((ArrayType) arrayType).getElementType();
            
            if (elementType instanceof ClassType || elementType instanceof ArrayType) {
                code.append("aastore").append(NL);
            } else if (elementType instanceof BuiltinType) {
                BuiltinType builtinType = (BuiltinType) elementType;
                switch (builtinType.getKind()) {
                    case INT32:
                        code.append("iastore").append(NL);
                        break;
                    case BOOLEAN:
                        code.append("bastore").append(NL);
                        break;
                    default:
                        throw new NotImplementedException("Array store not implemented for type: " + elementType);
                }
            } else {
                throw new NotImplementedException("Array store not implemented for type: " + elementType);
            }
        } else if (lhs instanceof Operand) {
            // Regular variable assignment
            var operand = (Operand) lhs;
            
            // Regular assignment - generate code for loading what's on the right
            code.append(apply(assign.getRhs()));

            var reg = currentMethod.getVarTable().get(operand.getName());

            String storeInstruction = types.generateStoreInstruction(operand.getType(), reg.getVirtualReg());
            code.append(storeInstruction).append(NL);
        } else {
            throw new NotImplementedException("Assignment destination not supported: " + lhs.getClass());
        }

        return code.toString();
    }

    private String generateSingleOp(SingleOpInstruction singleOp) {
        return apply(singleOp.getSingleOperand());
    }    private String generateLiteral(LiteralElement literal) {
        String literalValue = literal.getLiteral();
        
        // Try to parse as integer for optimization
        try {
            int value = Integer.parseInt(literalValue);
            return generateOptimizedIntConstant(value);
        } catch (NumberFormatException e) {
            return "ldc " + literalValue + NL;
        }
    }
    
    private String generateOptimizedIntConstant(int value) {
        if (value >= -1 && value <= 5) {
            switch (value) {
                case -1: return "iconst_m1" + NL;
                case 0: return "iconst_0" + NL;
                case 1: return "iconst_1" + NL;
                case 2: return "iconst_2" + NL;
                case 3: return "iconst_3" + NL;
                case 4: return "iconst_4" + NL;
                case 5: return "iconst_5" + NL;
            }
        }
        if (value >= -128 && value <= 127) {
            return "bipush " + value + NL;
        }
        if (value >= -32768 && value <= 32767) {
            return "sipush " + value + NL;
        }

        return "ldc " + value + NL;
    }    // This section intentionally left empty after removing unused method

    private String generateOperand(Operand operand) {        // Special case for array access
        if (operand instanceof ArrayOperand arrayOp) {
            // First, load the array reference onto the stack
            String arrayName = arrayOp.getName();
            var baseReg = currentMethod.getVarTable().get(arrayName);
            StringBuilder code = new StringBuilder();
            Type arrayType = baseReg.getVarType(); // Get the actual array type from the variable table
            code.append(types.generateLoadInstruction(arrayType, baseReg.getVirtualReg())).append(NL);
            
            // Next, load the index value onto the stack
            code.append(apply(arrayOp.getIndexOperands().get(0)));
            
            // Generate the appropriate array load instruction based on the element type
            Type elementType = ((ArrayType) arrayType).getElementType();
            
            if (elementType instanceof ClassType || elementType instanceof ArrayType) {
                code.append("aaload").append(NL);
            } else if (elementType instanceof BuiltinType) {
                BuiltinType builtinType = (BuiltinType) elementType;
                switch (builtinType.getKind()) {
                    case INT32:
                        code.append("iaload").append(NL);
                        break;
                    case BOOLEAN:
                        code.append("baload").append(NL);
                        break;
                    default:
                        throw new NotImplementedException("Array load not implemented for type: " + elementType);
                }
            } else {
                throw new NotImplementedException("Array load not implemented for type: " + elementType);
            }
            
            return code.toString();
        }

        var reg = currentMethod.getVarTable().get(operand.getName());

        // Use our utility method to generate the appropriate load instruction based on the type
        return types.generateLoadInstruction(operand.getType(), reg.getVirtualReg()) + NL;
    }    private String generateBinaryOp(BinaryOpInstruction binaryOp) {
        var code = new StringBuilder();

        OperationType opType = binaryOp.getOperation().getOpType();
        Type operandType = binaryOp.getLeftOperand().getType();

        if (opType == OperationType.LTH) {
            System.out.println("Processing LTH in generateBinaryOp:");
            System.out.println("  Left operand: " + binaryOp.getLeftOperand());
            System.out.println("  Right operand: " + binaryOp.getRightOperand());

            if (binaryOp.getRightOperand() instanceof LiteralElement) {
                try {
                    int value = Integer.parseInt(((LiteralElement)binaryOp.getRightOperand()).getLiteral());
                    System.out.println("  Right is zero: " + (value == 0));
                } catch (NumberFormatException e) {
                    System.out.println("  Right is not a numeric literal");
                }
            }
        }
        
        // Special handling for boolean operations
        boolean isBoolean = operandType instanceof BuiltinType && 
                           ((BuiltinType)operandType).getKind() == BuiltinKind.BOOLEAN;
        
        // Handle boolean operations with short circuits
        if ((opType == OperationType.AND || opType == OperationType.ANDB) && isBoolean) {
            // Use a stable ID based on the instruction's hashcode
            String id = Integer.toString(Math.abs(System.identityHashCode(binaryOp)) % 10000);
            String falseLabel = "and_false_" + id;
            String endLabel = "and_end_" + id;
            
            // Evaluate left operand
            code.append(apply(binaryOp.getLeftOperand()));

            code.append("ifeq ").append(falseLabel).append(NL);
            
            // Evaluate right operand if left is true
            code.append(apply(binaryOp.getRightOperand()));
            code.append("goto ").append(endLabel).append(NL);

            code.append(falseLabel).append(":").append(NL);
            code.append("iconst_0").append(NL);
            
            // End label
            code.append(endLabel).append(":").append(NL);
        }
        else if ((opType == OperationType.OR || opType == OperationType.ORB) && isBoolean) {
            // Use a stable ID based on the instruction's hashcode
            String id = Integer.toString(Math.abs(System.identityHashCode(binaryOp)) % 10000);
            String trueLabel = "or_true_" + id;
            String endLabel = "or_end_" + id;
            
            // Evaluate left operand
            code.append(apply(binaryOp.getLeftOperand()));
            // If left is true (1), short circuit to true result
            code.append("ifne ").append(trueLabel).append(NL);
            
            // Evaluate right operand only if left was false
            code.append(apply(binaryOp.getRightOperand()));
            code.append("goto ").append(endLabel).append(NL);

            code.append(trueLabel).append(":").append(NL);
            code.append("iconst_1").append(NL);
            
            // End label
            code.append(endLabel).append(":").append(NL);
        }
        else if (opType == OperationType.LTH && isBoolean) {
            // Special handling for less than with booleans
            code.append(apply(binaryOp.getLeftOperand()));
            code.append(apply(binaryOp.getRightOperand()));
            
            String id = Integer.toString(Math.abs(System.identityHashCode(binaryOp)) % 10000);
            String trueLabel = "lth_true_" + id;
            String endLabel = "lth_end_" + id;
            
            // Compare the two boolean values
            code.append("if_icmplt ").append(trueLabel).append(NL);
            code.append("iconst_0").append(NL);  // False result
            code.append("goto ").append(endLabel).append(NL);
            
            // True case
            code.append(trueLabel).append(":").append(NL);
            code.append("iconst_1").append(NL);  // True result
            
            // End label
            code.append(endLabel).append(":").append(NL);        }
        else if (opType == OperationType.LTH) {
            // Special optimization for comparison with zero
            if (binaryOp.getRightOperand() instanceof LiteralElement) {
                try {
                    LiteralElement literalElement = (LiteralElement) binaryOp.getRightOperand();
                    int value = Integer.parseInt(literalElement.getLiteral());
                    if (value == 0) {
                        // If comparing with literal 0, use optimized iflt pattern
                        String id = Integer.toString(Math.abs(System.identityHashCode(binaryOp)) % 10000);
                        String trueLabel = "lth_zero_true_" + id;
                        String endLabel = "lth_zero_end_" + id;
                        
                        code.append(apply(binaryOp.getLeftOperand()));
                        code.append("iflt ").append(trueLabel).append(NL);
                        
                        // False case
                        code.append("iconst_0").append(NL);
                        code.append("goto ").append(endLabel).append(NL);
                        
                        // True case
                        code.append(trueLabel).append(":").append(NL);
                        code.append("iconst_1").append(NL);
                        
                        // End label
                        code.append(endLabel).append(":").append(NL);
                        
                        return code.toString();
                    }
                } catch (NumberFormatException e) {
                    // Not a number, fall through to regular comparison
                }
            }
            
            // Regular LTH comparison
            code.append(apply(binaryOp.getLeftOperand()));
            code.append(apply(binaryOp.getRightOperand()));

            String opInstruction = types.getBinaryOpInstruction(opType, operandType);
            
            code.append(opInstruction).append(NL);
        }
        else {
            code.append(apply(binaryOp.getLeftOperand()));
            code.append(apply(binaryOp.getRightOperand()));

            String opInstruction = types.getBinaryOpInstruction(opType, operandType);
            
            code.append(opInstruction).append(NL);
        }

        return code.toString();
    }private String generateReturn(ReturnInstruction returnInst) {
        var code = new StringBuilder();
        if (returnInst.hasReturnValue()) {
            code.append(apply(returnInst.getOperand().get()));
        }

        // Generate the appropriate return instruction based on the method's return type
        Type returnType = currentMethod.getReturnType();
        code.append(types.generateReturnInstruction(returnType)).append(NL);

        return code.toString();
    }    private String generateNew(NewInstruction newInst) {
        var code = new StringBuilder();
        Type returnType = newInst.getReturnType();
        List<Element> arguments = newInst.getArguments();
        
        if (!arguments.isEmpty()) {
            // Array initialization with size
            // Load array size onto the stack
            code.append(apply(arguments.get(0)));
            
            // Create a new array of the appropriate type
            Type elemType = returnType;
            if (elemType instanceof ArrayType) {
                elemType = ((ArrayType)elemType).getElementType();
            }
            
            if (elemType instanceof ClassType) {
                String className = ((ClassType)elemType).getName().replace(".", "/");
                code.append("anewarray ").append(className).append(NL);
            } else if (elemType instanceof BuiltinType) {
                BuiltinType builtinType = (BuiltinType)elemType;
                switch (builtinType.getKind()) {
                    case INT32:
                        code.append("newarray int").append(NL);  // T_INT = 10
                        break;
                    case BOOLEAN:
                        code.append("newarray boolean").append(NL);  // T_BOOLEAN = 4
                        break;
                    case STRING:
                        code.append("anewarray java/lang/String").append(NL);
                        break;
                    default:
                        throw new NotImplementedException("Array type not supported: " + elemType);
                }
            } else if (elemType instanceof ArrayType) {
                code.append("anewarray ").append(types.getJasminType(elemType)).append(NL);
            } else {
                throw new NotImplementedException("Array type not supported: " + elemType);
            }
        } else {
            if (!(returnType instanceof ClassType)) {
                throw new NotImplementedException("Cannot create new instance of non-class type: " + returnType);
            }
            
            ClassType classType = (ClassType) returnType;
            code.append("new ").append(classType.getName().replace(".", "/")).append(NL);
            code.append("dup").append(NL); // Duplicate reference for constructor call
        }
        
        return code.toString();
    }

    private String generateInvokeVirtual(InvokeVirtualInstruction invoke) {
        var code = new StringBuilder();
        
        // Load the object on which the method is invoked (the "this" reference)
        code.append(apply(invoke.getCaller()));
        
        // Load all the arguments
        for (Element arg : invoke.getArguments()) {
            code.append(apply(arg));
        }
        
        // Get method info
        Element methodElement = invoke.getMethodName();
        String methodName;
        if (methodElement instanceof LiteralElement) {
            methodName = ((LiteralElement) methodElement).getLiteral().replace("\"", "");
        } else {
            throw new NotImplementedException("Method name must be a literal: " + methodElement);
        }
        
        // Generate the invokevirtual instruction
        Type callerType = invoke.getCaller().getType();
        String className;
        
        if (callerType instanceof ClassType) {
            className = ((ClassType) callerType).getName().replace(".", "/");
        } else {
            throw new NotImplementedException("Caller type not supported: " + callerType);
        }
        
        // Generate the method descriptor
        StringBuilder paramTypes = new StringBuilder();
        for (Element param : invoke.getArguments()) {
            paramTypes.append(types.getJasminType(param.getType()));
        }
        
        String returnTypeDesc = types.getJasminType(invoke.getReturnType());
        
        code.append("invokevirtual ")
            .append(className)
            .append("/")
            .append(methodName)
            .append("(")
            .append(paramTypes)
            .append(")")
            .append(returnTypeDesc)
            .append(NL);
        
        return code.toString();
    }    private String generateInvokeSpecial(InvokeSpecialInstruction invokeSpecial) {
        var code = new StringBuilder();

        // Load the object on which the method is invoked (the "this" reference)
        code.append(apply(invokeSpecial.getCaller()));

        // Load all the arguments
        for (Element arg : invokeSpecial.getArguments()) {
            code.append(apply(arg));
        }

        // Get method info
        Element methodElement = invokeSpecial.getMethodName();
        String methodName;
        if (methodElement instanceof LiteralElement) {
            methodName = ((LiteralElement) methodElement).getLiteral().replace("\"", "");
        } else {
            throw new NotImplementedException("Method name must be a literal: " + methodElement);
        }

        // Generate the invokespecial instruction
        Type callerType = invokeSpecial.getCaller().getType();
        String className;

        if (callerType instanceof ClassType) {
            className = ((ClassType) callerType).getName().replace(".", "/");
        } else {
            throw new NotImplementedException("Caller type not supported: " + callerType);
        }

        // Generate the method descriptor
        StringBuilder paramTypes = new StringBuilder();
        for (Element param : invokeSpecial.getArguments()) {
            paramTypes.append(types.getJasminType(param.getType()));
        }

        String returnTypeDesc = types.getJasminType(invokeSpecial.getReturnType());

        code.append("invokespecial ")
            .append(className)
            .append("/")
            .append(methodName)
            .append("(")
            .append(paramTypes)
            .append(")")
            .append(returnTypeDesc)
            .append(NL);

        return code.toString();
    }    private String generateGetField(GetFieldInstruction getField) {
        var code = new StringBuilder();

        // Load the object reference
        code.append(apply(getField.getObject()));

        // Generate the getfield instruction
        Type fieldType = getField.getFieldType();
        String fieldName = getField.getField().getName();
        String className = ((ClassType) getField.getObject().getType()).getName().replace(".", "/");

        code.append("getfield ")
            .append(className)
            .append("/")
            .append(fieldName)
            .append(" ")
            .append(types.getJasminType(fieldType))
            .append(NL);

        return code.toString();
    }    private String generatePutField(PutFieldInstruction putField) {
        var code = new StringBuilder();

        // Load the object reference
        code.append(apply(putField.getObject()));

        // Load the value to be stored
        code.append(apply(putField.getValue()));

        // Generate the putfield instruction
        Type fieldType = putField.getFieldType();
        String fieldName = putField.getField().getName();
        String className = ((ClassType) putField.getObject().getType()).getName().replace(".", "/");

        code.append("putfield ")
            .append(className)
            .append("/")
            .append(fieldName)
            .append(" ")
            .append(types.getJasminType(fieldType))
            .append(NL);

        return code.toString();
    }    private String generateGoto(GotoInstruction gotoInst) {
        // Make sure label is correctly formatted for Jasmin
        return "goto " + gotoInst.getLabel() + NL;
    }    private String generateOpCond(OpCondInstruction opCondInst) {
        var code = new StringBuilder();
        
        // Get the binary operation that serves as the condition
        BinaryOpInstruction binOp = (BinaryOpInstruction) opCondInst.getCondition();
        
        // Get the operation type and target label
        OperationType opType = binOp.getOperation().getOpType();
        String label = opCondInst.getLabel();
        
        // Use a stable ID based on the instruction's hashcode
        String id = Integer.toString(Math.abs(System.identityHashCode(binOp)) % 10000);
        
        switch (opType) {
            case ANDB:
            case AND:
                // For AND, both parts need to be true
                
                // Generate unique labels
                String shortCircuitEnd = "sc_end_" + id;
                
                // Check left operand
                code.append(apply(binOp.getLeftOperand()));
                code.append("ifeq ").append(shortCircuitEnd).append(NL);  // If left is false, skip
                
                // Check right operand
                code.append(apply(binOp.getRightOperand()));
                code.append("ifne ").append(label).append(NL);  // If right is true, jump to target label
                
                // Place the end label here - fall through if left is true but right is false
                code.append(shortCircuitEnd).append(":").append(NL);
                break;
                
            case ORB:
            case OR:
                // For OR one part needs to be true
                
                // Check left operand
                code.append(apply(binOp.getLeftOperand()));
                code.append("ifne ").append(label).append(NL);  // If left is true, jump to target label
                
                // Check right operand only if left was false
                code.append(apply(binOp.getRightOperand()));
                code.append("ifne ").append(label).append(NL);  // If right is true, jump to target label
                
                // Fall through if both are false
                break;                case LTH:

                code.append(apply(binOp.getLeftOperand()));
                
                // Add special case for zero comparison
                if (binOp.getRightOperand() instanceof LiteralElement) {
                    try {
                        LiteralElement literalElement = (LiteralElement) binOp.getRightOperand();
                        int value = Integer.parseInt(literalElement.getLiteral());
                        if (value == 0) {
                            // If comparing with literal 0, use iflt directly
                            code.append("iflt ").append(label).append(NL);
                            break;
                        }
                    } catch (NumberFormatException e) {
                        // Not a number, continue with regular comparison
                    }
                }
                
                // For any other case, load the right operand and compute (a - b)
                code.append(apply(binOp.getRightOperand()));
                code.append("isub").append(NL);  // a - b on stack
                code.append("iflt ").append(label).append(NL);  // if (a - b) < 0 goto label
                break;
                
            case GTH:
                // Special handling for greater than
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                code.append("if_icmpgt ").append(label).append(NL);
                break;
                
            case LTE:
                // Special handling for less than or equal
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                code.append("if_icmple ").append(label).append(NL);
                break;
                
            case GTE:
                // Special handling for greater than or equal
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                code.append("if_icmpge ").append(label).append(NL);
                break;
                
            case EQ:
                // Special handling for equality
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                code.append("if_icmpeq ").append(label).append(NL);
                break;
                
            case NEQ:
                // Special handling for not equal
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                code.append("if_icmpne ").append(label).append(NL);
                break;
                
            default:
                // For any other type of operations
                // Load the left and right operands and use direct comparison instructions
                code.append(apply(binOp.getLeftOperand()));
                code.append(apply(binOp.getRightOperand()));
                
                // Use the comparison instruction from our utility
                String jumpInstruction = types.getComparisonInstruction(opType);
                code.append(jumpInstruction).append(" ").append(label).append(NL);
                break;
        }
        
        return code.toString();
    }private String generateSingleOpCond(SingleOpCondInstruction singleOpCondInst) {
        var code = new StringBuilder();

        Element operand = singleOpCondInst.getOperands().get(0);
        code.append(apply(operand));
        
        // For a single operand condition (like 'if(x)'), we need to check if it's true (non-zero)
        // ifne = jump if not equal to zero (true for boolean)
        code.append("ifne").append(" ").append(singleOpCondInst.getLabel()).append(NL);
        
        return code.toString();
    }
      private String generateInvokeStatic(InvokeStaticInstruction invoke) {
        var code = new StringBuilder();
        
        // Load all the arguments
        for (Element arg : invoke.getArguments()) {
            code.append(apply(arg));
        }
        
        // Get method info
        Element methodElement = invoke.getMethodName();
        String methodName;
        if (methodElement instanceof LiteralElement) {
            methodName = ((LiteralElement) methodElement).getLiteral().replace("\"", "");
        } else {
            throw new NotImplementedException("Method name must be a literal: " + methodElement);
        }

        Element callerElement = invoke.getCaller();
        String className;
        if (callerElement instanceof LiteralElement) {
            className = ((LiteralElement) callerElement).getLiteral().replace("\"", "");
        } else if (callerElement instanceof Operand) {
            Operand caller = (Operand) callerElement;
            // For static calls, the operand name itself is the class name
            className = caller.getName();
        } else {
            throw new NotImplementedException("Caller element not supported: " + callerElement);
        }

        StringBuilder paramTypes = new StringBuilder();
        for (Element param : invoke.getArguments()) {
            paramTypes.append(types.getJasminType(param.getType()));
        }
        
        String returnTypeDesc = types.getJasminType(invoke.getReturnType());
        
        code.append("invokestatic ")
            .append(className.replace(".", "/"))
            .append("/")
            .append(methodName)
            .append("(")
            .append(paramTypes)
            .append(")")
            .append(returnTypeDesc)
            .append(NL);
        
        return code.toString();
    }private String generateArrayLength(ArrayLengthInstruction arrLenInst) {
        var code = new StringBuilder();
        
        // Load the array reference onto the stack
        code.append(apply(arrLenInst.getCaller()));
        
        // Generate the array length instruction
        // This will push the array length onto the stack
        code.append("arraylength").append(NL);
        
        return code.toString();
    }    private String generateArrayLoad(ArrayOperand arrayOp) {
        var code = new StringBuilder();
        
        // First, load the array reference onto the stack
        String arrayName = arrayOp.getName();
        var reg = currentMethod.getVarTable().get(arrayName);
        Type arrayType = reg.getVarType(); // Get the actual array type from the variable table
        code.append(types.generateLoadInstruction(arrayType, reg.getVirtualReg())).append(NL);
        
        // Next, load the index value onto the stack - handle complex expressions as indices
        Element indexElement = arrayOp.getIndexOperands().get(0);
        code.append(apply(indexElement));
        
        // Generate the appropriate array load instruction based on the element type
        if (!(arrayType instanceof ArrayType)) {
            throw new NotImplementedException("Expected array type, got: " + arrayType);
        }
        
        Type elementType = ((ArrayType) arrayType).getElementType();
        
        if (elementType instanceof ClassType || elementType instanceof ArrayType) {
            code.append("aaload").append(NL);
        } else if (elementType instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) elementType;
            switch (builtinType.getKind()) {
                case INT32:
                    code.append("iaload").append(NL);
                    break;
                case BOOLEAN:
                    code.append("baload").append(NL);
                    break;
                default:
                    throw new NotImplementedException("Array load not implemented for type: " + elementType);
            }
        } else {
            throw new NotImplementedException("Array load not implemented for type: " + elementType);
        }
        
        return code.toString();
    }private String generateUnaryOp(UnaryOpInstruction unaryOp) {
        var code = new StringBuilder();

        Element operand = unaryOp.getOperand();
        OperationType opType = unaryOp.getOperation().getOpType();

        code.append(apply(operand));
        
        // Generate the appropriate unary operation instruction
        String unaryInstruction = types.getUnaryOpInstruction(opType, operand.getType());
        code.append(unaryInstruction).append(NL);
        
        return code.toString();
    }
}