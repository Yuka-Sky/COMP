package pt.up.fe.comp2025.optimization;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.ast.PreorderJmmVisitor;
import pt.up.fe.comp2025.ast.TypeUtils;
import pt.up.fe.comp2025.symboltable.JmmSymbolTable;

import java.util.ArrayList;
import java.util.List;

import static pt.up.fe.comp2025.ast.Kind.*;

/**
 * Generates OLLIR code from JmmNodes that are expressions.
 */
public class OllirExprGeneratorVisitor extends PreorderJmmVisitor<Void, OllirExprResult> {

    private static final String SPACE = " ";
    private static final String ASSIGN = ":=";
    private final String END_STMT = ";\n";

    private final SymbolTable table;

    private final TypeUtils types;
    private final OptUtils ollirTypes;


    public OllirExprGeneratorVisitor(SymbolTable table) {
        this.table = table;
        this.types = new TypeUtils(table);
        this.ollirTypes = new OptUtils(types);
    }


    @Override
    protected void buildVisitor() {
        addVisit(VAR_REF_EXPR, this::visitVarRef);
        addVisit(BINARY_EXPR, this::visitBinExpr);
        addVisit(INTEGER_LITERAL, this::visitInteger);
        addVisit(STATIC_METHOD_CALL, this::visitStaticMethodCall);
        addVisit(METHOD_CALL, this::visitMethodCall);
        addVisit(MEMBER_ACESS, this::visitMemberAcess);
        addVisit("ArrayAccess", this::visitArrayAccess);
        addVisit(EXPR_LENGTH, this::visitExprLength);
        addVisit(PAREN_EXPR, this::visitParenExpr);
        addVisit(BRACKETS_EXPR, this::visitBracketsExpr);
        addVisit(TRUE_BOOL, this::visitTrueBool);
        addVisit(FALSE_BOOL, this::visitFalseBool);
        addVisit(THIS, this::visitThis);
        addVisit(NEW_ARRAY_ALLOC, this::visitNewArrayAlloc);
        addVisit(NEW_OBJECT_INST, this::visitNewObjectInst);
        addVisit(UNARY_EXPR, this::visitUnaryExpr);

        setDefaultVisit(this::defaultVisit);
    }

    /* General steps for expression generation:
    * 1. Extract information from the JmmNode
    * 2. Determine the result type of the expr with TypeUtils
    * 3. Visit child expr recursively to generate their OLLIR code
    * 4. Build computation:
    *    a. Appending pre-computations from child expr
    *    b. Creating a temporary variable for the result only if needed
    *    c. Generating the OLLIR operation
    * 5. Return both the code and the computation string
    */

    private boolean isClassField(String varName, String methodName) {
        // If we're in a method context, check parameters and local variables first
        if (methodName != null && !methodName.isEmpty()) {
            // Check parameters
            List<Symbol> parameters = table.getParameters(methodName);
            if (parameters != null) {
                for (Symbol param : parameters) {
                    if (param.getName().equals(varName)) {
                        System.out.println("Variable " + varName + " is a parameter in " + methodName);
                        return false; // It's a parameter
                    }
                }
            }

            // Check local variables
            List<Symbol> localVars = table.getLocalVariables(methodName);
            if (localVars != null) {
                for (Symbol localVar : localVars) {
                    if (localVar.getName().equals(varName)) {
                        System.out.println("Variable " + varName + " is a local variable in " + methodName);
                        return false; // It's a local variable
                    }
                }
            }
        }

        // Check if it's a field
        List<Symbol> fields = table.getFields();
        if (fields != null) {
            for (Symbol field : fields) {
                if (field.getName().equals(varName)) {
                    System.out.println("Variable " + varName + " is a class field");
                    return true; // It's a field
                }
            }
        }

        // Default behavior - if we can't determine, assume it's not a field
        System.out.println("Variable " + varName + " not identified, assuming local");
        return false;
    }


    // Helper method to get the current method name from a node
    private String getCurrentMethodName(JmmNode node) {
        // Traverse up until we find a MethodDecl node
        JmmNode current = node;
        while (current != null && !current.getKind().equals("MethodDecl")) {
            current = current.getParent();
        }

        if (current != null && current.getKind().equals("MethodDecl")) {
            return current.get("name");
        }

        return null; // Not in a method context
    }

    private OllirExprResult visitStaticMethodCall(JmmNode node, Void unused) {
        String className = node.get("className");
        String methodName = node.get("methodName");
        
        System.out.println("Static method call: " + className + "." + methodName);
        
        // Check if this is actually an instance method call misinterpreted as static
        boolean isActuallyInstanceCall = false;
        String methodScopeContext = getCurrentMethodName(node);
        
        if (methodScopeContext != null) {
            // Check if className is actually a local variable or parameter
            List<Symbol> localVars = table.getLocalVariables(methodScopeContext);
            List<Symbol> parameters = table.getParameters(methodScopeContext);
            
            boolean isLocalVar = localVars != null && localVars.stream()
                .anyMatch(var -> var.getName().equals(className));
            
            boolean isParameter = parameters != null && parameters.stream()
                .anyMatch(param -> param.getName().equals(className));
                
            // Also check if className is a field
            boolean isField = table.getFields().stream()
                .anyMatch(field -> field.getName().equals(className));
                
            isActuallyInstanceCall = isLocalVar || isParameter || isField;
            
            if (isActuallyInstanceCall) {
                System.out.println("CORRECTION: This is actually an instance method call on variable: " + className);
            }
        }

        // Determine return type of the method
        Type returnType = null;
        
        // First try to get from node's type info
        try {
            returnType = types.getExprType(node);
        } catch (Exception e) {
            System.out.println("Could not get expr type for node: " + e.getMessage());
        }
        
        // If not available, try to find method in symbol table
        if (returnType == null || returnType.getName().equals("unknown")) {
            try {
                if (isActuallyInstanceCall) {
                    // Try to find instance method return type
                    returnType = table.getReturnType(methodName);
                    System.out.println("Found instance method return type: " + (returnType != null ? returnType.getName() : "null"));
                } else {
                    // For static methods, we'll default to int if not found
                    returnType = TypeUtils.newIntType();
                }
            } catch (Exception e) {
                System.out.println("Could not find method " + methodName + " in symbol table: " + e.getMessage());
            }
        }
        
        // Default to int if we still don't have a type
        if (returnType == null) {
            returnType = TypeUtils.newIntType();
            System.out.println("Defaulting to int for return type of " + className + "." + methodName);
        }
        
        String returnOllirType = ollirTypes.toOllirType(returnType);

        // For standard library methods like io.print, ensure proper return type
        if (className.equals("io") && (methodName.equals("print") || methodName.equals("println"))) {
            returnType = new Type("void", false);
            returnOllirType = ".V";
        }

        StringBuilder computation = new StringBuilder();
        List<OllirExprResult> argResults = new ArrayList<>();

        // Handle varargs if this is actually an instance call
        if (isActuallyInstanceCall) {
            // Check if the method has varargs parameters
            boolean hasVarArgs = false;
            int varArgsPosition = -1;
            Type varArgsElementType = null;

            try {
                // Get method parameters from symbol table
                List<Symbol> parameters = table.getParameters(methodName);
                if (parameters != null && !parameters.isEmpty()) {
                    // Check if the last parameter is a varargs parameter
                    varArgsPosition = parameters.size() - 1;
                    Symbol lastParam = parameters.get(varArgsPosition);
                    hasVarArgs = lastParam.getType().isArray() && isVarArgsParam(methodName, lastParam.getName());

                    if (hasVarArgs) {
                        // Extract the element type of the varargs array
                        varArgsElementType = new Type(lastParam.getType().getName(), false);
                        System.out.println("Method " + methodName + " has varargs parameter: " +
                                lastParam.getName() + " with element type: " + varArgsElementType.getName());
                    }
                }
            } catch (Exception e) {
                System.out.println("Could not find method " + methodName + " in symbol table: " + e.getMessage());

                if (node.getNumChildren() > 0) {
                    hasVarArgs = node.hasAttribute("hasVarArgs") && node.getBoolean("hasVarArgs", false);
                }
            }

            int actualArgCount = node.getNumChildren();
            int normalArgsEnd = hasVarArgs ? Math.min(varArgsPosition, actualArgCount) : actualArgCount;

            // Process normal arguments
            for (int i = 0; i < normalArgsEnd; i++) {
                var argExpr = visit(node.getChild(i));
                computation.append(argExpr.getComputation());
                argResults.add(argExpr);
            }

            // Handle varargs if present
            if (hasVarArgs) {
                System.out.println("Processing varargs in static method call - actualArgCount=" + actualArgCount + 
                                 ", varArgsPosition=" + varArgsPosition + 
                                 ", numChildren=" + node.getNumChildren());
                
                if (actualArgCount == varArgsPosition + 1) {
                    // Case 1: Exactly one argument for varargs position
                    int childIndex = varArgsPosition;
                    System.out.println("Accessing child at index " + childIndex);
                    
                    if (childIndex >= node.getNumChildren()) {
                        System.err.println("ERROR: Trying to access child " + childIndex + 
                                         " but node only has " + node.getNumChildren() + " children");
                        createEmptyVarArgsArray(computation, argResults);
                    } else {
                        JmmNode varArgNode = node.getChild(childIndex);
                        if (varArgNode == null) {
                            System.err.println("ERROR: Child at index " + childIndex + " is null");
                            createEmptyVarArgsArray(computation, argResults);
                        } else {
                            Type varArgType = types.getExprType(varArgNode);

                            if (varArgType != null && varArgType.isArray()) {
                                // The argument is already an array, use it directly
                                var argExpr = visit(varArgNode);
                                computation.append(argExpr.getComputation());
                                argResults.add(argExpr);
                            } else {
                                // Single value needs to be wrapped in an array
                                createSingleElementVarArgsArray(computation, argResults, node, childIndex);
                            }
                        }
                    }
                } else if (actualArgCount > varArgsPosition + 1) {
                    // Case 2: Multiple arguments for varargs - create an array
                    int startIndex = varArgsPosition;
                    int count = actualArgCount - varArgsPosition;
                    
                    System.out.println("Multiple varargs from index " + startIndex + ", count=" + count);
                    
                    if (startIndex >= node.getNumChildren()) {
                        System.err.println("ERROR: Start index " + startIndex + 
                                         " exceeds number of children " + node.getNumChildren());
                        createEmptyVarArgsArray(computation, argResults);
                    } else {
                        createMultiElementVarArgsArray(computation, argResults, node, startIndex, count);
                    }
                } else {
                    // Case 3: No arguments for varargs - create empty array
                    createEmptyVarArgsArray(computation, argResults);
                }
            }
        } else {
            // Original logic for actual static method calls
            for (JmmNode arg : node.getChildren()) {
                OllirExprResult argResult = visit(arg);
                computation.append(argResult.getComputation());
                argResults.add(argResult);
            }
        }

        // Build arguments string
        StringBuilder args = new StringBuilder();
        boolean firstArg = true;
        for (OllirExprResult argResult : argResults) {
            if (!firstArg) {
                args.append(", ");
            }
            args.append(argResult.getCode());
            firstArg = false;
        }

        String tempVar = ollirTypes.nextTemp();
        String code;

        // For void methods, do not assign the result
        if (returnType.getName().equals("void")) {
            if (isActuallyInstanceCall) {
                // This is actually an instance method call
                // Get the type of the variable
                Type varType = null;
                // Use the previously obtained method scope context

                if (methodScopeContext != null) {
                    for (Symbol param : table.getParameters(methodScopeContext)) {
                        if (param.getName().equals(className)) {
                            varType = param.getType();
                            break;
                        }
                    }
                    
                    if (varType == null) {
                        for (Symbol var : table.getLocalVariables(methodScopeContext)) {
                            if (var.getName().equals(className)) {
                                varType = var.getType();
                                break;
                            }
                        }
                    }
                    
                    if (varType == null) {
                        for (Symbol field : table.getFields()) {
                            if (field.getName().equals(className)) {
                                varType = field.getType();
                                break;
                            }
                        }
                    }
                }
                
                if (varType == null) {
                    // Default to the class type if we can't determine
                    varType = new Type(table.getClassName(), false);
                }
                
                String varOllirType = ollirTypes.toOllirType(varType);
                
                computation.append("invokevirtual").append("(")
                        .append(className).append(varOllirType)
                        .append(", \"")
                        .append(methodName).append("\"")
                        .append(args.length() > 0 ? ", " + args.toString() : "")
                        .append(")").append(returnOllirType)
                        .append(END_STMT);
            } else {
                computation.append("invokestatic").append("(")
                        .append(className).append(", \"")
                        .append(methodName).append("\"")
                        .append(args.length() > 0 ? ", " + args.toString() : "")
                        .append(")").append(returnOllirType)
                        .append(END_STMT);
            }

            code = "";  // No result variable for void methods
        } else {
            code = tempVar + returnOllirType;

            // Add method invocation with assignment
            if (isActuallyInstanceCall) {
                // This is actually an instance method call
                // Get the type of the variable
                Type varType = null;
                
                // Use existing method scope context
                if (methodScopeContext != null) {
                    for (Symbol param : table.getParameters(methodScopeContext)) {
                        if (param.getName().equals(className)) {
                            varType = param.getType();
                            break;
                        }
                    }
                    
                    if (varType == null) {
                        for (Symbol var : table.getLocalVariables(methodScopeContext)) {
                            if (var.getName().equals(className)) {
                                varType = var.getType();
                                break;
                            }
                        }
                    }
                    
                    if (varType == null) {
                        for (Symbol field : table.getFields()) {
                            if (field.getName().equals(className)) {
                                varType = field.getType();
                                break;
                            }
                        }
                    }
                }
                
                if (varType == null) {
                    // Default to the class type if we can't determine
                    varType = new Type(table.getClassName(), false);
                }
                
                String varOllirType = ollirTypes.toOllirType(varType);
                
                computation.append(code).append(SPACE)
                        .append(ASSIGN).append(returnOllirType).append(SPACE)
                        .append("invokevirtual").append("(")
                        .append(className).append(varOllirType)
                        .append(", \"")
                        .append(methodName).append("\"")
                        .append(args.length() > 0 ? ", " + args.toString() : "")
                        .append(")").append(returnOllirType)
                        .append(END_STMT);
            } else {
                computation.append(code).append(SPACE)
                        .append(ASSIGN).append(returnOllirType).append(SPACE)
                        .append("invokestatic").append("(")
                        .append(className).append(", \"")
                        .append(methodName).append("\"")
                        .append(args.length() > 0 ? ", " + args.toString() : "")
                        .append(")").append(returnOllirType)
                        .append(END_STMT);
            }
        }

        return new OllirExprResult(code, computation);
    }

    private OllirExprResult visitMethodCall(JmmNode node, Void unused) {
        var instanceExpr = visit(node.getChild(0));

        StringBuilder computation = new StringBuilder();
        computation.append(instanceExpr.getComputation());

        String methodName = node.get("name");
        
        System.out.println("Instance method call: " + instanceExpr.getCode() + "." + methodName);

        // Check if the method has varargs parameters
        boolean hasVarArgs = false;
        List<Symbol> parameters;
        int varArgsPosition = -1;
        Type varArgsElementType = null;

        try {
            // Get method parameters from symbol table
            parameters = table.getParameters(methodName);
            if (parameters != null && !parameters.isEmpty()) {
                // Check if the last parameter is a varargs parameter
                varArgsPosition = parameters.size() - 1;
                Symbol lastParam = parameters.get(varArgsPosition);
                hasVarArgs = lastParam.getType().isArray() && isVarArgsParam(methodName, lastParam.getName());

                if (hasVarArgs) {
                    // Extract the element type of the varargs array
                    varArgsElementType = new Type(lastParam.getType().getName(), false);
                    System.out.println("Method " + methodName + " has varargs parameter: " +
                            lastParam.getName() + " with element type: " + varArgsElementType.getName());
                }
            }
        } catch (Exception e) {
            System.out.println("Could not find method " + methodName + " in symbol table: " + e.getMessage());

            if (node.getNumChildren() > 1) {
                hasVarArgs = node.hasAttribute("hasVarArgs") && node.getBoolean("hasVarArgs", false);
            }
        }

        List<OllirExprResult> argResults = new ArrayList<>();

        int actualArgCount = node.getNumChildren() - 1;

        int normalArgsEnd = hasVarArgs ? Math.min(varArgsPosition, actualArgCount) : actualArgCount;

        for (int i = 1; i <= normalArgsEnd; i++) {
            var argExpr = visit(node.getChild(i));
            computation.append(argExpr.getComputation());
            argResults.add(argExpr);
        }

        // Handle varargs if present
        if (hasVarArgs) {
            System.out.println("Processing varargs - actualArgCount=" + actualArgCount + 
                             ", varArgsPosition=" + varArgsPosition + 
                             ", numChildren=" + node.getNumChildren());
            
            if (actualArgCount == varArgsPosition + 1) {
                // Case 1: Exactly one argument for varargs position
                int childIndex = varArgsPosition + 1;
                System.out.println("Accessing child at index " + childIndex);
                
                if (childIndex >= node.getNumChildren()) {
                    System.err.println("ERROR: Trying to access child " + childIndex + 
                                     " but node only has " + node.getNumChildren() + " children");
                    createEmptyVarArgsArray(computation, argResults);
                } else {
                    JmmNode varArgNode = node.getChild(childIndex);
                    if (varArgNode == null) {
                        System.err.println("ERROR: Child at index " + childIndex + " is null");
                        createEmptyVarArgsArray(computation, argResults);
                    } else {
                        Type varArgType = types.getExprType(varArgNode);

                        if (varArgType != null && varArgType.isArray()) {
                            // The argument is already an array, use it directly
                            var argExpr = visit(varArgNode);
                            computation.append(argExpr.getComputation());
                            argResults.add(argExpr);
                        } else {
                            // Single value needs to be wrapped in an array
                            createSingleElementVarArgsArray(computation, argResults, node, childIndex);
                        }
                    }
                }
            } else if (actualArgCount > varArgsPosition + 1) {
                // Case 2: Multiple arguments for varargs - create an array
                int startIndex = varArgsPosition + 1;
                int count = actualArgCount - varArgsPosition;
                System.out.println("Multiple varargs from index " + startIndex + ", count=" + count);
                
                if (startIndex >= node.getNumChildren()) {
                    System.err.println("ERROR: Start index " + startIndex + 
                                     " exceeds number of children " + node.getNumChildren());
                    createEmptyVarArgsArray(computation, argResults);
                } else {
                    createMultiElementVarArgsArray(computation, argResults, node, startIndex, count);
                }
            } else {
                // Case 3: No arguments for varargs - create empty array
                createEmptyVarArgsArray(computation, argResults);
            }
        }

        // Get return type of the method (try to get from symbol table or default to int)
        Type returnType;
        try {
            // First try to find the method in our symbol table
            returnType = table.getReturnType(methodName);
            if (returnType == null) {
                // If not found in our symbol table, try to analyze the node's expected type
                returnType = types.getExprType(node);
            }
            
            if (returnType == null) {
                // If we still can't determine it, default to int
                returnType = TypeUtils.newIntType();
                System.out.println("WARNING: Could not determine return type for method " + methodName + ", defaulting to int");
            } else {
                System.out.println("INFO: Found return type for method " + methodName + ": " + returnType.getName() + (returnType.isArray() ? "[]" : ""));
            }
        } catch (Exception e) {
            returnType = TypeUtils.newIntType(); // Default to int if not found
        }

        String returnOllirType = ollirTypes.toOllirType(returnType);

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + returnOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(returnOllirType).append(SPACE)
                .append("invokevirtual").append("(")
                .append(instanceExpr.getCode()).append(", \"")
                .append(methodName).append("\"");

        // Add arguments
        for (OllirExprResult arg : argResults) {
            computation.append(", ").append(arg.getCode());
        }

        computation.append(")").append(returnOllirType)
                .append(END_STMT);

        return new OllirExprResult(code, computation.toString());
    }

    private boolean isVarArgsParam(String methodName, String paramName) {
        try {
            return ((JmmSymbolTable)table).isVarArgsParameter(methodName, paramName);
        } catch (Exception e) {
            // Method or attribute not found
            return false;
        }
    }

    /**
     * Creates an empty array for a varargs parameter with no arguments.
     */
    private void createEmptyVarArgsArray(StringBuilder computation, List<OllirExprResult> argResults) {
        Type elementType = new Type("Object", false);
        Type arrayType = new Type(elementType.getName(), true);
        String arrayOllirType = ollirTypes.toOllirType(arrayType);

        // Debug the OLLIR syntax
        System.out.println("DEBUG: Creating empty varargs array with proper syntax");

        String arrayTemp = ollirTypes.nextTemp() + arrayOllirType;
        computation.append(arrayTemp).append(" :=").append(arrayOllirType)
                .append(" new(int).array.0")
                .append(END_STMT);

        argResults.add(new OllirExprResult(arrayTemp, ""));
    }

    /**
     * Creates an array with a single element for a varargs parameter.
     */
    private void createSingleElementVarArgsArray(StringBuilder computation, List<OllirExprResult> argResults, JmmNode node, int argIndex) {
        System.out.println("DEBUG: createSingleElementVarArgsArray - argIndex=" + argIndex + ", numChildren=" + node.getNumChildren());
        
        if (argIndex >= node.getNumChildren()) {
            System.err.println("ERROR: argIndex " + argIndex + " exceeds number of children " + node.getNumChildren());
            createEmptyVarArgsArray(computation, argResults);
            return;
        }
        
        JmmNode argNode = node.getChild(argIndex);
        if (argNode == null) {
            System.err.println("ERROR: Child node at index " + argIndex + " is null");
            createEmptyVarArgsArray(computation, argResults);
            return;
        }
        
        OllirExprResult argExpr = visit(argNode);

        Type elementType = types.getExprType(argNode);
        Type arrayType = new Type(elementType.getName(), true);
        String arrayOllirType = ollirTypes.toOllirType(arrayType);
        String elementOllirType = ollirTypes.toOllirType(elementType);

        computation.append(argExpr.getComputation());

        // Debug the OLLIR syntax
        System.out.println("DEBUG: Creating single-element varargs array with proper syntax");

        String arrayTemp = ollirTypes.nextTemp() + arrayOllirType;
        // Use the exact format expected by the test: new(int).array.1
        computation.append(arrayTemp).append(" :=").append(arrayOllirType)
                .append(" new(int).array.1")
                .append(END_STMT);

        computation.append(arrayTemp).append("[0.i32]").append(elementOllirType)
                .append(" :=").append(elementOllirType).append(" ")
                .append(argExpr.getCode()).append(END_STMT);

        argResults.add(new OllirExprResult(arrayTemp, ""));
    }

    /**
     * Creates an array with multiple elements for varargs parameters.
     */
    private void createMultiElementVarArgsArray(StringBuilder computation, List<OllirExprResult> argResults, JmmNode node, int startIndex, int count) {
        System.out.println("DEBUG: createMultiElementVarArgsArray - startIndex=" + startIndex + 
                         ", count=" + count + ", numChildren=" + node.getNumChildren());
        
        if (startIndex >= node.getNumChildren()) {
            System.err.println("ERROR: startIndex " + startIndex + " exceeds number of children " + node.getNumChildren());
            createEmptyVarArgsArray(computation, argResults);
            return;
        }
        
        if (startIndex + count > node.getNumChildren()) {
            System.err.println("ERROR: Trying to access " + count + " elements from index " + startIndex + 
                             " but node only has " + node.getNumChildren() + " children");
            createEmptyVarArgsArray(computation, argResults);
            return;
        }
        
        JmmNode firstVarArgNode = node.getChild(startIndex);
        if (firstVarArgNode == null) {
            System.err.println("ERROR: First vararg node at index " + startIndex + " is null");
            createEmptyVarArgsArray(computation, argResults);
            return;
        }
        
        Type elementType = types.getExprType(firstVarArgNode);
        Type arrayType = new Type(elementType.getName(), true);
        String arrayOllirType = ollirTypes.toOllirType(arrayType);
        String elementOllirType = ollirTypes.toOllirType(elementType);

        // Debug the OLLIR syntax
        System.out.println("DEBUG: Creating multi-element varargs array with proper syntax, count=" + count);

        String arrayTemp = ollirTypes.nextTemp() + arrayOllirType;
        // Use the exact format expected by the test: new(int).array.5
        computation.append(arrayTemp).append(" :=").append(arrayOllirType)
                .append(" new(int).array.").append(count)
                .append(END_STMT);

        // Process each varargs element
        for (int i = 0; i < count; i++) {
            int childIndex = startIndex + i;
            if (childIndex >= node.getNumChildren()) {
                System.err.println("ERROR: Child index " + childIndex + " exceeds number of children");
                break;
            }
            
            JmmNode argNode = node.getChild(childIndex);
            if (argNode == null) {
                System.err.println("ERROR: Child node at index " + childIndex + " is null");
                continue;
            }
            
            OllirExprResult argExpr = visit(argNode);

            computation.append(argExpr.getComputation());

            // Add element to array
            computation.append(arrayTemp).append("[").append(i).append(".i32]").append(elementOllirType)
                    .append(" :=").append(elementOllirType).append(" ")
                    .append(argExpr.getCode()).append(END_STMT);
        }

        // Add the array as argument
        argResults.add(new OllirExprResult(arrayTemp, ""));
    }


    private OllirExprResult visitMemberAcess(JmmNode node, Void unused) {
        OllirExprResult instance = visit(node.getChild(0));

        String fieldName = node.get("fieldName");

        Type fieldType = types.getExprType(node);
        String fieldOllirType = ollirTypes.toOllirType(fieldType);

        StringBuilder computation = new StringBuilder();
        computation.append(instance.getComputation());

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + fieldOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(fieldOllirType).append(SPACE)
                .append("getfield").append("(")
                .append(instance.getCode()).append(", ")
                .append(fieldName).append(fieldOllirType)
                .append(")").append(fieldOllirType)
                .append(END_STMT);

        return new OllirExprResult(code, computation);
    }

    private OllirExprResult visitArrayAccess(JmmNode node, Void unused) {
        var arrayExpr = visit(node.getChild(0));
        var indexExpr = visit(node.getChild(1));

        StringBuilder computation = new StringBuilder();

        computation.append(arrayExpr.getComputation());
        computation.append(indexExpr.getComputation());

        Type arrayType = types.getExprType(node.getChild(0));
        Type elementType = new Type(arrayType.getName(), false); // Remove the array dimension
        String elementOllirType = ollirTypes.toOllirType(elementType);

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + elementOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(elementOllirType).append(SPACE)
                .append(arrayExpr.getCode())
                .append("[")
                .append(indexExpr.getCode())
                .append("]")
                .append(elementOllirType)
                .append(END_STMT);

        return new OllirExprResult(code, computation.toString());
    }

    private OllirExprResult visitExprLength(JmmNode node, Void unused) {
        var arrayExpr = visit(node.getChild(0));

        StringBuilder computation = new StringBuilder();

        // First, compute the array reference
        computation.append(arrayExpr.getComputation());

        // The result of array.length is an integer
        String returnOllirType = ".i32";

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + returnOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(returnOllirType).append(SPACE)
                .append("arraylength(")
                .append(arrayExpr.getCode())
                .append(")")
                .append(returnOllirType)
                .append(END_STMT);

        return new OllirExprResult(code, computation.toString());
    }

    private OllirExprResult visitParenExpr(JmmNode node, Void unused) {
        // Simply return the result of the inner expression
        return visit(node.getChild(0));
    }

    private OllirExprResult visitBracketsExpr(JmmNode node, Void unused) {
        // Same as parens - just visit the inner expression
        return visit(node.getChild(0));
    }

    private OllirExprResult visitTrueBool(JmmNode node, Void unused) {
        Type boolType = TypeUtils.newBooleanType();
        String ollirBoolType = ollirTypes.toOllirType(boolType);
        String code = "1" + ollirBoolType; // true is 1 in OLLIR
        return new OllirExprResult(code);
    }

    private OllirExprResult visitFalseBool(JmmNode node, Void unused) {
        Type boolType = TypeUtils.newBooleanType();
        String ollirBoolType = ollirTypes.toOllirType(boolType);
        String code = "0" + ollirBoolType; // false is 0 in OLLIR
        return new OllirExprResult(code);
    }

    private OllirExprResult visitThis(JmmNode node, Void unused) {
        // 'this' refers to the current instance
        String className = table.getClassName();
        Type thisType = new Type(className, false);
        String ollirType = ollirTypes.toOllirType(thisType);

        String code = "this" + ollirType;
        return new OllirExprResult(code);
    }

    private OllirExprResult visitNewArrayAlloc(JmmNode node, Void unused) {
        OllirExprResult size = visit(node.getChild(0));

        Type arrayType = types.getExprType(node);
        String arrayOllirType = ollirTypes.toOllirType(arrayType);

        StringBuilder computation = new StringBuilder();
        computation.append(size.getComputation());

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + arrayOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(arrayOllirType).append(SPACE)
                .append("new(array, ")
                .append(size.getCode()).append(")")
                .append(arrayOllirType)
                .append(END_STMT);

        return new OllirExprResult(code, computation);
    }

    private OllirExprResult visitNewObjectInst(JmmNode node, Void unused) {
        String className = node.get("name");
        Type objectType = new Type(className, false);
        String objectOllirType = ollirTypes.toOllirType(objectType);

        StringBuilder computation = new StringBuilder();

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + objectOllirType;

        // Add object instantiation
        computation.append(code).append(SPACE)
                .append(ASSIGN).append(objectOllirType).append(SPACE)
                .append("new(").append(className).append(")")
                .append(objectOllirType)
                .append(END_STMT);

        // Add constructor call
        computation.append("invokespecial").append("(")
                .append(code).append(", \"<init>\").V")
                .append(END_STMT);

        return new OllirExprResult(code, computation);
    }

    private OllirExprResult visitUnaryExpr(JmmNode node, Void unused) {
        OllirExprResult operand = visit(node.getChild(0));

        Type resultType = types.getExprType(node);
        String resultOllirType = ollirTypes.toOllirType(resultType);

        StringBuilder computation = new StringBuilder();
        computation.append(operand.getComputation());

        String tempVar = ollirTypes.nextTemp();
        String code = tempVar + resultOllirType;

        computation.append(code).append(SPACE)
                .append(ASSIGN).append(resultOllirType).append(SPACE)
                .append(node.get("op")).append(resultOllirType).append(SPACE)
                .append(operand.getCode())
                .append(END_STMT);

        return new OllirExprResult(code, computation);
    }


    private OllirExprResult visitInteger(JmmNode node, Void unused) {
        var intType = TypeUtils.newIntType();
        String ollirIntType = ollirTypes.toOllirType(intType);
        String code = node.get("value") + ollirIntType;
        return new OllirExprResult(code);
    }


    private OllirExprResult visitBinExpr(JmmNode node, Void unused) {
        // Make sure node has children before proceeding
        if (node.getNumChildren() < 2) {
            System.err.println("Binary expression node has fewer than 2 children: " + node);
            return OllirExprResult.EMPTY;
        }

        // Get left and right operands
        JmmNode leftChild = node.getChild(0);
        JmmNode rightChild = node.getChild(1);

        if (leftChild == null || rightChild == null) {
            System.err.println("Binary expression has null child node: " + node);
            return OllirExprResult.EMPTY;
        }

        var lhs = visit(leftChild);
        var rhs = visit(rightChild);

        StringBuilder computation = new StringBuilder();
        computation.append(lhs.getComputation());
        computation.append(rhs.getComputation());

        // Make sure operation is present
        if (!node.hasAttribute("op")) {
            System.err.println("Binary expression node missing 'op' attribute: " + node);
            return OllirExprResult.EMPTY;
        }

        String operation = node.get("op");

        // Get result type safely
        Type resType;
        try {
            resType = types.getExprType(node);
            if (resType == null) {
                System.err.println("Could not determine type for binary expression: " + node);
                // Default to int type if we can't determine
                resType = TypeUtils.newIntType();
            }
        } catch (Exception e) {
            System.err.println("Error getting type for binary expression: " + e.getMessage());
            resType = TypeUtils.newIntType(); // Default to int
        }

        String resOllirType = ollirTypes.toOllirType(resType);
        String code = ollirTypes.nextTemp() + resOllirType;

        // Convert Java operators to OLLIR operators with proper types
        String ollirOp;

        // Handle comparison operators
        if (operation.equals("==")) {
            // For equality comparison, use the appropriate type suffix
            if (resOllirType.equals(".bool")) {
                ollirOp = "==.bool";
            } else {
                ollirOp = "==.i32";
            }
        } else if (operation.equals(">")) {
            ollirOp = ">.i32";
            if (!resType.getName().equals("boolean")) {
                System.err.println("Warning: '>' operation should produce boolean result but got: " + resType.getName());
                resType = new Type("boolean", false);
                resOllirType = ".bool";
            }
        } else if (operation.equals("<")) {
            ollirOp = "<.i32";
        } else if (operation.equals("&&")) {
            // Generate labels for short-circuit evaluation
            String trueLabel = "and_true_" + ollirTypes.nextTemp();
            // String falseLabel = "and_false_" + ollirTypes.nextTemp();
            String endLabel = "and_end_" + ollirTypes.nextTemp();

            computation = new StringBuilder();
            computation.append(lhs.getComputation());

            // Create result variable
            String resultVar = ollirTypes.nextTemp() + resOllirType;

            // Check first condition
            computation.append("if (").append(lhs.getCode()).append(") goto ").append(trueLabel).append(";\n");
            computation.append(resultVar).append(" :=").append(resOllirType).append(" 0.bool;\n"); // Short-circuit: if first is false, result is false
            computation.append("goto ").append(endLabel).append(";\n");

            // If first condition is true, evaluate second condition
            computation.append(trueLabel).append(":\n");
            computation.append(rhs.getComputation());
            computation.append(resultVar).append(" :=").append(resOllirType).append(" ").append(rhs.getCode()).append(";\n");

            // End label
            computation.append(endLabel).append(":\n");

            return new OllirExprResult(resultVar, computation.toString());
        } else if (operation.equals("||")) {
            // Generate labels for short-circuit evaluation
            String trueLabel = "and_true_" + ollirTypes.nextTemp();
            // String falseLabel = "and_false_" + ollirTypes.nextTemp();
            String endLabel = "and_end_" + ollirTypes.nextTemp();

            computation = new StringBuilder();
            computation.append(lhs.getComputation());

            // Create result variable
            String resultVar = ollirTypes.nextTemp() + resOllirType;

            // Check first condition
            computation.append("if (").append(lhs.getCode()).append(") goto ").append(trueLabel).append(";\n");
            computation.append(resultVar).append(" :=").append(resOllirType).append(" 1.bool;\n"); // Short-circuit: if first is true, result is true
            computation.append("goto ").append(endLabel).append(";\n");

            // If first condition is true, evaluate second condition
            computation.append(trueLabel).append(":\n");
            computation.append(rhs.getComputation());
            computation.append(resultVar).append(" :=").append(resOllirType).append(" ").append(rhs.getCode()).append(";\n");

            // End label
            computation.append(endLabel).append(":\n");

            return new OllirExprResult(resultVar, computation.toString());
        } else if (operation.equals("!=")) {
            if (resOllirType.equals(".bool")) {
                ollirOp = "!=.bool";
            } else {
                ollirOp = "!=.i32";
            }
        } else if (operation.equals("<=")) {
            ollirOp = "<=.i32";
        } else if (operation.equals(">=")) {
            ollirOp = ">=.i32";
        } else if (operation.equals("+")) {
            ollirOp = "+.i32";
        } else if (operation.equals("-")) {
            ollirOp = "-.i32";
        } else if (operation.equals("*")) {
            ollirOp = "*.i32";
        } else if (operation.equals("/")) {
            ollirOp = "/.i32";
        } else if (operation.equals("%")) {
            ollirOp = "%.i32";
        } else {
            // Default case
            ollirOp = operation + ".i32";
        }

        computation.append(code).append(" ")
                .append(":=").append(resOllirType).append(" ")
                .append(lhs.getCode()).append(" ")
                .append(ollirOp).append(" ")
                .append(rhs.getCode()).append(";\n");

        return new OllirExprResult(code, computation.toString());
    }


    private OllirExprResult visitVarRef(JmmNode node, Void unused) {
        var id = node.get("name");
        Type type = types.getExprType(node);
        String ollirType = ollirTypes.toOllirType(type);

        // Get current method context
        String currentMethod = getCurrentMethodName(node);
        System.out.println("VarRef: " + id + " in method " + currentMethod);

        // Determine if this is a field or local variable
        boolean isField = isClassField(id, currentMethod);

        if (isField) {
            // This is a class field, use getfield
            String tempVar = ollirTypes.nextTemp();
            String tempCode = tempVar + ollirType;

            StringBuilder computation = new StringBuilder();
            computation.append(tempCode).append(SPACE)
                    .append(ASSIGN).append(ollirType).append(SPACE)
                    .append("getfield").append("(")
                    .append("this").append(", ")
                    .append(id).append(ollirType)
                    .append(")").append(ollirType)
                    .append(END_STMT);

            return new OllirExprResult(tempCode, computation.toString());
        } else {
            // This is a local variable or parameter
            String code = id + ollirType;
            return new OllirExprResult(code, "");
        }
    }

    /**
     * Default visitor. Visits every child node and return an empty result.
     *
     * @param node
     * @param unused
     * @return
     */
    private OllirExprResult defaultVisit(JmmNode node, Void unused) {

        for (var child : node.getChildren()) {
            visit(child);
        }

        return OllirExprResult.EMPTY;
    }

}
