package pt.up.fe.comp2025.ast;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp2025.symboltable.JmmSymbolTable;
import pt.up.fe.specs.util.exceptions.NotImplementedException;

import java.util.List;

/**
* Utility methods regarding types.
*/
public class TypeUtils {


private final JmmSymbolTable table;

public TypeUtils(SymbolTable table) {
    this.table = (JmmSymbolTable) table;
}

public static Type newIntType() {
    return new Type("int", false);
}

public static Type newIntArrayType() {
    return new Type("int", true);
}

public static Type newBooleanType() {
    return new Type("boolean", false);
}

public static Type newStringType() {
    return new Type("String", false);
}

public static Type newVoidType() {
    return new Type("void", false);
}

public static Type newStringArrayType() {
    return new Type("String", true);
}

public boolean isPrimitiveType(String typeName) {
    return typeName.equals("int") || typeName.equals("boolean");
}

public boolean isBuiltInType(String typeName) {
    return isPrimitiveType(typeName) || typeName.equals("String") || typeName.equals("void");
}

    public static Type convertType(JmmNode typeNode) {
        String name;
        boolean isArray = false;

        System.out.println("Converting type node: " + typeNode + ", attributes: " + typeNode.getAttributes());

        // Check if the type node has isArray attribute
        if (typeNode.hasAttribute("isArray")) {
            isArray = typeNode.getBoolean("isArray", false);
        }

        // Check if it's a varargs parameter (this should set isArray=true)
        if (typeNode.hasAttribute("isVarArgs") && typeNode.getBoolean("isVarArgs", false)) {
            isArray = true;
            System.out.println("Found varargs type, setting isArray=true");
        }

        // Get the type name
        name = typeNode.get("name");

        System.out.println("Converted type: " + name + (isArray ? "[]" : ""));
        return new Type(name, isArray);
    }

public boolean isImportedType(String typeName) {
    boolean result = table.getImports().contains(typeName);
    if (result) {
        System.out.println("Type " + typeName + " is directly imported");
        return true;
    }

    for (String importPath : table.getImports()) {
        System.out.println("Checking import path: " + importPath);
        String simpleName = importPath;
        int lastDot = importPath.lastIndexOf('.');
        if (lastDot >= 0) {
            simpleName = importPath.substring(lastDot + 1);
        }

        System.out.println("Comparing " + simpleName + " with " + typeName);
        if (simpleName.equals(typeName)) {
            System.out.println("Match found! " + typeName + " is imported");
            return true;
        }
    }

    System.out.println("Type " + typeName + " is NOT imported");
    return false;
}

    private Type getUnaryExprType(JmmNode node) {
        String op = node.get("op");
        Type operandType = getExprType(node.getChild(0));

        return switch (op) {
            case "!" -> newBooleanType();
            case "-" -> newIntType();
            default -> throw new NotImplementedException("Unary operator not supported: " + op);
        };
    }

/**
 * Check if sourceType can be assigned to targetType based on:
 * - Direct type compatibility
 * - Inheritance (child to parent)
 * - Import-based compatibility assumptions
 */
public boolean areTypesCompatible(Type targetType, Type sourceType) {
    // Same type and array status is always compatible
    if (targetType.getName().equals(sourceType.getName()) &&
            targetType.isArray() == sourceType.isArray()) {
        return true;
    }
    // Different array status is never compatible
    if (targetType.isArray() != sourceType.isArray()) {
        return false;
    }

    String targetName = targetType.getName();
    String sourceName = sourceType.getName();

    // Unknown types are considered compatible
    if (targetName.equals("unknown") || sourceName.equals("unknown")) {
        return true;
    }

    // Imports
    if (isImportedType(targetName) || isImportedType(sourceName)) {
        // For imported types, assume they might be compatible (potential inheritance)
        return true;
    }

    // Strict primitive type checking
    if (isPrimitiveType(targetName) && isPrimitiveType(sourceName)) {
        return targetName.equals(sourceName); // Primitives must match exactly
    }

    // Primitive types are never compatible with non-primitive types
    if (isPrimitiveType(targetName) && !isPrimitiveType(sourceName)) {
        return false;
    }
    if (isPrimitiveType(sourceName) && !isPrimitiveType(targetName)) {
        return false;
    }

    // Current class can be assigned to superclass (inheritance)
    if (table.getSuper() != null && targetName.equals(table.getSuper()) &&
            sourceName.equals(table.getClassName())) {
        return true;
    }

    // Otherwise, no compatibility
    return false;
}

/**
 * Gets the {@link Type} of an arbitrary expression.
 */
public Type getExprType(JmmNode expr) {
    String kind = expr.getKind();

    switch (kind) {
        case "IntegerLiteral":
            return new Type("int", false);

        case "TrueBool":
        case "FalseBool":
            return new Type("boolean", false);

        case "VarRefExpr":
            return getVariableType(expr);

        case "UnaryExpr":
            String op = expr.get("op");
            Type operandType = getExprType(expr.getChild(0));

            if (op.equals("!")) {
                if (!operandType.getName().equals("boolean")) {
                    return new Type("unknown", false);
                }
                return new Type("boolean", false);
            }
            return operandType;

        case "BinaryExpr":
            return getBinaryExprType(expr);

        case "ParenExpr":
            return getExprType(expr.getChild(0));

        case "ArrayAccess":
            Type arrayType = getExprType(expr.getChild(0));
            if (arrayType.isArray()) {
                return new Type(arrayType.getName(), false);
            }
            return new Type("unknown", false); // Not an array

        case "MethodCall":
            return getMethodReturnType(expr);

        case "MemberAcess":
            return getMemberAccessType(expr);

        case "ExprLength":
            Type lenArrayType = getExprType(expr.getChild(0));
            if (lenArrayType.isArray()) {
                return new Type("int", false);
            }
            return new Type("unknown", false); // Length only works on arrays

        case "NewArrayAlloc":
            return new Type("int", true);

        case "NewObjectInst":
            String className = expr.get("name");
            System.out.println("NewObjectInst with class name: " + className);
            if (className.equals(table.getClassName()) ||
                    isImportedType(className) ||
                    (table.getSuper() != null && className.equals(table.getSuper()))) {
                System.out.println("Returning type: " + className);
                return new Type(className, false);
            }
            System.out.println("Class not found, returning unknown: " + className);
            return new Type("unknown", false); // Class not found

        case "This":
        case "ThisExpr":
            return new Type(table.getClassName(), false);

        case "BracketsExpr":
            if (expr.getChildren().isEmpty()) {
                return new Type("unknown", true);
            }

            Type firstType = getExprType(expr.getChild(0));
            for (int i = 1; i < expr.getChildren().size(); i++) {
                Type nextType = getExprType(expr.getChild(i));
                if (!firstType.getName().equals(nextType.getName())) {
                    return new Type("unknown", true); // Mixed types
                }
            }
            return new Type(firstType.getName(), true);

        default:
            return new Type("unknown", false);
    }
}

    /**
     * Checks if the given type is numeric (currently only supports 'int' without array flag).
     */
    private boolean isNumericType(Type type) {
        return "int".equals(type.getName()) && !type.isArray();
    }

    /**
     * Checks if the given type is a boolean (without array flag).
     */
    private boolean isBooleanType(Type type) {
        return "boolean".equals(type.getName()) && !type.isArray();
    }

    /**
     * Validates operands for arithmetic operations (+, -, *, /, %).
     */
    private boolean areArithmeticOperandsValid(Type left, Type right) {
        return isNumericType(left) && isNumericType(right);
    }

    /**
     * Validates operands for logical operations (&&).
     */
    private boolean areLogicalOperandsValid(Type left, Type right) {
        return isBooleanType(left) && isBooleanType(right);
    }

    /**
     * Validates operands for comparison operations (<).
     */
    private boolean areComparisonOperandsValid(Type left, Type right) {
        return isNumericType(left) && isNumericType(right);
    }

    /**
     * Determines the result type for a binary operation given the operator and operand types.
     * Returns null if the operation is not valid.
     */
    private Type getBinaryOperationResultType(String operator, Type left, Type right) {
        switch (operator) {
            case "+":
            case "-":
            case "*":
            case "/":
            case "%":
                return areArithmeticOperandsValid(left, right) ? new Type("int", false) : null;
            case ">":  // Explicitly handle ">" operator
            case "<":
            case "<=":
            case ">=":
            case "==":
            case "!=":
                return areComparisonOperandsValid(left, right) ? new Type("boolean", false) : null;
            case "&&":
            case "||":
                return areLogicalOperandsValid(left, right) ? new Type("boolean", false) : null;
            default:
                System.err.println("Unhandled binary operator: " + operator);
                return null;
        }
    }

    /**
     * Returns a descriptive error message for an invalid binary operation.
     */
    public String getInvalidOperationMessage(String operator, Type left, Type right) {
        StringBuilder message = new StringBuilder("Invalid operation: cannot use operator '")
                .append(operator)
                .append("' with operands of type ")
                .append(left.getName()).append(left.isArray() ? "[]" : "")
                .append(" and ")
                .append(right.getName()).append(right.isArray() ? "[]" : "");
        return message.toString();
    }

    /**
     * Checks if a binary expression is valid based on operator and operand types.
     * Returns true if valid, false otherwise.
     */
    public boolean isValidBinaryExpression(JmmNode expr) {
        if (!expr.getKind().equals("BinaryExpr")) {
            return false;
        }

        String op = expr.get("op");
        Type leftType = getExprType(expr.getChild(0));
        Type rightType = getExprType(expr.getChild(1));

        Type resultType = getBinaryOperationResultType(op, leftType, rightType);
        return resultType != null;
    }

    /**
     * Process binary expressions to determine their type.
     */
    private Type getBinaryExprType(JmmNode expr) {
        String op = expr.get("op");
        Type leftType = getExprType(expr.getChild(0));
        Type rightType = getExprType(expr.getChild(1));

        // Use the helper methods to get the result type
        Type resultType = getBinaryOperationResultType(op, leftType, rightType);
        if (resultType != null) {
            return resultType;
        }
        // If the operands do not satisfy the operator criteria, return "unknown"
        return new Type("unknown", false);
    }


    /**
     * Gets the type of a variable reference, searching through different scopes.
     */
    private Type getVariableType(JmmNode varRef) {
        if (!varRef.hasAttribute("name")) {
            System.out.println("VarRef missing name attribute: " + varRef);
            return new Type("unknown", false);
        }

        String varName = varRef.get("name");
        String currentMethodName = findEnclosingMethod(varRef);

        //System.out.println("Looking up variable: " + varName + " in method: " + currentMethodName);

        if (currentMethodName != null) {
            // Check method parameters
            for (Symbol param : table.getParameters(currentMethodName)) {
                if (param.getName().equals(varName)) {
                    if (table.isVarArgsParameter(currentMethodName, varName)) {
                        return new Type(param.getType().getName(), true); // Force array type
                    }
                    //System.out.println("Found in parameters: " + param.getType().getName());
                    return param.getType();
                }
            }

            // Check local variables
            for (Symbol local : table.getLocalVariables(currentMethodName)) {
                if (local.getName().equals(varName)) {
                    //System.out.println("Found in locals: " + local.getType().getName());
                    return local.getType();
                }
            }
        }

        // Check class fields
        for (Symbol field : table.getFields()) {
            if (field.getName().equals(varName)) {
                //System.out.println("Found in fields: " + field.getType().getName());
                return field.getType();
            }
        }

        // Check if it's an imported class name
        if (isImportedType(varName)) {
            //System.out.println("Found as imported type: " + varName);
            return new Type(varName, false);
        }

        System.out.println("Variable not found: " + varName);
        return new Type("unknown", false);
    }

    /**
     * Find the method name that contains this node.
     */
    private String findEnclosingMethod(JmmNode node) {
        JmmNode current = node;
        while (current != null) {
            //System.out.println("Finding method, current node: " + current.getKind());
            if (current.getKind().equals("MethodDecl")) {
                return current.get("name");
            }
            current = current.getParent();
        }
        //System.out.println("No enclosing method found for node: " + node.getKind());
        return null;
    }

    /**
     * Resolves the return type of a method call.
     */
    private Type getMethodReturnType(JmmNode methodCall) {
        String methodName = methodCall.get("name");

        // Must have at least one child (the object the method is called on)
        if (methodCall.getNumChildren() == 0) {
            return new Type("unknown", false);
        }

        JmmNode callerExpr = methodCall.getChild(0);
        Type callerType = getExprType(callerExpr);

        // If the caller is of the current class type
        if (callerType.getName().equals(table.getClassName())) {
            // Check if the method exists in the class
            if (table.getMethods().contains(methodName)) {
                return table.getReturnType(methodName);
            }

            // Check if the method might be inherited from a superclass
            if (table.getSuper() != null) {
                // We don't have access to superclass method details
                // Assume it's valid and return an unknown type
                return new Type("unknown", false);
            }
        }

        // If the caller is of an imported type
        if (isImportedType(callerType.getName())) {
            // We don't have access to method details for imported types
            // Assume it's valid and return an unknown type
            return new Type("unknown", false);
        }

        // If the caller is 'this'
        if (callerType.getName().equals(table.getClassName())) {
            if (table.getMethods().contains(methodName)) {
                return table.getReturnType(methodName);
            }
        }

        return new Type("unknown", false);
    }

    /**
     * Resolves the type of a member access expression (obj.field).
     */
    private Type getMemberAccessType(JmmNode memberAccess) {
        JmmNode objectExpr = memberAccess.getChild(0);
        Type objectType = getExprType(objectExpr);
        String fieldName = memberAccess.get("name");

        // If the object is of the current class type
        if (objectType.getName().equals(table.getClassName())) {
            // Look for the field in the class
            for (Symbol field : table.getFields()) {
                if (field.getName().equals(fieldName)) {
                    return field.getType();
                }
            }

            // If there's a superclass, the field might be inherited
            if (table.getSuper() != null) {
                return new Type("unknown", false);
            }
        }

        // If the object type is imported, assume the field exists
        if (isImportedType(objectType.getName())) {
            return new Type("unknown", false);
        }

        return new Type("unknown", false);
    }

    /**
     * Checks if a method is static based on method name and context.
     * Currently identifies 'main' as static and others as instance methods.
     */
    public boolean isStaticMethod(String methodName) {
        // 'main' is always static by convention in Java
        if ("main".equals(methodName)) {
            return true;
        }

        // In a complete implementation, check method modifiers
        // For now, all other methods are considered instance methods
        return false;
    }

    /**
     * Identifies if a method call appears to be a static call.
     * Static calls typically use the form ClassName.methodName()
     */
    public boolean isStaticMethodCallPattern(JmmNode methodCall) {
        // If the method call's first child is a class name reference rather than an object
        if (methodCall.getNumChildren() > 0) {
            JmmNode firstChild = methodCall.getChild(0);
            if (firstChild.getKind().equals("ClassRef")) {
                return true;
            }

            // Another pattern: if first child is a VarRefExpr and its type is a class name
            if (firstChild.getKind().equals("VarRefExpr")) {
                Type varType = getExprType(firstChild);
                // If the variable is capitalized, it's likely a class name
                if (Character.isUpperCase(varType.getName().charAt(0))) {
                    return true;
                }
            }
        }
        return false;
    }

    private Type getVarType(String name) {
        // Check local variables first
        List<Symbol> locals = table.getLocalVariables("main");
        for (Symbol symbol : locals) {
            if (symbol.getName().equals(name)) {
                return symbol.getType();
            }
        }

        // Check parameters
        List<Symbol> params = table.getParameters("main");
        for (Symbol symbol : params) {
            if (symbol.getName().equals(name)) {
                return symbol.getType();
            }
        }

        // Check fields
        List<Symbol> fields = table.getFields();
        for (Symbol symbol : fields) {
            if (symbol.getName().equals(name)) {
                return symbol.getType();
            }
        }

        // Default to int if not found
        return newIntType();
    }

    /**
     * Resolves the type of a reference (variable) in a given method context.
     */
    public Type getTypeOfReference(String ref, String methodName) {
        // 1. Check local variables
        for (var local : table.getLocalVariables(methodName)) {
            if (local.getName().equals(ref)) {
                return local.getType();
            }
        }

        // 2. Check parameters
        for (var param : table.getParameters(methodName)) {
            if (param.getName().equals(ref)) {
                return param.getType();
            }
        }

        // 3. Check fields
        for (var field : table.getFields()) {
            if (field.getName().equals(ref)) {
                return field.getType();
            }
        }

        return null; // Not found
    }
}
