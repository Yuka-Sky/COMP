package pt.up.fe.comp2025.symboltable;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp2025.ast.TypeUtils;
import pt.up.fe.specs.util.SpecsCheck;
import pt.up.fe.specs.util.exceptions.NotImplementedException;

import java.util.*;

public class JmmSymbolTable extends AJmmSymbolTable {

    private final String className;
    private final String superClass;
    private final List<String> imports;
    private final List<Symbol> fields;
    private final List<String> methods;
    private final Map<String, Type> returnTypes;
    private final Map<String, List<Symbol>> params;
    private final Map<String, List<Symbol>> locals;
    private final Set<String> methodsWithVarargs = new HashSet<>();

    public JmmSymbolTable(String className,
                          String superClass,
                          List<String> imports,
                          List<String> methods,
                          Map<String, Type> returnTypes,
                          Map<String, List<Symbol>> params,
                          Map<String, List<Symbol>> locals,
                          List<Symbol> fields) {
        this.className = className;
        this.superClass = superClass;
        this.imports = imports;
        this.methods = methods;
        this.returnTypes = returnTypes;
        this.params = params;
        this.locals = locals;
        this.fields = fields;
    }

    @Override
    public List<String> getImports() {
        return imports;
    }

    @Override
    public String getClassName() {
        return className;
    }

    @Override
    public String getSuper() {
        return superClass;
    }

    @Override
    public List<Symbol> getFields() {
        return fields;
    }

    @Override
    public List<String> getMethods() {
        return methods;
    }

    @Override
    public Type getReturnType(String methodSignature) {
        return returnTypes.get(methodSignature);
    }

    @Override
    public List<Symbol> getParameters(String methodSignature) {
        return params.getOrDefault(methodSignature, Collections.emptyList());
    }

    @Override
    public List<Symbol> getLocalVariables(String methodSignature) {
        return locals.getOrDefault(methodSignature, Collections.emptyList());
    }

    @Override
    public String toString() {
        return print();
    }

    public void addVarargsMethod(String methodName) {
        methodsWithVarargs.add(methodName);
    }

    public boolean hasVarargs(String methodName) {
        return methodsWithVarargs.contains(methodName);
    }

    public boolean isVarArgsParameter(String methodName, String paramName) {
        // In Java, only the last parameter can be varargs
        if (!hasVarargs(methodName)) {
            return false;
        }

        List<Symbol> parameters = getParameters(methodName);
        if (parameters == null || parameters.isEmpty()) {
            return false;
        }

        // Get the last parameter
        Symbol lastParam = parameters.get(parameters.size() - 1);

        // Check if it's the parameter we're looking for
        return lastParam.getName().equals(paramName);
    }
}
