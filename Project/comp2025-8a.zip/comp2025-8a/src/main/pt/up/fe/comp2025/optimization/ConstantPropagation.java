package pt.up.fe.comp2025.optimization;

import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.ast.AJmmVisitor;
import pt.up.fe.comp2025.ast.TypeUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Collections;

public class ConstantPropagation extends AJmmVisitor<Map<String, Object>, Boolean> {

    private final TypeUtils typeUtils;

    // Map to track constants by scope (method name) -> variable name -> constant value
    private final Map<String, Map<String, Integer>> constantVariables;

    // Track the current method scope
    private String currentScope;

    // Statistics for reporting
    private int replacementCount = 0;

    public ConstantPropagation(TypeUtils typeUtils) {
        this.typeUtils = typeUtils;
        this.constantVariables = new HashMap<>();
    }

    @Override
    protected void buildVisitor() {
        // Set visit methods for specific node kinds
        addVisit("ClassDecl", this::visitClassDecl);
        addVisit("MethodDecl", this::visitMethodDecl);
        addVisit("AssignStmt", this::visitAssignStmt);
        addVisit("VarRefExpr", this::visitVarRefExpr);
        addVisit("BinaryExpr", this::visitBinaryExpr);
        addVisit("WhileStmt", this::visitWhileStmt);
        addVisit("IfElseStmt", this::visitIfElseStmt);

        setDefaultVisit(this::defaultVisit);
    }

    /**
     * Visits the ClassDecl node. Just processes all children.
     */
    private Boolean visitClassDecl(JmmNode node, Map<String, Object> data) {
        // Visit all methods and field declarations
        for (JmmNode child : node.getChildren()) {
            visit(child);
        }
        return true;
    }

    /**
     * Visits a method declaration and sets up a new scope for variables.
     */
    private Boolean visitMethodDecl(JmmNode node, Map<String, Object> data) {
        String methodName = node.get("name");
        this.currentScope = methodName;

        // Initialize constant map for this method
        constantVariables.put(methodName, new HashMap<>());

        // Process the method body
        for (JmmNode child : node.getChildren()) {
            visit(child);
        }

        return true;
    }

    /**
     * Handles while statements specifically to ensure proper constant propagation.
     */
    private Boolean visitWhileStmt(JmmNode node, Map<String, Object> data) {
        if (currentScope == null) {
            return defaultVisit(node, data);
        }

        // First, process the condition (first child)
        if (node.getNumChildren() > 0) {
            visit(node.getChild(0), data);
        }

        // Create a backup of constants before processing loop body
        Map<String, Integer> constantsBackup = new HashMap<>(constantVariables.get(currentScope));

        // Process the loop body (second child)
        if (node.getNumChildren() > 1) {
            visit(node.getChild(1), data);
        }

        // After processing the loop body, we might have updated variables that were constants
        // We take a conservative approach and only keep constants that didn't change in the loop
        Map<String, Integer> afterLoopConstants = constantVariables.get(currentScope);
        Map<String, Integer> safeConstants = new HashMap<>();

        // Only keep constants that are the same before and after loop processing
        for (Map.Entry<String, Integer> entry : constantsBackup.entrySet()) {
            String varName = entry.getKey();
            Integer valueBefore = entry.getValue();
            Integer valueAfter = afterLoopConstants.get(varName);

            // If the variable still has the same constant value, it's safe to keep
            if (valueAfter != null && valueAfter.equals(valueBefore)) {
                safeConstants.put(varName, valueBefore);
            }
        }

        // Update the constants map with only the safe constants
        constantVariables.get(currentScope).clear();
        constantVariables.get(currentScope).putAll(safeConstants);

        // Second pass for condition to apply propagation
        if (node.getNumChildren() > 0) {
            visit(node.getChild(0), data);
        }

        return true;
    }

    /**
     * Handles if/else statements to ensure proper constant propagation in both branches.
     */
    private Boolean visitIfElseStmt(JmmNode node, Map<String, Object> data) {
        if (currentScope == null) {
            return defaultVisit(node, data);
        }

        // First, process the condition (first child)
        if (node.getNumChildren() > 0) {
            visit(node.getChild(0), data);
        }

        // Create a backup of constants before processing if/else branches
        Map<String, Integer> constantsBeforeBranches = new HashMap<>(constantVariables.get(currentScope));

        // Process the if branch (second child)
        Map<String, Integer> ifBranchConstants = null;
        if (node.getNumChildren() > 1) {
            visit(node.getChild(1), data);
            // Save constants after processing if branch
            ifBranchConstants = new HashMap<>(constantVariables.get(currentScope));
        }

        // Restore original constants before processing else branch
        constantVariables.get(currentScope).clear();
        constantVariables.get(currentScope).putAll(constantsBeforeBranches);

        // Process the else branch (third child)
        Map<String, Integer> elseBranchConstants = null;
        if (node.getNumChildren() > 2) {
            visit(node.getChild(2), data);
            // Save constants after processing else branch
            elseBranchConstants = new HashMap<>(constantVariables.get(currentScope));
        }

        // After processing both branches, only keep variables that are constants with
        // the same value in both branches
        Map<String, Integer> finalConstants = new HashMap<>();

        // First, restore the original constants
        constantVariables.get(currentScope).clear();
        constantVariables.get(currentScope).putAll(constantsBeforeBranches);

        // Then determine which variables are constants in both branches with the same value
        if (ifBranchConstants != null && elseBranchConstants != null) {
            for (Map.Entry<String, Integer> entry : ifBranchConstants.entrySet()) {
                String varName = entry.getKey();
                Integer ifValue = entry.getValue();
                Integer elseValue = elseBranchConstants.get(varName);

                // If the variable is a constant with the same value in both branches,
                // we can safely propagate it
                if (elseValue != null && elseValue.equals(ifValue)) {
                    finalConstants.put(varName, ifValue);
                }
            }
        }

        // Update the constants map with only variables that remain constant across both branches
        for (String varName : constantsBeforeBranches.keySet()) {
            if (!finalConstants.containsKey(varName)) {
                constantVariables.get(currentScope).remove(varName);
            }
        }

        // Apply any new constants from finalConstants
        constantVariables.get(currentScope).putAll(finalConstants);

        return true;
    }

    /**
     * Handles assignment statements where constants may be determined.
     */
    private Boolean visitAssignStmt(JmmNode node, Map<String, Object> data) {
        if (currentScope == null) {
            // Not inside a method, skip
            return defaultVisit(node, data);
        }

        // Get left and right sides of the assignment
        List<JmmNode> children = node.getChildren();
        if (children.size() != 2) {
            return defaultVisit(node, data);
        }

        JmmNode left = children.get(0);
        JmmNode right = children.get(1);

        // Check if left side is a simple variable reference
        if (left.getKind().equals("VarRefExpr")) {
            String varName = left.get("name");

            // Try to evaluate the right side as a constant
            Integer constantValue = evaluateConstantExpression(right);

            if (constantValue != null) {
                // We found a constant value, store it
                constantVariables.get(currentScope).put(varName, constantValue);
            } else {
                // Variable is assigned a non-constant, remove it from our map
                constantVariables.get(currentScope).remove(varName);
            }
        }

        // Visit right side of assignment to apply constant propagation
        visit(right, data);

        return true;
    }

    /**
     * Replaces variable references with constants when possible.
     */
    private Boolean visitVarRefExpr(JmmNode node, Map<String, Object> data) {
        if (currentScope == null) {
            return defaultVisit(node, data);
        }

        String varName = node.get("name");
        Map<String, Integer> scopeConstants = constantVariables.get(currentScope);

        // Check if this variable has a known constant value
        if (scopeConstants != null && scopeConstants.containsKey(varName)) {
            Integer constantValue = scopeConstants.get(varName);

            // Replace the variable reference with an integer literal
            JmmNode intLiteral = createIntegerLiteral(constantValue);
            node.replace(intLiteral);
            replacementCount++; // Track replacements for reporting
            return true;
        }

        return defaultVisit(node, data);
    }

    /**
     * Special handling for binary expressions to perform constant folding.
     */
    private Boolean visitBinaryExpr(JmmNode node, Map<String, Object> data) {
        // First visit the children to apply constant propagation
        visit(node.getChild(0), data);
        visit(node.getChild(1), data);

        // After visiting, try to evaluate as constant
        Integer constantValue = evaluateConstantExpression(node);
        if (constantValue != null) {
            // If we can evaluate to a constant, replace with an integer literal
            JmmNode intLiteral = createIntegerLiteral(constantValue);
            node.replace(intLiteral);
            replacementCount++; // Track constant folding as a replacement
            return true;
        }

        return true;
    }

    /**
     * Default visit method for nodes without specific handlers.
     */
    private Boolean defaultVisit(JmmNode node, Map<String, Object> data) {
        for (JmmNode child : node.getChildren()) {
            visit(child, data);
        }
        return true;
    }

    /**
     * Creates a new IntegerLiteral node with the given value.
     */
    private JmmNode createIntegerLiteral(Integer value) {
        JmmNode intLiteral = node("IntegerLiteral");
        intLiteral.put("value", value.toString());
        return intLiteral;
    }

    /**
     * Returns the number of constant replacements made during optimization.
     */
    public int getReplacementCount() {
        return replacementCount;
    }

    /**
     * Helper method to create a new JmmNode with specific kind.
     */
    private JmmNode node(String kind) {
        return new pt.up.fe.comp.jmm.ast.JmmNodeImpl(Collections.singletonList(kind));
    }

    /**
     * Attempts to evaluate an expression as a constant value.
     * Returns the constant value, or null if the expression is not constant.
     */
    private Integer evaluateConstantExpression(JmmNode node) {
        switch (node.getKind()) {
            case "IntegerLiteral":
                return Integer.parseInt(node.get("value"));

            case "VarRefExpr":
                if (currentScope != null) {
                    String varName = node.get("name");
                    Map<String, Integer> scopeConstants = constantVariables.get(currentScope);
                    if (scopeConstants != null && scopeConstants.containsKey(varName)) {
                        return scopeConstants.get(varName);
                    }
                }
                return null;

            case "BinaryExpr":
                List<JmmNode> children = node.getChildren();
                if (children.size() != 2) return null;

                Integer left = evaluateConstantExpression(children.get(0));
                Integer right = evaluateConstantExpression(children.get(1));

                // If both operands are constants, perform the operation
                if (left != null && right != null) {
                    String op = node.get("op");
                    return performBinaryOperation(left, right, op);
                }
                return null;

            case "ParenExpr":
                if (node.getNumChildren() != 1) return null;
                return evaluateConstantExpression(node.getChild(0));

            default:
                return null;
        }
    }

    /**
     * Performs binary operations on constant values.
     */
    private Integer performBinaryOperation(Integer left, Integer right, String op) {
        switch (op) {
            case "+": return left + right;
            case "-": return left - right;
            case "*": return left * right;
            case "/":
                if (right == 0) return null; // Avoid division by zero
                return left / right;
            case "%":
                if (right == 0) return null; // Avoid modulo by zero
                return left % right;
            default:
                return null; // Other operations (comparison, logical) not handled for constant folding
        }
    }
}