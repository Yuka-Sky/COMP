package pt.up.fe.comp2025.analysis.passes;

import pt.up.fe.comp.jmm.analysis.table.Symbol;
import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.analysis.AnalysisVisitor;
import pt.up.fe.comp2025.ast.TypeUtils;

import java.util.List;
import java.util.Objects;

public abstract class TypeCheckVisitor extends AnalysisVisitor {
    protected String currentMethod;
    protected TypeUtils typeUtils;

    @Override
    public List<Report> analyze(JmmNode rootNode, SymbolTable symbolTable) {
        this.typeUtils = new TypeUtils(symbolTable);
        return super.analyze(rootNode, symbolTable);
    }

    protected boolean isMethodStatic(String methodName, SymbolTable table) {
        // Considering main method as static by convention
        return methodName.equals("main");
    }

}