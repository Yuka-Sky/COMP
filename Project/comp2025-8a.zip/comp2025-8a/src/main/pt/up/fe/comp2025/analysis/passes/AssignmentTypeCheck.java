package pt.up.fe.comp2025.analysis.passes;

import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.ast.Kind;

/**
 * Concrete implementation of TypeCheckVisitor that checks variable and method
 * type compatibility, focusing on assignments and method calls.
 */
public class AssignmentTypeCheck extends TypeCheckVisitor {

    @Override
    public void buildVisitor() {
        addVisit(Kind.METHOD_DECL, this::visitMethodDecl);
        addVisit("AssignStmt", this::visitAssignStmt);
        //addVisit("ReturnStmt", this::visitReturnStmt);
        //addVisit("MethodCall", this::visitMethodCall);
        addVisit("ArrayAccess", this::visitArrayAccess);
        addVisit("BinaryExpr", this::visitBinaryExpr);
    }

    private Void visitMethodDecl(JmmNode method, SymbolTable table) {
        currentMethod = method.get("name");
        return null;
    }

    private Void visitAssignStmt(JmmNode assignStmt, SymbolTable table) {
        JmmNode leftExpr = assignStmt.getChild(0);
        JmmNode rightExpr = assignStmt.getChild(1);

        Type leftType = typeUtils.getExprType(leftExpr);
        Type rightType = typeUtils.getExprType(rightExpr);

        System.out.println("Assignment check: " + leftType.getName() + (leftType.isArray() ? "[]" : "") +
                " = " + rightType.getName() + (rightType.isArray() ? "[]" : ""));

        // if both types are imported, assume the assignment is valid
        // This handles potential inheritance relationships between imported classes
        if (typeUtils.isImportedType(leftType.getName()) &&
                typeUtils.isImportedType(rightType.getName())) {
            return null;  // Assume valid for imported types
        }


        // Check if we're assigning to an imported type from a non-imported type
        if (typeUtils.isImportedType(leftType.getName()) && !typeUtils.isImportedType(rightType.getName())) {
            // If the right type is the current class or a subclass of the imported type
            if (rightType.getName().equals(table.getClassName()) &&
                    (table.getSuper() != null && table.getSuper().equals(leftType.getName()))) {
                return null; // Valid assignment -> child to parent
            }

            // Otherwise, it's invalid -> can't assign non-subclass to imported type
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    assignStmt.getLine(),
                    assignStmt.getColumn(),
                    "Incompatible types in assignment: cannot assign " +
                            rightType.getName() + (rightType.isArray() ? "[]" : "") +
                            " to " + leftType.getName() + (leftType.isArray() ? "[]" : ""),
                    null
            ));
            return null;
        }

        // Check if we're assigning from an imported type to a non-imported type
        if (!typeUtils.isImportedType(leftType.getName()) && typeUtils.isImportedType(rightType.getName())) {
            // If the left type is the current class or parent of the imported type
            if (leftType.getName().equals(table.getClassName()) &&
                    (rightType.getName().equals(table.getSuper()))) {
                return null; // Valid assignment - parent to child with cast
            }

            // Otherwise, it's invalid -> can't assign imported to non-parent
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    assignStmt.getLine(),
                    assignStmt.getColumn(),
                    "Incompatible types in assignment: cannot assign " +
                            rightType.getName() + (rightType.isArray() ? "[]" : "") +
                            " to " + leftType.getName() + (leftType.isArray() ? "[]" : ""),
                    null
            ));
            return null;
        }

        // Handle array initialization with mixed types
        if (leftType.isArray() && rightExpr.getKind().equals("BracketsExpr")) {
            // Check if right side has mixed element types
            boolean hasMixedTypes = hasMixedArrayElements(rightExpr);
            if (hasMixedTypes) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        assignStmt.getLine(),
                        assignStmt.getColumn(),
                        "Cannot initialize " + leftType.getName() + "[] with mixed element types",
                        null
                ));
                return null;
            }
        }

        // Skip further checks only for non-array unknown types
        if ((leftType.getName().equals("unknown") && !leftType.isArray()) ||
                (rightType.getName().equals("unknown") && !rightType.isArray())) {
            return null;
        }

        if (!typeUtils.areTypesCompatible(leftType, rightType)) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    assignStmt.getLine(),
                    assignStmt.getColumn(),
                    "Incompatible types in assignment: cannot assign " +
                            rightType.getName() + (rightType.isArray() ? "[]" : "") +
                            " to " + leftType.getName() + (leftType.isArray() ? "[]" : ""),
                    null
            ));
        }

        return null;
    }

    // Helper method to check if an array expression has mixed element types
    private boolean hasMixedArrayElements(JmmNode bracketsExpr) {
        if (bracketsExpr.getChildren().isEmpty()) {
            return false;
        }

        Type firstType = typeUtils.getExprType(bracketsExpr.getChild(0));
        for (int i = 1; i < bracketsExpr.getChildren().size(); i++) {
            Type nextType = typeUtils.getExprType(bracketsExpr.getChild(i));
            if (!firstType.getName().equals(nextType.getName())) {
                return true; // Mixed types found
            }
        }
        return false;
    }

    /*
    private Void visitReturnStmt(JmmNode returnStmt, SymbolTable table) {
        if (currentMethod == null) {
            return null;
        }

        Type methodReturnType = table.getReturnType(currentMethod);

        if (returnStmt.getNumChildren() > 0) {
            JmmNode returnExpr = returnStmt.getChild(0);
            Type returnExprType = typeUtils.getExprType(returnExpr);

            if (!typeUtils.areTypesCompatible(methodReturnType, returnExprType)) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        returnStmt.getLine(),
                        returnStmt.getColumn(),
                        "Incompatible return type: method '" + currentMethod + "' requires " +
                                methodReturnType.getName() + (methodReturnType.isArray() ? "[]" : "") +
                                " but found " + returnExprType.getName() + (returnExprType.isArray() ? "[]" : ""),
                        null
                ));
            }
        } else {
            if (!methodReturnType.getName().equals("void")) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        returnStmt.getLine(),
                        returnStmt.getColumn(),
                        "Missing return value: method '" + currentMethod + "' requires " +
                                methodReturnType.getName() + (methodReturnType.isArray() ? "[]" : ""),
                        null
                ));
            }
        }

        return null;
    }

    private Void visitMethodCall(JmmNode methodCall, SymbolTable table) {
        String methodName = methodCall.get("name");

        if (methodCall.getNumChildren() == 0) {
            return null;
        }

        JmmNode objExpr = methodCall.getChild(0);
        Type objType = typeUtils.getExprType(objExpr);

        if (objType.getName().equals(table.getClassName()) &&
                table.getMethods().contains(methodName)) {
            int expectedArgCount = table.getParameters(methodName).size();
            int actualArgCount = methodCall.getNumChildren() - 1;

            if (expectedArgCount != actualArgCount) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        methodCall.getLine(),
                        methodCall.getColumn(),
                        "Method '" + methodName + "' expects " + expectedArgCount +
                                " arguments, but got " + actualArgCount,
                        null
                ));
            } else {
                for (int i = 0; i < expectedArgCount; i++) {
                    Type paramType = table.getParameters(methodName).get(i).getType();
                    Type argType = typeUtils.getExprType(methodCall.getChild(i + 1));

                    if (paramType.getName().equals("unknown") || argType.getName().equals("unknown")) {
                        continue;
                    }

                    if (!typeUtils.areTypesCompatible(paramType, argType)) {
                        addReport(Report.newError(
                                Stage.SEMANTIC,
                                methodCall.getChild(i + 1).getLine(),
                                methodCall.getChild(i + 1).getColumn(),
                                "Incompatible argument type for parameter " + (i+1) +
                                        " of method '" + methodName + "'",
                                null
                        ));
                    }
                }
            }
        }
        return null;
    }
*/
    private Void visitArrayAccess(JmmNode arrayAccess, SymbolTable table) {
        JmmNode arrayExpr = arrayAccess.getChild(0);
        JmmNode indexExpr = arrayAccess.getChild(1);

        Type arrayType = typeUtils.getExprType(arrayExpr);
        Type indexType = typeUtils.getExprType(indexExpr);

        // Check if being used on an array
        if (!arrayType.isArray()) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    arrayExpr.getLine(),
                    arrayExpr.getColumn(),
                    "Array access on non-array type: " + arrayType.getName(),
                    null
            ));
        }

        // Check if index is an integer
        if (!indexType.getName().equals("int") || indexType.isArray()) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    indexExpr.getLine(),
                    indexExpr.getColumn(),
                    "Array index must be an integer",
                    null
            ));
        }

        return null;
    }

    private Void visitBinaryExpr(JmmNode binaryExpr, SymbolTable table) {
        if (!typeUtils.isValidBinaryExpression(binaryExpr)) {
            String op = binaryExpr.get("op");
            Type leftType = typeUtils.getExprType(binaryExpr.getChild(0));
            Type rightType = typeUtils.getExprType(binaryExpr.getChild(1));

            addReport(Report.newError(
                    Stage.SEMANTIC,
                    binaryExpr.getLine(),
                    binaryExpr.getColumn(),
                    typeUtils.getInvalidOperationMessage(op, leftType, rightType),
                    null
            ));
        }
        return null;
    }
}