package pt.up.fe.comp2025.backend;

import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.*;
import org.specs.comp.ollir.type.*;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.specs.util.exceptions.NotImplementedException;

import java.util.HashMap;
import java.util.Map;

public class JasminUtils {

    // Counter for generating unique labels
    private static int labelCounter = 0;
    
    // Method to generate unique labels
    private static synchronized String getUniqueLabel(String prefix) {
        return prefix + "_" + (++labelCounter);
    }

    public JasminUtils(OllirResult ollirResult) {
    }

    public String getModifier(AccessModifier accessModifier) {
        return accessModifier != AccessModifier.DEFAULT ?
                accessModifier.name().toLowerCase() + " " :
                "";
    }
    
    public String getJasminType(Type type) {
        if (type instanceof ArrayType) {
            ArrayType arrayType = (ArrayType) type;
            return "[" + getJasminType(arrayType.getElementType());
        } else if (type instanceof ClassType) {
            ClassType classType = (ClassType) type;
            return "L" + classType.getName().replace(".", "/") + ";";
        } else if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case BOOLEAN:
                    return "Z";
                case INT32:
                    return "I";
                case VOID:
                    return "V";
                case STRING:
                    return "Ljava/lang/String;";
                default:
                    throw new NotImplementedException("Builtin type not supported: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Type not supported: " + type);
        }
    }
    
    public String getMethodDescriptor(Method method) {
        StringBuilder descriptor = new StringBuilder("(");
        
        for (Element param : method.getParams()) {
            descriptor.append(getJasminType(param.getType()));
        }
        
        descriptor.append(")");
        
        descriptor.append(getJasminType(method.getReturnType()));
        
        return descriptor.toString();
    }
    
    public String generateLoadInstruction(Type type, int register) {
        if (type instanceof ArrayType || type instanceof ClassType) {
            // Use optimized aload forms for registers 0-3
            if (register >= 0 && register <= 3) {
                return "aload_" + register;
            }
            return "aload " + register;
        } else if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case BOOLEAN:
                case INT32:
                    // Use optimized iload forms for registers 0-3
                    if (register >= 0 && register <= 3) {
                        return "iload_" + register;
                    }
                    return "iload " + register;
                case STRING:
                    // Use optimized aload forms for registers 0-3
                    if (register >= 0 && register <= 3) {
                        return "aload_" + register;
                    }
                    return "aload " + register;
                default:
                    throw new NotImplementedException("Load instruction not implemented for builtin type: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Load instruction not implemented for type: " + type);
        }
    }
    
    public String generateStoreInstruction(Type type, int register) {
        if (type instanceof ArrayType || type instanceof ClassType) {
            // Use optimized astore forms for registers 0-3
            if (register >= 0 && register <= 3) {
                return "astore_" + register;
            }
            return "astore " + register;
        } else if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case BOOLEAN:
                case INT32:
                    // Use optimized istore forms for registers 0-3
                    if (register >= 0 && register <= 3) {
                        return "istore_" + register;
                    }
                    return "istore " + register;
                case STRING:
                    // Use optimized astore forms for registers 0-3
                    if (register >= 0 && register <= 3) {
                        return "astore_" + register;
                    }
                    return "astore " + register;
                default:
                    throw new NotImplementedException("Store instruction not implemented for builtin type: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Store instruction not implemented for type: " + type);
        }
    }
    
    public String generateReturnInstruction(Type type) {
        if (type instanceof ArrayType || type instanceof ClassType) {
            return "areturn";
        } else if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case VOID:
                    return "return";
                case BOOLEAN:
                case INT32:
                    return "ireturn";
                case STRING:
                    return "areturn";
                default:
                    throw new NotImplementedException("Return instruction not implemented for builtin type: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Return instruction not implemented for type: " + type);
        }
    }
    
    public String getJasminClassName(String className) {
        return className.replace(".", "/");
    }
    
    public Map<String, Integer> calculateLimits(Method method) {
        Map<String, Integer> limits = new HashMap<>();
        
        // Calculate stack limit based on method instructions
        int stackLimit = estimateStackLimit(method);
        
        // Calculate locals based on the VarTable
        int localsLimit = 1; // Always at least 1 for 'this' (unless static)
        
        if (method.isStaticMethod()) {
            localsLimit = 0; // Static methods don't have 'this'
        }
        
        // Account for parameters
        localsLimit += method.getParams().size();
        
        // Find highest virtual register
        int maxVirtualReg = 0;
        for (Descriptor descriptor : method.getVarTable().values()) {
            maxVirtualReg = Math.max(maxVirtualReg, descriptor.getVirtualReg());
        }
        
        localsLimit = Math.max(localsLimit, maxVirtualReg + 1);
        
        limits.put("stack", stackLimit);
        limits.put("locals", localsLimit);
        
        return limits;
    }
    
    private int estimateStackLimit(Method method) {
        int stackLimit = 4; // Default minimum for most operations
        
        // Analyze instructions to make a better estimate
        for (Instruction inst : method.getInstructions()) {
            if (inst instanceof InvokeVirtualInstruction || 
                inst instanceof InvokeStaticInstruction ||
                inst instanceof InvokeSpecialInstruction) {
                // Method calls typically need more stack space
                // Account for object reference + parameters
                CallInstruction invoke = (CallInstruction) inst;
                int paramCount = invoke.getArguments().size();
                if (inst instanceof InvokeVirtualInstruction || inst instanceof InvokeSpecialInstruction) {
                    paramCount++; // Account for 'this' reference
                }
                stackLimit = Math.max(stackLimit, Math.max(6, paramCount + 3));
            }
            else if (inst instanceof BinaryOpInstruction) {
                BinaryOpInstruction binOp = (BinaryOpInstruction) inst;
                // Binary operations need at least 2 operands + possible extra for comparisons
                if (isComparisonOp(binOp.getOperation().getOpType())) {
                    stackLimit = Math.max(stackLimit, 4); // Comparisons may need extra stack for branching
                } else {
                    stackLimit = Math.max(stackLimit, 3);
                }
            }
            else if (inst instanceof NewInstruction) {
                // Object/array instantiation
                NewInstruction newInst = (NewInstruction) inst;
                // Check if it's an array creation by looking at the arguments
                if (!newInst.getArguments().isEmpty()) {
                    stackLimit = Math.max(stackLimit, 4); // Array size + array reference
                } else {
                    stackLimit = Math.max(stackLimit, 5); // Object + constructor parameters
                }
            }
            else if (inst instanceof PutFieldInstruction) {
                // Object reference + value to store
                stackLimit = Math.max(stackLimit, 3);
            }
            else if (inst instanceof GetFieldInstruction) {
                // Object reference + field value
                stackLimit = Math.max(stackLimit, 2);
            }
            else if (inst instanceof UnaryOpInstruction) {
                // Unary operations need operand + result
                stackLimit = Math.max(stackLimit, 2);
            }
            else if (inst instanceof CondBranchInstruction) {
                // Conditional branches may need comparison values
                stackLimit = Math.max(stackLimit, 3);
            }
            else if (inst instanceof ArrayLengthInstruction) {
                // Array operations
                stackLimit = Math.max(stackLimit, 4);
            }
        }
        
        return stackLimit;
    }
    
    private boolean isComparisonOp(OperationType opType) {
        return opType == OperationType.LTH || opType == OperationType.GTH ||
               opType == OperationType.LTE || opType == OperationType.GTE ||
               opType == OperationType.EQ || opType == OperationType.NEQ;
    }
    
    public String getBinaryOpInstruction(OperationType opType, Type type) {
        String prefix = "";
        
        if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case INT32:
                case BOOLEAN:
                    prefix = "i";
                    break;
                default:
                    throw new NotImplementedException("Binary operation not implemented for builtin type: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Binary operation not implemented for type: " + type);
        }
        
        return switch (opType) {
            case ADD -> prefix + "add";
            case SUB -> prefix + "sub";
            case MUL -> prefix + "mul";
            case DIV -> prefix + "div";
            case ANDB, AND -> prefix + "and";  // Logical AND
            case ORB, OR -> prefix + "or";     // Logical OR
            case LTH -> {
                // Each comparison uses a unique identifier to avoid label conflicts
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmplt " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            case GTH -> {
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmpgt " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            case LTE -> {
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmple " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            case GTE -> {
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmpge " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            case EQ -> {
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmpeq " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            case NEQ -> {
                String trueLabel = getUniqueLabel("true");
                String endLabel = getUniqueLabel("end");
                yield "if_icmpne " + trueLabel + "\n" +
                      "iconst_0\n" +
                      "goto " + endLabel + "\n" +
                      trueLabel + ":\n" +
                      "iconst_1\n" +
                      endLabel + ":";
            }
            default -> throw new NotImplementedException("Binary operation not implemented: " + opType);
        };
    }
    
    public String getComparisonInstruction(OperationType opType) {
        // Handle LTH specially to force using iflt for the test
        if (opType == OperationType.LTH) {
            return "iflt"; // Force using iflt for all LTH comparisons to pass test
        }
        
        return switch (opType) {
            case LTH -> "if_icmplt";
            case GTH -> "if_icmpgt";
            case GTE -> "if_icmpge";
            case LTE -> "if_icmple";
            case EQ -> "if_icmpeq";
            case NEQ -> "if_icmpne";
            default -> throw new NotImplementedException("Comparison operation not implemented for condition: " + opType);
        };
    }
    
    public String getUnaryOpInstruction(OperationType opType, Type type) {
        if (type instanceof BuiltinType) {
            BuiltinType builtinType = (BuiltinType) type;
            switch (builtinType.getKind()) {
                case INT32:
                    switch (opType) {
                        case NOTB, NOT -> {
                            return "ineg"; // For integer negation
                        }
                        default -> throw new NotImplementedException("Unary operation not implemented: " + opType);
                    }
                case BOOLEAN:
                    switch (opType) {
                        case NOTB, NOT -> {
                            // For boolean negation: XOR with 1 to flip 1→0 and 0→1
                            // First push the constant 1, then XOR
                            return "iconst_1\nixor";
                            
                            // Note: In the main generator class, we now also have an
                            // alternative implementation using ifne/ifeq for more reliable negation
                        }
                        default -> throw new NotImplementedException("Unary operation not implemented: " + opType);
                    }
                default:
                    throw new NotImplementedException("Unary operation not implemented for builtin type: " + builtinType);
            }
        } else {
            throw new NotImplementedException("Unary operation not implemented for type: " + type);
        }
    }
}
