package pt.up.fe.comp2025.analysis.passes;

import pt.up.fe.comp.jmm.analysis.table.SymbolTable;
import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.ast.Kind;
import pt.up.fe.comp2025.symboltable.JmmSymbolTable;

/**
 * Comprehensive method validation that checks:
 * - Method existence and declaration
 * - Static vs instance method calls
 * - Type compatibility in arguments and return values
 * - Methods assumed in imports or inherited from superclass
 */
public class MethodValidationCheck extends TypeCheckVisitor {

    @Override
    public void buildVisitor() {
        addVisit(Kind.METHOD_DECL, this::visitMethodDecl);
        addVisit("MethodCall", this::visitMethodCall);
        addVisit("StaticMethodCall", this::visitStaticMethodCall);
        addVisit("ReturnStmt", this::visitReturnStmt);
    }

    private Void visitMethodDecl(JmmNode method, SymbolTable table) {
        currentMethod = method.get("name");
        return null;
    }

    private Void visitMethodCall(JmmNode methodCall, SymbolTable table) {
        String methodName = methodCall.get("name");

        // Must have at least one child (the object the method is called on)
        if (methodCall.getNumChildren() == 0) {
            return null;
        }

        JmmNode callerExpr = methodCall.getChild(0);
        Type callerType = typeUtils.getExprType(callerExpr);

        if (callerType.getName().equals("unknown")) {
            return null;
        }

        // Check if calling a method on the current class
        if (callerType.getName().equals(table.getClassName())) {
            // Check if method exists in current class
            if (!table.getMethods().contains(methodName)) {
                if (table.getSuper() == null) {
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            methodCall.getLine(),
                            methodCall.getColumn(),
                            "Call to undeclared method '" + methodName + "' in class '" + table.getClassName() + "'",
                            null
                    ));
                } else {
                    // There's a superclass, assume the method is inherited
                    return null;
                }
            }
            // Check static vs instance context
            else if (table.getMethods().contains(methodName) && typeUtils.isStaticMethod(methodName)) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        methodCall.getLine(),
                        methodCall.getColumn(),
                        "Cannot call static method '" + methodName + "' in an instance context",
                        null
                ));
            }

            // Validate arguments for methods in current class
            if (table.getMethods().contains(methodName)) {
                validateMethodArguments(methodCall, methodName, table);
            }
        }
        else if (typeUtils.isImportedType(callerType.getName()) ||
                (table.getSuper() != null && callerType.getName().equals(table.getSuper()))) {
            // Assume method existence is valid for imported/super classes
            return null;
        }
        // Unrecognized type -> could be a type error
        else {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    methodCall.getLine(),
                    methodCall.getColumn(),
                    "Method call on unknown type '" + callerType.getName() + "'",
                    null
            ));
        }

        return null;
    }

    private Void visitStaticMethodCall(JmmNode staticCall, SymbolTable table) {
        String classNameOrVar = staticCall.get("className");
        String methodName = staticCall.get("methodName");

        if (typeUtils.isImportedType(classNameOrVar)) {
            // It's an imported class, assume method is valid
            return null;
        }

        // Try to resolve classNameOrVar as a variable first
        Type resolvedType = typeUtils.getTypeOfReference(classNameOrVar, currentMethod);

        if (resolvedType != null) {
            // It's a variable! Now check the variable's type
            String resolvedClassName = resolvedType.getName();

            if (typeUtils.isImportedType(resolvedClassName)) {
                return null; // assume valid
            }
            else if (table.getSuper() != null && resolvedClassName.equals(table.getSuper())) {
                return null; // assume valid
            }
            else if (resolvedClassName.equals(table.getClassName())) {
                // Variable of type current class
                if (!table.getMethods().contains(methodName)) {
                    if (table.getSuper() == null) {
                        addReport(Report.newError(
                                Stage.SEMANTIC,
                                staticCall.getLine(),
                                staticCall.getColumn(),
                                "Call to undeclared static method '" + methodName + "' in class '" + resolvedClassName + "'",
                                null
                        ));
                    } else {
                        // There's a superclass, assume the method is inherited
                        return null;
                    }
                } else if (!typeUtils.isStaticMethod(methodName)) {
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            staticCall.getLine(),
                            staticCall.getColumn(),
                            "Cannot call instance method '" + methodName + "' in a static context",
                            null
                    ));
                }
                if (table.getMethods().contains(methodName)) {
                    validateStaticMethodArguments(staticCall, methodName, table);
                }
                return null;
            }
            else {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        staticCall.getLine(),
                        staticCall.getColumn(),
                        "Static method call on unknown type '" + resolvedClassName + "'",
                        null
                ));
                return null;
            }
        }

        // If not a variable, assume it's a class name
        if (typeUtils.isImportedType(classNameOrVar)) {
            return null;
        }
        else if (table.getSuper() != null && classNameOrVar.equals(table.getSuper())) {
            return null;
        }
        else if (classNameOrVar.equals(table.getClassName())) {
            if (!table.getMethods().contains(methodName)) {
                if (table.getSuper() == null) {
                    // No superclass, so the method is undeclared
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            staticCall.getLine(),
                            staticCall.getColumn(),
                            "Call to undeclared static method '" + methodName + "' in class '" + classNameOrVar + "'",
                            null
                    ));
                } else {
                    // There's a superclass, assume the method is inherited
                    return null;
                }
            } else if (!typeUtils.isStaticMethod(methodName)) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        staticCall.getLine(),
                        staticCall.getColumn(),
                        "Cannot call instance method '" + methodName + "' in a static context",
                        null
                ));
            }
            if (table.getMethods().contains(methodName)) {
                validateStaticMethodArguments(staticCall, methodName, table);
            }
        }
        else {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    staticCall.getLine(),
                    staticCall.getColumn(),
                    "Static method call on unknown class '" + classNameOrVar + "'",
                    null
            ));
        }

        return null;
    }

    private Void visitReturnStmt(JmmNode returnStmt, SymbolTable table) {
        // Skip if current method is unknown
        if (currentMethod == null) {
            return null;
        }

        // Get the method's declared return type
        Type methodReturnType = table.getReturnType(currentMethod);

        // If there's a return expression, check its type
        if (returnStmt.getNumChildren() > 0) {
            JmmNode returnExpr = returnStmt.getChild(0);
            Type returnExprType = typeUtils.getExprType(returnExpr);

            if (!typeUtils.areTypesCompatible(methodReturnType, returnExprType)) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        returnStmt.getLine(),
                        returnStmt.getColumn(),
                        "Incompatible return type: method '" + currentMethod + "' requires " +
                                methodReturnType.getName() + (methodReturnType.isArray() ? "[]" : "") +
                                " but found " + returnExprType.getName() + (returnExprType.isArray() ? "[]" : ""),
                        null
                ));
            }
        } else {
            // No expression, should be void
            if (!methodReturnType.getName().equals("void")) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        returnStmt.getLine(),
                        returnStmt.getColumn(),
                        "Missing return value: method '" + currentMethod + "' requires " +
                                methodReturnType.getName() + (methodReturnType.isArray() ? "[]" : ""),
                        null
                ));
            }
        }

        return null;
    }

    /**
     * Validate arguments for instance method calls.
     * For methods on the current class, we check argument types against parameter types.
     */
    private void validateMethodArguments(JmmNode methodCall, String methodName, SymbolTable table) {
        // First child is the caller
        JmmNode callerExpr = methodCall.getChild(0);
        Type callerType = typeUtils.getExprType(callerExpr);

        // Skip validation for imported types
        if (typeUtils.isImportedType(callerType.getName()) ||
                (table.getSuper() != null && callerType.getName().equals(table.getSuper()))) {
            return;  // Skip validation for imported/inherited methods
        }

        var params = table.getParameters(methodName);
        int expectedArgCount = params.size();
        int actualArgCount = methodCall.getNumChildren() - 1; // First child is the caller

        // Check if this is a varargs method
        if (table instanceof JmmSymbolTable && !params.isEmpty() &&
                ((JmmSymbolTable)table).hasVarargs(methodName)) {

            // For varargs, we need at least (params.size() - 1) arguments
            int requiredParams = expectedArgCount - 1;

            if (actualArgCount < requiredParams) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        methodCall.getLine(),
                        methodCall.getColumn(),
                        "Method '" + methodName + "' with varargs requires at least " + requiredParams +
                                " arguments, but got " + actualArgCount,
                        null
                ));
            } else {
                // Check fixed parameters
                for (int i = 0; i < requiredParams; i++) {
                    Type paramType = params.get(i).getType();
                    Type argType = typeUtils.getExprType(methodCall.getChild(i + 1));

                    if (!typeUtils.areTypesCompatible(paramType, argType)) {
                        addReport(Report.newError(
                                Stage.SEMANTIC,
                                methodCall.getChild(i + 1).getLine(),
                                methodCall.getChild(i + 1).getColumn(),
                                "Incompatible argument type for parameter " + (i+1) +
                                        " of method '" + methodName + "'",
                                null
                        ));
                    }
                }

                // Check varargs parameters
                if (actualArgCount > requiredParams) {
                    Type varargType = params.get(requiredParams).getType();
                    Type elementType = new Type(varargType.getName(), false); // Element type without array flag

                    for (int i = requiredParams; i < actualArgCount; i++) {
                        Type argType = typeUtils.getExprType(methodCall.getChild(i + 1));

                        if (!typeUtils.areTypesCompatible(elementType, argType)) {
                            addReport(Report.newError(
                                    Stage.SEMANTIC,
                                    methodCall.getChild(i + 1).getLine(),
                                    methodCall.getChild(i + 1).getColumn(),
                                    "Incompatible argument type for varargs parameter of method '" + methodName + "'",
                                    null
                            ));
                        }
                    }
                }
            }
            return; // Exit early for varargs methods
        }

        // Regular method handling
        if (expectedArgCount != actualArgCount) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    methodCall.getLine(),
                    methodCall.getColumn(),
                    "Method '" + methodName + "' expects " + expectedArgCount +
                            " arguments, but got " + actualArgCount,
                    null
            ));
        } else {
            // Check each argument type compatibility
            for (int i = 0; i < expectedArgCount; i++) {
                Type paramType = params.get(i).getType();
                Type argType = typeUtils.getExprType(methodCall.getChild(i + 1));

                // Skip validation if either type is unknown
                if (paramType.getName().equals("unknown") || argType.getName().equals("unknown")) {
                    continue;
                }

                if (!typeUtils.areTypesCompatible(paramType, argType)) {
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            methodCall.getChild(i + 1).getLine(),
                            methodCall.getChild(i + 1).getColumn(),
                            "Incompatible argument type for parameter " + (i+1) +
                                    " of method '" + methodName + "'",
                            null
                    ));
                }
            }
        }
    }

    /**
     * Validate arguments for static method calls.
     */
    private void validateStaticMethodArguments(JmmNode staticCall, String methodName, SymbolTable table) {
        String classNameOrVar = staticCall.get("className");

        if (typeUtils.isImportedType(classNameOrVar) ||
                (table.getSuper() != null && classNameOrVar.equals(table.getSuper()))) {
            return;  // Skip validation for imported/inherited methods
        }

        var params = table.getParameters(methodName);
        int expectedArgCount = params.size();
        int actualArgCount = staticCall.getNumChildren(); // All children are arguments

        // Check if this is a varargs method
        if (table instanceof JmmSymbolTable && !params.isEmpty() &&
                ((JmmSymbolTable)table).hasVarargs(methodName)) {

            // For varargs, we need at least (params.size() - 1) arguments
            int requiredParams = expectedArgCount - 1;

            if (actualArgCount < requiredParams) {
                addReport(Report.newError(
                        Stage.SEMANTIC,
                        staticCall.getLine(),
                        staticCall.getColumn(),
                        "Static method '" + methodName + "' with varargs requires at least " + requiredParams +
                                " arguments, but got " + actualArgCount,
                        null
                ));
            } else {
                // Check fixed parameters
                for (int i = 0; i < requiredParams; i++) {
                    Type paramType = params.get(i).getType();
                    Type argType = typeUtils.getExprType(staticCall.getChild(i));

                    if (!typeUtils.areTypesCompatible(paramType, argType)) {
                        addReport(Report.newError(
                                Stage.SEMANTIC,
                                staticCall.getChild(i).getLine(),
                                staticCall.getChild(i).getColumn(),
                                "Incompatible argument type for parameter " + (i+1) +
                                        " of static method '" + methodName + "'",
                                null
                        ));
                    }
                }

                // Check varargs parameters
                if (actualArgCount > requiredParams) {
                    Type varargType = params.get(requiredParams).getType();
                    Type elementType = new Type(varargType.getName(), false); // Element type without array flag

                    for (int i = requiredParams; i < actualArgCount; i++) {
                        Type argType = typeUtils.getExprType(staticCall.getChild(i));

                        if (!typeUtils.areTypesCompatible(elementType, argType)) {
                            addReport(Report.newError(
                                    Stage.SEMANTIC,
                                    staticCall.getChild(i).getLine(),
                                    staticCall.getChild(i).getColumn(),
                                    "Incompatible argument type for varargs parameter of static method '" + methodName + "'",
                                    null
                            ));
                        }
                    }
                }
            }
            return; // Exit early for varargs methods
        }

        // Regular method handling
        if (expectedArgCount != actualArgCount) {
            addReport(Report.newError(
                    Stage.SEMANTIC,
                    staticCall.getLine(),
                    staticCall.getColumn(),
                    "Static method '" + methodName + "' expects " + expectedArgCount +
                            " arguments, but got " + actualArgCount,
                    null
            ));
        } else {
            // Check each argument type compatibility
            for (int i = 0; i < expectedArgCount; i++) {
                Type paramType = params.get(i).getType();
                Type argType = typeUtils.getExprType(staticCall.getChild(i));

                // Skip validation if either type is unknown
                if (paramType.getName().equals("unknown") || argType.getName().equals("unknown")) {
                    continue;
                }

                if (!typeUtils.areTypesCompatible(paramType, argType)) {
                    addReport(Report.newError(
                            Stage.SEMANTIC,
                            staticCall.getChild(i).getLine(),
                            staticCall.getChild(i).getColumn(),
                            "Incompatible argument type for parameter " + (i+1) +
                                    " of static method '" + methodName + "'",
                            null
                    ));
                }
            }
        }
    }
}