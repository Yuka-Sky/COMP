package pt.up.fe.comp2025.optimization;

import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.*;
import pt.up.fe.comp.jmm.ollir.OllirResult;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.Stage;

import java.util.*;
import java.util.stream.Collectors;

public class RegisterAllocator {

    public static class RegisterAllocationException extends RuntimeException {
        private final int minimumRequiredRegisters;

        public RegisterAllocationException(int minimumRequiredRegisters) {
            super("Allocation failed: at least " + minimumRequiredRegisters + " registers needed");
            this.minimumRequiredRegisters = minimumRequiredRegisters;
        }

        public int getMinRegistersNeeded() {
            return minimumRequiredRegisters;
        }
    }

    private static final boolean VERBOSE = false;

    public List<Report> allocateRegisters(OllirResult ollirResult, int maxRegisters) {
        List<Report> reports = new ArrayList<>();
        ClassUnit classUnit = ollirResult.getOllirClass();

        if (maxRegisters == -1) {
            return reports;
        }

        for (Method method : classUnit.getMethods()) {
            if (method.isConstructMethod()) {
                continue;
            }            try {
                if (maxRegisters == 0) {
                    allocateOptimally(method);
                    String mapping = createRegisterReport(method);
                    reports.add(Report.newLog(Stage.OPTIMIZATION, 0, 0,
                            "Optimal register allocation for method " + method.getMethodName() + ": " + mapping, null));
                } else {
                    boolean success = allocateWithLimit(method, maxRegisters);
                    if (success) {
                        String mapping = createRegisterReport(method);
                        reports.add(Report.newLog(Stage.OPTIMIZATION, 0, 0,
                                "Limited register allocation for method " + method.getMethodName() +
                                        " (max " + maxRegisters + "): " + mapping, null));
                    }
                }} catch (RegisterAllocationException e) {
                reports.add(Report.newError(Stage.OPTIMIZATION, 0, 0,
                        "Register allocation failed for " + method.getMethodName() +
                                ": Need at least " + e.getMinRegistersNeeded() + " registers", null));
                // Don't throw exception, just add error report
            } catch (Exception e) {
                reports.add(Report.newError(Stage.OPTIMIZATION, 0, 0,
                        "Unexpected error in register allocation for " + method.getMethodName() +
                                ": " + e.getMessage(), e));
                // Don't throw exception, just add error report
            }
        }

        return reports;
    }

    private void allocateOptimally(Method method) {
        LivenessAnalyzer analyzer = new LivenessAnalyzer(method);
        analyzer.analyze();

        InterferenceGraph graph = new InterferenceGraph(analyzer);

        VarAssigner assigner = new VarAssigner(method, graph);
        assigner.assignMinimumRegisters();
    }    private boolean allocateWithLimit(Method method, int maxRegisters) {
        LivenessAnalyzer analyzer = new LivenessAnalyzer(method);
        analyzer.analyze();

        InterferenceGraph graph = new InterferenceGraph(analyzer);

        VarAssigner assigner = new VarAssigner(method, graph);
        return assigner.assignLimitedRegisters(maxRegisters);
    }

    private String createRegisterReport(Method method) {
        StringBuilder report = new StringBuilder();
        Map<String, Descriptor> varTable = method.getVarTable();

        List<String> vars = new ArrayList<>(varTable.keySet());
        Collections.sort(vars);

        for (int i = 0; i < vars.size(); i++) {
            report.append(vars.get(i)).append("→r").append(varTable.get(vars.get(i)).getVirtualReg());
            if (i < vars.size() - 1) {
                report.append(", ");
            }
        }

        return report.toString();
    }

    private void log(String message) {
        if (VERBOSE) {

        }
    }

    private class LivenessAnalyzer {
        private final Method method;
        private final List<Instruction> instructions;
        private final Map<Instruction, Set<String>> in = new HashMap<>();
        private final Map<Instruction, Set<String>> out = new HashMap<>();
        private final Map<Instruction, Set<String>> def = new HashMap<>();
        private final Map<Instruction, Set<String>> use = new HashMap<>();
        private final Map<Instruction, List<Instruction>> successors = new HashMap<>();

        public LivenessAnalyzer(Method method) {
            this.method = method;
            this.instructions = method.getInstructions();
        }

        public void analyze() {
            initializeDataFlowSets();
            buildFlowGraph();
            computeDefUse();
            computeLiveness();
        }

        public Map<Instruction, Set<String>> getLiveIn() {
            return in;
        }

        public Map<Instruction, Set<String>> getLiveOut() {
            return out;
        }

        private void initializeDataFlowSets() {
            for (Instruction inst : instructions) {
                in.put(inst, new HashSet<>());
                out.put(inst, new HashSet<>());
                def.put(inst, new HashSet<>());
                use.put(inst, new HashSet<>());
                successors.put(inst, new ArrayList<>());
            }
        }

        private void buildFlowGraph() {
            method.buildCFG();

            for (int i = 0; i < instructions.size(); i++) {
                Instruction current = instructions.get(i);

                if (current instanceof ReturnInstruction) {
                    continue;
                }

                if (current instanceof GotoInstruction gotoInst) {
                    Instruction target = findLabelTarget(gotoInst.getLabel());
                    if (target != null) {
                        successors.get(current).add(target);
                    }
                    continue;
                }

                if (current instanceof CondBranchInstruction condBranch) {
                    Instruction target = findLabelTarget(condBranch.getLabel());
                    if (target != null) {
                        successors.get(current).add(target);
                    }

                    if (i + 1 < instructions.size()) {
                        successors.get(current).add(instructions.get(i + 1));
                    }
                    continue;
                }

                if (i + 1 < instructions.size()) {
                    successors.get(current).add(instructions.get(i + 1));
                }
            }
        }

        private Instruction findLabelTarget(String label) {
            if (label == null) return null;

            HashMap<String, Instruction> labels = method.getLabels();
            return labels != null ? labels.get(label) : null;
        }

        private void computeDefUse() {
            for (Instruction inst : instructions) {
                findDefinitionsAndUses(inst, def.get(inst), use.get(inst));
            }
        }

        private void findDefinitionsAndUses(Instruction inst, Set<String> defined, Set<String> used) {
            if (inst instanceof AssignInstruction assign) {
                Element dest = assign.getDest();
                if (dest instanceof Operand && !(dest instanceof ArrayOperand)) {
                    String varName = ((Operand) dest).getName();
                    if (!varName.equals("this")) {
                        defined.add(varName);
                    }
                } else if (dest instanceof ArrayOperand arrayDest) {
                    used.add(arrayDest.getName());
                    for (Element indexElem : arrayDest.getIndexOperands()) {
                        collectUsedVariables(indexElem, used);
                    }
                }

                collectUsesFromRightHandSide(assign.getRhs(), used);
            }
            else if (inst instanceof CallInstruction call) {
                if (call.getCaller() != null) {
                    collectUsedVariables(call.getCaller(), used);
                }

                for (Element arg : call.getArguments()) {
                    collectUsedVariables(arg, used);
                }
            }
            else if (inst instanceof ReturnInstruction ret && ret.hasReturnValue()) {
                collectUsedVariables(ret.getOperand().get(), used);
            }
            else if (inst instanceof CondBranchInstruction branch) {
                for (Element op : branch.getOperands()) {
                    collectUsedVariables(op, used);
                }
            }
            else if (inst instanceof PutFieldInstruction put) {
                for (Element op : put.getOperands()) {
                    collectUsedVariables(op, used);
                }
            }
            else if (inst instanceof GetFieldInstruction get) {
                for (Element op : get.getOperands()) {
                    collectUsedVariables(op, used);
                }
            }
            else if (inst instanceof UnaryOpInstruction unary) {
                collectUsedVariables(unary.getOperand(), used);
            }
            else if (inst instanceof BinaryOpInstruction binary) {
                collectUsedVariables(binary.getLeftOperand(), used);
                collectUsedVariables(binary.getRightOperand(), used);
            }
            else if (inst instanceof SingleOpInstruction single) {
                collectUsedVariables(single.getSingleOperand(), used);
            }

            defined.remove("this");
            used.remove("this");
        }

        private void collectUsesFromRightHandSide(Instruction inst, Set<String> used) {
            if (inst instanceof SingleOpInstruction single) {
                collectUsedVariables(single.getSingleOperand(), used);
            }
            else if (inst instanceof BinaryOpInstruction binary) {
                collectUsedVariables(binary.getLeftOperand(), used);
                collectUsedVariables(binary.getRightOperand(), used);
            }
            else if (inst instanceof UnaryOpInstruction unary) {
                collectUsedVariables(unary.getOperand(), used);
            }
            else if (inst instanceof CallInstruction call) {
                if (call.getCaller() != null) {
                    collectUsedVariables(call.getCaller(), used);
                }

                for (Element arg : call.getArguments()) {
                    collectUsedVariables(arg, used);
                }
            }
            else if (inst instanceof GetFieldInstruction get) {
                for (Element op : get.getOperands()) {
                    collectUsedVariables(op, used);
                }
            }
        }

        private void collectUsedVariables(Element element, Set<String> used) {
            if (element instanceof Operand && !(element instanceof LiteralElement)) {
                if (element instanceof ArrayOperand arrayOp) {
                    used.add(arrayOp.getName());
                    for (Element indexElem : arrayOp.getIndexOperands()) {
                        collectUsedVariables(indexElem, used);
                    }
                } else {
                    String name = ((Operand) element).getName();
                    if (!name.equals("this")) {
                        used.add(name);
                    }
                }
            }
        }

        private void computeLiveness() {
            boolean changed;
            do {
                changed = false;

                for (int i = instructions.size() - 1; i >= 0; i--) {
                    Instruction inst = instructions.get(i);

                    Set<String> oldIn = new HashSet<>(in.get(inst));
                    Set<String> oldOut = new HashSet<>(out.get(inst));

                    for (Instruction succ : successors.get(inst)) {
                        out.get(inst).addAll(in.get(succ));
                    }

                    Set<String> outMinusDef = new HashSet<>(out.get(inst));
                    outMinusDef.removeAll(def.get(inst));

                    Set<String> newIn = new HashSet<>(use.get(inst));
                    newIn.addAll(outMinusDef);
                    in.get(inst).clear();
                    in.get(inst).addAll(newIn);

                    if (!oldIn.equals(in.get(inst)) || !oldOut.equals(out.get(inst))) {
                        changed = true;
                    }
                }
            } while (changed);
        }
    }

    private class InterferenceGraph {
        private final Map<String, Set<String>> graph = new HashMap<>();
        private final Map<String, Set<String>> copyRelated = new HashMap<>();
        private final Map<Instruction, Set<String>> liveOut;
        private final Method method;

        public InterferenceGraph(LivenessAnalyzer analyzer) {
            this.method = analyzer.method;
            this.liveOut = analyzer.getLiveOut();

            initializeGraph();
            findCopyRelations();
            buildInterferenceEdges();
            refineCopyRelations();
        }

        public Map<String, Set<String>> getGraph() {
            return graph;
        }

        public Map<String, Set<String>> getCopyRelations() {
            return copyRelated;
        }

        private void initializeGraph() {
            for (String var : method.getVarTable().keySet()) {
                if (!var.equals("this")) {
                    graph.put(var, new HashSet<>());
                    copyRelated.put(var, new HashSet<>());
                    copyRelated.get(var).add(var);
                }
            }
        }

        private void findCopyRelations() {
            for (Instruction inst : method.getInstructions()) {
                if (inst instanceof AssignInstruction assign) {
                    Element dest = assign.getDest();

                    if (!(dest instanceof Operand) || dest instanceof ArrayOperand) {
                        continue;
                    }

                    String destVar = ((Operand) dest).getName();
                    if (destVar.equals("this")) continue;

                    if (assign.getRhs() instanceof SingleOpInstruction sop) {
                        Element src = sop.getSingleOperand();
                        if (src instanceof Operand && !(src instanceof ArrayOperand)) {
                            String srcVar = ((Operand) src).getName();
                            if (!srcVar.equals("this")) {
                                copyRelated.get(destVar).add(srcVar);
                                copyRelated.get(srcVar).add(destVar);
                            }
                        }
                    }

                    else if (assign.getRhs() instanceof BinaryOpInstruction bop) {
                        Element left = bop.getLeftOperand();
                        Element right = bop.getRightOperand();

                        boolean leftIsParam = isParameter(left);
                        boolean rightIsParam = isParameter(right);
                        boolean leftIsConst = left instanceof LiteralElement;
                        boolean rightIsConst = right instanceof LiteralElement;

                        if ((leftIsParam && rightIsConst) || (rightIsParam && leftIsConst)) {
                            String paramName = leftIsParam ?
                                    ((Operand)left).getName() : ((Operand)right).getName();

                            copyRelated.get(destVar).add(paramName);
                            copyRelated.get(paramName).add(destVar);
                        }
                    }
                }
            }

            expandCopyRelations();
        }

        private boolean isParameter(Element element) {
            if (!(element instanceof Operand) || element instanceof ArrayOperand
                    || element instanceof LiteralElement) {
                return false;
            }

            String name = ((Operand)element).getName();
            if (name.equals("this")) return false;

            return method.getParams().stream()
                    .filter(Operand.class::isInstance)
                    .map(param -> ((Operand)param).getName())
                    .anyMatch(name::equals);
        }

        private void expandCopyRelations() {
            boolean changed;
            do {
                changed = false;

                for (String var : copyRelated.keySet()) {
                    Set<String> newRelations = new HashSet<>();

                    for (String related : copyRelated.get(var)) {
                        newRelations.addAll(copyRelated.get(related));
                    }

                    if (copyRelated.get(var).addAll(newRelations)) {
                        changed = true;
                    }
                }
            } while (changed);
        }

        private void buildInterferenceEdges() {
            Set<String> methodCallResults = new HashSet<>();

            for (Instruction inst : method.getInstructions()) {
                if (!(inst instanceof AssignInstruction assign)) continue;
                if (!(assign.getDest() instanceof Operand)) continue;

                String destVar = ((Operand) assign.getDest()).getName();
                if (destVar.equals("this")) continue;

                boolean isMethodCallResult = assign.getRhs() instanceof CallInstruction;
                if (isMethodCallResult) {
                    methodCallResults.add(destVar);
                }

                String srcVar = null;
                boolean isCopy = false;

                if (assign.getRhs() instanceof SingleOpInstruction sop &&
                        sop.getSingleOperand() instanceof Operand &&
                        !(sop.getSingleOperand() instanceof ArrayOperand)) {
                    srcVar = ((Operand) sop.getSingleOperand()).getName();
                    isCopy = true;
                }

                Set<String> liveVarsAfter = new HashSet<>(liveOut.get(inst));

                if (isCopy && srcVar != null && !srcVar.equals("this")) {
                    liveVarsAfter.remove(srcVar);
                }

                for (String liveVar : liveVarsAfter) {
                    if (!liveVar.equals(destVar) && !liveVar.equals("this")) {
                        addInterference(destVar, liveVar);
                    }
                }

                if (isMethodCallResult && assign.getRhs() instanceof CallInstruction call) {
                    for (Element arg : call.getArguments()) {
                        if (arg instanceof Operand && !(arg instanceof ArrayOperand)) {
                            String argName = ((Operand)arg).getName();
                            if (!argName.equals("this") && !argName.equals(destVar)) {
                                addInterference(destVar, argName);
                            }
                        }
                    }
                }
            }

            List<String> resultsList = new ArrayList<>(methodCallResults);
            for (int i = 0; i < resultsList.size(); i++) {
                for (int j = i + 1; j < resultsList.size(); j++) {
                    addInterference(resultsList.get(i), resultsList.get(j));
                }
            }
        }

        private void refineCopyRelations() {
            for (String var : graph.keySet()) {
                for (String related : new ArrayList<>(copyRelated.get(var))) {
                    if (!related.equals(var)) {
                        boolean safeToRemoveInterference = true;

                        for (Instruction inst : method.getInstructions()) {
                            Set<String> liveVarsAfter = liveOut.get(inst);
                            if (liveVarsAfter.contains(var) && liveVarsAfter.contains(related)) {
                                safeToRemoveInterference = false;
                                break;
                            }
                        }

                        if (safeToRemoveInterference) {
                            graph.get(var).remove(related);
                            graph.get(related).remove(var);
                        }
                    }
                }
            }
        }

        private void addInterference(String var1, String var2) {
            if (graph.containsKey(var1) && graph.containsKey(var2)) {
                graph.get(var1).add(var2);
                graph.get(var2).add(var1);
            }
        }
    }

    private class VarAssigner {
        private final Method method;
        private final Map<String, Set<String>> interferenceGraph;
        private final Map<String, Set<String>> copyRelations;

        public VarAssigner(Method method, InterferenceGraph graph) {
            this.method = method;
            this.interferenceGraph = graph.getGraph();
            this.copyRelations = graph.getCopyRelations();
        }

        public void assignMinimumRegisters() {
            List<Set<String>> registerGroups = buildRegisterGroups();

            Map<String, Integer> assignments = new HashMap<>();
            int registerIndex = 0;

            for (Set<String> group : registerGroups) {
                for (String var : group) {
                    assignments.put(var, registerIndex);
                }
                registerIndex++;
            }

            updateVariableTable(assignments);
        }

        private List<Set<String>> buildRegisterGroups() {
            List<Set<String>> groups = new ArrayList<>();
            Set<String> processed = new HashSet<>();

            List<String> sortedVars = new ArrayList<>(interferenceGraph.keySet());
            sortedVars.sort((v1, v2) -> {
                int chainSize1 = copyRelations.get(v1).size();
                int chainSize2 = copyRelations.get(v2).size();
                if (chainSize1 != chainSize2) {
                    return Integer.compare(chainSize2, chainSize1);
                }
                return Integer.compare(
                        interferenceGraph.get(v2).size(),
                        interferenceGraph.get(v1).size()
                );
            });

            for (String var : sortedVars) {
                if (processed.contains(var)) continue;

                Set<String> group = new HashSet<>();
                group.add(var);
                processed.add(var);

                for (String related : copyRelations.get(var)) {
                    if (related.equals(var) || processed.contains(related)) continue;

                    if (canAddToGroup(related, group)) {
                        group.add(related);
                        processed.add(related);
                    }
                }

                boolean merged = tryMergeWithExistingGroup(group, groups);

                if (!merged) {
                    groups.add(group);
                }
            }

            return groups;
        }

        private boolean canAddToGroup(String var, Set<String> group) {
            for (String member : group) {
                if (interferenceGraph.get(member).contains(var)) {
                    return false;
                }
            }
            return true;
        }

        private boolean tryMergeWithExistingGroup(Set<String> group, List<Set<String>> groups) {
            for (Set<String> existingGroup : groups) {
                if (canMergeGroups(group, existingGroup)) {
                    existingGroup.addAll(group);
                    return true;
                }
            }
            return false;
        }

        private boolean canMergeGroups(Set<String> group1, Set<String> group2) {
            for (String var1 : group1) {
                for (String var2 : group2) {
                    if (interferenceGraph.get(var1).contains(var2)) {
                        return false;
                    }
                }
            }
            return true;
        }        public boolean assignLimitedRegisters(int maxRegisters) {
            try {
                Map<String, Integer> assignments = colorGraph(maxRegisters);
                if (assignments == null) {
                    // Allocation failed
                    int minRequired = estimateMinimumRegisters();
                    throw new RegisterAllocationException(minRequired);
                }
                updateVariableTable(assignments);
                return true;
            } catch (Exception e) {
                int minRequired = estimateMinimumRegisters();
                throw new RegisterAllocationException(minRequired);
            }
        }

        private Map<String, Integer> colorGraph(int maxColors) {
            Map<String, Integer> colorAssignment = new HashMap<>();

            Map<String, Set<String>> copyGroups = new HashMap<>();
            Map<String, String> varToGroupLeader = new HashMap<>();

            for (String var : interferenceGraph.keySet()) {
                copyGroups.put(var, new HashSet<>());
                copyGroups.get(var).add(var);
                varToGroupLeader.put(var, var);

                for (String related : copyRelations.get(var)) {
                    if (!related.equals(var) && !interferenceGraph.get(var).contains(related)) {
                        copyGroups.get(var).add(related);
                        varToGroupLeader.put(related, var);
                    }
                }
            }

            Stack<String> removalStack = new Stack<>();
            Set<String> removed = new HashSet<>();
            Map<String, Set<String>> workGraph = cloneGraph(interferenceGraph);

            List<String> sortedVars = new ArrayList<>(workGraph.keySet());
            sortedVars.sort(createSimplificationOrdering(copyGroups, varToGroupLeader, workGraph));

            while (!sortedVars.isEmpty()) {
                String nodeToRemove = null;
                for (String node : sortedVars) {
                    if (workGraph.get(node).size() < maxColors) {
                        nodeToRemove = node;
                        break;
                    }
                }                if (nodeToRemove == null) {
                    return null; // Indicate allocation failure
                }

                String leader = varToGroupLeader.getOrDefault(nodeToRemove, nodeToRemove);
                for (String groupMember : copyGroups.get(leader)) {
                    if (sortedVars.contains(groupMember)) {
                        removalStack.push(groupMember);
                        sortedVars.remove(groupMember);
                        removed.add(groupMember);

                        for (String neighbor : interferenceGraph.get(groupMember)) {
                            if (workGraph.containsKey(neighbor)) {
                                workGraph.get(neighbor).remove(groupMember);
                            }
                        }
                    }
                }

                sortedVars.sort(createSimplificationOrdering(copyGroups, varToGroupLeader, workGraph));
            }

            Map<String, Integer> groupColors = new HashMap<>();
            Set<String> colored = new HashSet<>();

            while (!removalStack.isEmpty()) {
                String var = removalStack.pop();
                if (colored.contains(var)) continue;

                String groupLeader = varToGroupLeader.getOrDefault(var, var);
                if (groupColors.containsKey(groupLeader)) {
                    colorAssignment.put(var, groupColors.get(groupLeader));
                    colored.add(var);
                    continue;
                }

                Set<Integer> usedColors = new HashSet<>();
                for (String neighbor : interferenceGraph.get(var)) {
                    if (colorAssignment.containsKey(neighbor)) {
                        usedColors.add(colorAssignment.get(neighbor));
                    }
                }

                int color = 0;
                while (usedColors.contains(color) && color < maxColors) {
                    color++;
                }                if (color >= maxColors) {
                    return null; // Indicate allocation failure
                }

                colorAssignment.put(var, color);
                colored.add(var);

                groupColors.put(groupLeader, color);

                for (String member : copyGroups.get(groupLeader)) {
                    if (!member.equals(var) && !colored.contains(member)) {
                        boolean canUseColor = true;

                        for (String neighbor : interferenceGraph.get(member)) {
                            Integer neighborColor = colorAssignment.get(neighbor);
                            if (neighborColor != null && neighborColor == color) {
                                canUseColor = false;
                                break;
                            }
                        }

                        if (canUseColor) {
                            colorAssignment.put(member, color);
                            colored.add(member);
                        }
                    }
                }
            }

            return colorAssignment;
        }

        private Comparator<String> createSimplificationOrdering(
                Map<String, Set<String>> copyGroups,
                Map<String, String> varToGroupLeader,
                Map<String, Set<String>> workGraph) {

            return (v1, v2) -> {
                String group1 = varToGroupLeader.getOrDefault(v1, v1);
                String group2 = varToGroupLeader.getOrDefault(v2, v2);

                int size1 = copyGroups.get(group1).size();
                int size2 = copyGroups.get(group2).size();
                if (size1 != size2) {
                    return Integer.compare(size2, size1);
                }

                return Integer.compare(workGraph.get(v1).size(), workGraph.get(v2).size());
            };
        }

        private Map<String, Set<String>> cloneGraph(Map<String, Set<String>> original) {
            Map<String, Set<String>> copy = new HashMap<>();
            for (Map.Entry<String, Set<String>> entry : original.entrySet()) {
                copy.put(entry.getKey(), new HashSet<>(entry.getValue()));
            }
            return copy;
        }

        private void updateVariableTable(Map<String, Integer> assignments) {
            List<Element> params = method.getParams();
            Set<String> paramNames = params.stream()
                    .filter(Operand.class::isInstance)
                    .map(param -> ((Operand) param).getName())
                    .collect(Collectors.toSet());

            int nextParamReg = 0;

            if (!method.isStaticMethod() && method.getVarTable().containsKey("this")) {
                method.getVarTable().get("this").setVirtualReg(nextParamReg++);
            }

            for (Element param : params) {
                if (param instanceof Operand paramOp) {
                    String paramName = paramOp.getName();
                    if (!paramName.equals("this")) {
                        method.getVarTable().get(paramName).setVirtualReg(nextParamReg++);
                    }
                }
            }

            int localRegBase = nextParamReg;

            for (Map.Entry<String, Integer> entry : assignments.entrySet()) {
                String varName = entry.getKey();

                if (!paramNames.contains(varName) && !varName.equals("this")) {
                    method.getVarTable().get(varName).setVirtualReg(localRegBase + entry.getValue());
                }
            }
        }

        private int estimateMinimumRegisters() {
            try {
                Map<String, Integer> coloring = colorGraph(Integer.MAX_VALUE);

                int maxColor = -1;
                for (int color : coloring.values()) {
                    maxColor = Math.max(maxColor, color);
                }

                return maxColor + 1;
            } catch (Exception e) {
                int maxDegree = 0;
                for (Set<String> neighbors : interferenceGraph.values()) {
                    maxDegree = Math.max(maxDegree, neighbors.size());
                }
                return maxDegree + 1;
            }
        }
    }
}