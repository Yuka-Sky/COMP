package pt.up.fe.comp2025.backend;

import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.AssignInstruction;
import org.specs.comp.ollir.inst.BinaryOpInstruction;
import org.specs.comp.ollir.type.BuiltinKind;
import org.specs.comp.ollir.type.BuiltinType;

import java.util.Map;

public class JasminIncrementOptimizer {
    
    public static boolean canApplyIincOptimization(AssignInstruction assign) {
        if (!(assign.getDest() instanceof Operand)) {
            return false; // Target must be a simple variable
        }
        
        Operand destOperand = (Operand) assign.getDest();
        
        // Check if RHS is a binary operation
        if (!(assign.getRhs() instanceof BinaryOpInstruction)) {
            return false;
        }        
        BinaryOpInstruction binOp = (BinaryOpInstruction) assign.getRhs();
        OperationType opType = binOp.getOperation().getOpType();
        
        // Only handle addition and subtraction
        if (opType != OperationType.ADD && opType != OperationType.SUB) {
            return false;
        }
        
        // Check if we're using integers
        if (!(destOperand.getType() instanceof BuiltinType) || 
            ((BuiltinType) destOperand.getType()).getKind() != BuiltinKind.INT32) {
            return false;
        }
        
        // Check that left operand is the same variable as destination
        if (!(binOp.getLeftOperand() instanceof Operand)) {
            return false;
        }
        
        Operand leftOp = (Operand) binOp.getLeftOperand();
        if (!leftOp.getName().equals(destOperand.getName())) {
            return false;
        }
        
        // Check if right operand is a literal integer value within -128 to 127
        if (!(binOp.getRightOperand() instanceof LiteralElement)) {
            return false;
        }
        
        LiteralElement literal = (LiteralElement) binOp.getRightOperand();
        
        try {
            int value = Integer.parseInt(literal.getLiteral());
            // iinc can only handle values from -128 to 127
            return value >= -128 && value <= 127;        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    public static boolean canApplyIincOptimizationPair(AssignInstruction firstAssign, AssignInstruction secondAssign) {
        // First assignment should be: temp = var + constant
        if (!(firstAssign.getDest() instanceof Operand)) {
            return false;
        }
        
        if (!(firstAssign.getRhs() instanceof BinaryOpInstruction)) {
            return false;
        }
        
        BinaryOpInstruction binOp = (BinaryOpInstruction) firstAssign.getRhs();
        OperationType opType = binOp.getOperation().getOpType();
        
        // Only handle addition and subtraction
        if (opType != OperationType.ADD && opType != OperationType.SUB) {
            return false;
        }
        
        // Check if left operand is a variable and right operand is a literal
        if (!(binOp.getLeftOperand() instanceof Operand) || !(binOp.getRightOperand() instanceof LiteralElement)) {
            return false;
        }
        
        Operand originalVar = (Operand) binOp.getLeftOperand();
        LiteralElement literal = (LiteralElement) binOp.getRightOperand();
        Operand tempVar = (Operand) firstAssign.getDest();
        
        // Check if we're using integers
        if (!(originalVar.getType() instanceof BuiltinType) || 
            ((BuiltinType) originalVar.getType()).getKind() != BuiltinKind.INT32) {
            return false;
        }
        
        // Check if literal is within iinc range
        try {
            int value = Integer.parseInt(literal.getLiteral());
            if (value < -128 || value > 127) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        
        // Second assignment should be: var = temp
        if (!(secondAssign.getDest() instanceof Operand) || !(secondAssign.getRhs() instanceof org.specs.comp.ollir.inst.SingleOpInstruction)) {
            return false;
        }
        
        Operand finalVar = (Operand) secondAssign.getDest();
        org.specs.comp.ollir.inst.SingleOpInstruction singleOp = (org.specs.comp.ollir.inst.SingleOpInstruction) secondAssign.getRhs();
        
        if (!(singleOp.getSingleOperand() instanceof Operand)) {
            return false;
        }
        
        Operand sourceVar = (Operand) singleOp.getSingleOperand();
        
        return originalVar.getName().equals(finalVar.getName()) && 
               tempVar.getName().equals(sourceVar.getName());
    }
    
    public static String generateIincInstructionFromPair(AssignInstruction firstAssign, Map<String, Descriptor> varTable) {
        BinaryOpInstruction binOp = (BinaryOpInstruction) firstAssign.getRhs();
        OperationType opType = binOp.getOperation().getOpType();
        LiteralElement literal = (LiteralElement) binOp.getRightOperand();
        Operand originalVar = (Operand) binOp.getLeftOperand();
          try {
            int value = Integer.parseInt(literal.getLiteral());
            int increment = (opType == OperationType.ADD) ? value : -value;
            
            var reg = varTable.get(originalVar.getName());
            return "iinc " + reg.getVirtualReg() + " " + increment + "\n";
        } catch (NumberFormatException e) {
            throw new IllegalStateException("Failed to parse integer literal: " + literal.getLiteral());
        }
    }
    
    public static String generateIincInstruction(AssignInstruction assign, Map<String, Descriptor> varTable) {
        Operand destOperand = (Operand) assign.getDest();
        BinaryOpInstruction binOp = (BinaryOpInstruction) assign.getRhs();
        OperationType opType = binOp.getOperation().getOpType();
        LiteralElement literal = (LiteralElement) binOp.getRightOperand();
        
        try {
            int value = Integer.parseInt(literal.getLiteral());
            int increment = (opType == OperationType.ADD) ? value : -value;
            
            var reg = varTable.get(destOperand.getName());
            return "iinc " + reg.getVirtualReg() + " " + increment + "\n";
        } catch (NumberFormatException e) {
            throw new IllegalStateException("Failed to parse integer literal: " + literal.getLiteral());
        }
    }
}
