package pt.up.fe.comp2025.optimization;

import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp.jmm.ast.AJmmVisitor;
import pt.up.fe.comp.jmm.analysis.JmmSemanticsResult;
import pt.up.fe.comp.jmm.report.Report;
import pt.up.fe.comp.jmm.report.ReportType;
import pt.up.fe.comp.jmm.report.Stage;
import pt.up.fe.comp2025.ast.TypeUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Implements constant folding optimization.
 *
 * This class identifies expressions with constant values (like "10 + 5") and
 * replaces them with their computed result (like "15").
 */
public class ConstantFolding extends AJmmVisitor<Map<String, Object>, Boolean> {

    private final TypeUtils typeUtils;

    // Statistics for reporting
    private int foldingCount = 0;

    public ConstantFolding(TypeUtils typeUtils) {
        this.typeUtils = typeUtils;
    }

    @Override
    protected void buildVisitor() {
        addVisit("BinaryExpr", this::visitBinaryExpr);
        addVisit("UnaryExpr", this::visitUnaryExpr);
        addVisit("ParenExpr", this::visitParenExpr);

        setDefaultVisit(this::defaultVisit);
    }

    /**
     * Default visit method for nodes without specific handlers.
     */
    private Boolean defaultVisit(JmmNode node, Map<String, Object> data) {
        // Process all children
        for (JmmNode child : node.getChildren()) {
            visit(child, data);
        }
        return true;
    }

    /**
     * Processes binary expressions like addition, subtraction, etc. and folds them when possible.
     */
    private Boolean visitBinaryExpr(JmmNode node, Map<String, Object> data) {
        // First process the children
        for (JmmNode child : node.getChildren()) {
            visit(child, data);
        }

        // Get the children after processing (they may have been replaced)
        List<JmmNode> children = node.getChildren();
        if (children.size() != 2) {
            return false; // Binary expression should have exactly 2 children
        }

        // Check if both operands are integer literals
        JmmNode left = children.get(0);
        JmmNode right = children.get(1);

        if (isIntegerLiteral(left) && isIntegerLiteral(right)) {
            int leftValue = Integer.parseInt(left.get("value"));
            int rightValue = Integer.parseInt(right.get("value"));
            String op = node.get("op");

            // Compute the result
            Integer result = performBinaryOperation(leftValue, rightValue, op);

            // If the operation can be folded, replace the node with the result
            if (result != null) {
                JmmNode intLiteral = createIntegerLiteral(result);
                node.replace(intLiteral);
                foldingCount++;
                return true;
            }
        } else if (isBooleanLiteral(left) && isBooleanLiteral(right)) {
            // Handle boolean operations
            boolean leftValue = getBooleanValue(left);
            boolean rightValue = getBooleanValue(right);
            String op = node.get("op");

            // Compute the result for boolean operations
            Boolean result = performBooleanOperation(leftValue, rightValue, op);

            // If the operation can be folded, replace the node with the result
            if (result != null) {
                JmmNode boolLiteral = createBooleanLiteral(result);
                node.replace(boolLiteral);
                foldingCount++;
                return true;
            }
        }

        return false;
    }

    /**
     * Processes unary expressions like negation and folds them when possible.
     */
    private Boolean visitUnaryExpr(JmmNode node, Map<String, Object> data) {
        // Process the child first
        if (node.getNumChildren() != 1) {
            return defaultVisit(node, data);
        }

        visit(node.getChild(0), data);

        // After processing, get the child (it may have been replaced)
        JmmNode child = node.getChild(0);
        String op = node.get("op");

        // For boolean negation
        if (op.equals("!") && isBooleanLiteral(child)) {
            boolean value = getBooleanValue(child);
            JmmNode boolLiteral = createBooleanLiteral(!value);
            node.replace(boolLiteral);
            foldingCount++;
            return true;
        }

        // For integer negation (if your language supports it)
        if (op.equals("-") && isIntegerLiteral(child)) {
            int value = Integer.parseInt(child.get("value"));
            JmmNode intLiteral = createIntegerLiteral(-value);
            node.replace(intLiteral);
            foldingCount++;
            return true;
        }

        return false;
    }

    /**
     * Handles parenthesized expressions by removing them when they contain a literal.
     */
    private Boolean visitParenExpr(JmmNode node, Map<String, Object> data) {
        // Process the child first
        if (node.getNumChildren() != 1) {
            return defaultVisit(node, data);
        }

        visit(node.getChild(0), data);

        // After processing, get the child (it may have been replaced)
        JmmNode child = node.getChild(0);

        // If child is a literal, replace the parenthesis node with the child
        if (isLiteral(child)) {
            node.replace(child);
            foldingCount++;
            return true;
        }

        return false;
    }

    /**
     * Creates a new IntegerLiteral node with the given value.
     */
    private JmmNode createIntegerLiteral(Integer value) {
        JmmNode intLiteral = node("IntegerLiteral");
        intLiteral.put("value", value.toString());
        return intLiteral;
    }

    /**
     * Creates a new boolean literal node (either TrueBool or FalseBool).
     */
    private JmmNode createBooleanLiteral(boolean value) {
        if (value) {
            return node("TrueBool");
        } else {
            return node("FalseBool");
        }
    }

    /**
     * Helper method to create a new JmmNode with specific kind.
     */
    private JmmNode node(String kind) {
        return new pt.up.fe.comp.jmm.ast.JmmNodeImpl(Collections.singletonList(kind));
    }

    /**
     * Returns the number of constant foldings made during optimization.
     */
    public int getFoldingCount() {
        return foldingCount;
    }

    /**
     * Checks if a node is an integer literal.
     */
    private boolean isIntegerLiteral(JmmNode node) {
        return node.getKind().equals("IntegerLiteral");
    }

    /**
     * Checks if a node is a boolean literal (true or false).
     */
    private boolean isBooleanLiteral(JmmNode node) {
        return node.getKind().equals("TrueBool") || node.getKind().equals("FalseBool");
    }

    /**
     * Checks if a node is any kind of literal.
     */
    private boolean isLiteral(JmmNode node) {
        return isIntegerLiteral(node) || isBooleanLiteral(node);
    }

    /**
     * Gets the boolean value from a boolean literal node.
     */
    private boolean getBooleanValue(JmmNode node) {
        return node.getKind().equals("TrueBool");
    }

    /**
     * Performs binary operations on constant integer values.
     */
    private Integer performBinaryOperation(Integer left, Integer right, String op) {
        switch (op) {
            case "+": return left + right;
            case "-": return left - right;
            case "*": return left * right;
            case "/":
                if (right == 0) return null; // Avoid division by zero
                return left / right;
            case "%":
                if (right == 0) return null; // Avoid modulo by zero
                return left % right;
            default:
                return null; // Other operations not handled for constant folding
        }
    }

    /**
     * Performs binary operations on constant boolean values.
     */
    private Boolean performBooleanOperation(Boolean left, Boolean right, String op) {
        switch (op) {
            case "&&": return left && right;
            case "||": return left || right;
            case "==": return left.equals(right);
            case "!=": return !left.equals(right);
            default:
                return null; // Other operations not handled for boolean folding
        }
    }
}
