package pt.up.fe.comp2025.optimization;

import pt.up.fe.comp.jmm.analysis.table.Type;
import pt.up.fe.comp.jmm.ast.JmmNode;
import pt.up.fe.comp2025.ast.TypeUtils;
import pt.up.fe.specs.util.collections.AccumulatorMap;
import pt.up.fe.specs.util.exceptions.NotImplementedException;
import pt.up.fe.comp.jmm.ast.JmmNodeImpl;

import static pt.up.fe.comp2025.ast.Kind.TYPE;

/**
 * Utility methods related to the optimization middle-end.
 */
public class OptUtils {


    private final AccumulatorMap<String> temporaries;

    private final TypeUtils types;

    public OptUtils(TypeUtils types) {
        this.types = types;
        this.temporaries = new AccumulatorMap<>();
    }


    public String nextTemp() {
        return nextTemp("tmp");
    }

    public String nextTemp(String prefix) {
        var nextTempNum = temporaries.add(prefix) - 1;
        return prefix + nextTempNum;
    }


    public String toOllirType(JmmNode typeNode) {
        TYPE.checkOrThrow(typeNode);
        return toOllirType(types.convertType(typeNode));
    }

    public String toOllirType(Type type) {
        if (type.isArray()) {
            // For arrays, format is ".array.<elementType>"
            // ".array" + Ollir type
            return ".array" + toOllirElementType(type.getName());
        } else {
            // For non-arrays -> simple name conversion
            return toOllirSimpleType(type.getName());
        }
    }

    private String toOllirSimpleType(String typeName) {
        return "." + switch (typeName) {
            case "int" -> "i32";
            case "boolean" -> "bool";
            case "String" -> "String";
            case "void" -> "V";
            default -> typeName; // custom class names are used directly
        };
    }

    // Helper method to get the OLLIR type string for array elements
    // OLLIR array element types do not have the leading dot, but it's added by toOllirSimpleType
    private String toOllirElementType(String elementTypeName) {
        return switch (elementTypeName) {
            case "int" -> ".i32";
            case "boolean" -> ".bool";
            case "String" -> ".String";
            default -> "." + elementTypeName; // custom class names are used directly
        };
    }

}
