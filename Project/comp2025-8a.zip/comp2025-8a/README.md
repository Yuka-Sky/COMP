# Compiler Project

**30%** : Luís Martim up202208429 \
**40%** : Tiago Teixeira up202208511 \
**30%** : Yuka Sakai up202300600

## CP2 Optimizations

This compiler implements the following optimizations:

### 1. Constant Propagation
The compiler performs constant propagation to replace variable references with their known constant values throughout the program. This optimization is implemented in `ConstantPropagation.java` and works by:
- Tracking assignments of constant values to variables
- Replacing subsequent uses of those variables with their constant values
- Propagating constants through the control flow of the program

### 2. Constant Folding
The compiler performs constant folding to evaluate constant expressions at compile time. This optimization is implemented in `ConstantFolding.java` and includes:
- Evaluation of arithmetic operations on constants (for example, `10 + 5` becomes `15`)
- Folding of boolean expressions with constant operands
- Simplification of expressions that can be computed at compile time

### 3. Register Allocation
The compiler implements register allocation using graph coloring to optimize register usage. This optimization is implemented in `RegisterAllocator.java` and features:
- Construction of an interference graph between variables
- Graph coloring algorithm to assign registers to variables
- Spilling of variables to memory when insufficient registers are available
- Optimization of register reuse to minimize memory accesses

### Configuration
The optimizations can be controlled through command-line options:
- `-o` flag enables general optimizations (constant propagation and folding)
- `-r <number>` flag controls register allocation with the following behavior:
  - **n ≥ 1**: Uses at most `n` local variables when generating Jasmin instructions. Reports the mapping between local variables and JVM variables. If `n` is insufficient, the compiler aborts with an error indicating the minimum number of registers required.
  - **n = 0**: Uses as few local variables as possible (optimal allocation). Reports the variable mapping.
  - **n = -1**: Uses as many variables as originally present in the OLLIR representation (default behavior, no optimization).

All optimizations are prepared through the `JmmOptimizationImpl.java` class, which applies them in the appropriate order to maximize their effectiveness.