package foo.bar;

public class A {

    public static String foo() {
        return "class A";
    }

}