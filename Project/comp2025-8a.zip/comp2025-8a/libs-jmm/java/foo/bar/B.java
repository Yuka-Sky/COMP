package foo.bar;

public class B {

    public static String foo() {
        return "class B";
    }

}