package pt.up.fe.comp;

public class Comp {

    public static String foo() {
        return "class Comp";
    }

}