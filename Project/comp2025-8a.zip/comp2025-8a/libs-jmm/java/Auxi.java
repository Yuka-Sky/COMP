class Auxi {


    public static void staticCall(int a) {
        io.println(a);
    }

    public void instanceCallVoid() {
        io.println(10);
    }

    public int instanceCallInt() {
        return 20;
    }

    public boolean instanceCallBool() {
        return true;
    }

}